import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'electron-vite';

const projectRoot = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  main: {
    build: {
      rollupOptions: {
        input: resolve(projectRoot, 'src/main/main.ts'),
        output: { format: 'es', entryFileNames: 'main.js' },
      },
    },
  },
  preload: {
    build: {
      rollupOptions: {
        input: resolve(projectRoot, 'src/preload/preload.ts'),
        // Sandboxed preloads must be a single CommonJS bundle, even with an ESM main.
        output: { format: 'cjs', entryFileNames: 'preload.cjs', inlineDynamicImports: true },
      },
    },
  },
  renderer: {
    root: resolve(projectRoot, 'src/renderer'),
    base: './',
    plugins: [react()],
    server: {
      host: '127.0.0.1',
      port: 5173,
      strictPort: true,
    },
    build: {
      minify: 'esbuild',
      rollupOptions: { input: resolve(projectRoot, 'src/renderer/index.html') },
    },
  },
});
