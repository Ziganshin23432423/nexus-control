import { WindowsSshProvider } from '../src/main/providers/windows/WindowsSshProvider.js';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import test from 'node:test';
import { WindowsRdpProvider, findWindowsRdpClient, launchWindowsRdpClient } from '../src/main/providers/windows/WindowsRdpProvider.js';
import { createPlatformService } from '../src/main/platform/createPlatformService.js';
import { RemoteDesktopService } from '../src/main/services/remoteDesktopService.js';
import { NetworkService, CheckCancelledError } from '../src/main/services/networkService.js';
import { CheckCoordinator } from '../src/main/services/checkCoordinator.js';
import { createRdpRequestHandler } from '../src/main/ipc/rdpRequest.js';
import { isTrustedIpcSender } from '../src/main/ipc/trustedSender.js';
import { performComputerAction } from '../src/renderer/state/computerActions.js';
import type { Computer } from '../src/shared/types.js';
import type { RemoteDesktopTarget } from '../src/main/providers/contracts.js';
import type { TcpProbe, TcpProbeResult } from '../src/main/services/tcpProbe.js';
import { record } from './fixtures.js';

const ready: TcpProbeResult = { status: 'ready', latencyMs: 1, errorCode: null };
const unavailable: TcpProbeResult = { status: 'unavailable', latencyMs: null, errorCode: 'ECONNREFUSED' };
function setup(computer: Computer = record, probe: TcpProbe = async () => ready, launch: (target: RemoteDesktopTarget) => Promise<void> = async () => {}) {
  const calls: RemoteDesktopTarget[] = [];
  let current = computer;
  const store = { get: () => current, list: () => [current] };
  const checks = new CheckCoordinator(store, new NetworkService(probe));
  const service = new RemoteDesktopService(store, checks, { id: 'mock', open: async target => { calls.push(target); await launch(target); } });
  return { service, calls, checks, setComputer: (value: Computer) => { current = value; } };
}
const code = (expected: string) => (error: unknown) => typeof error === 'object' && error !== null && 'code' in error && error.code === expected;

test('Windows provider uses a single validated /v argument, absolute system client and no PATH lookup', async () => {
  let path = ''; let args: readonly string[] = [];
  const provider = new WindowsRdpProvider(() => findWindowsRdpClient({ SystemRoot: 'D:\\Windows', PATH: 'C:\\untrusted' }, async file => { assert.equal(file, 'D:\\Windows\\System32\\mstsc.exe'); return true; }), async (file, values) => { path = file; args = values; });
  await provider.open({ host: 'PC-HOME.example.test', port: 3389 });
  assert.equal(path, 'D:\\Windows\\System32\\mstsc.exe'); assert.deepEqual(args, ['/v:PC-HOME.example.test']);
});
test('Client discovery rejects missing files, directories, relative/UNC/traversal roots without PATH fallback', async () => {
  for (const root of [undefined, 'Windows', '\\\\server\\share', 'C:\\Windows\\..\\evil']) await assert.rejects(findWindowsRdpClient(root ? { SystemRoot: root } : {}, async () => true), code('RDP_CLIENT_MISSING'));
  await assert.rejects(findWindowsRdpClient({ SystemRoot: 'C:\\Windows' }, async () => false), code('RDP_CLIENT_MISSING'));
  await assert.rejects(findWindowsRdpClient({ SystemRoot: 'C:\\Windows' }, async () => { throw new Error('not found'); }), code('RDP_CLIENT_MISSING'));
});
test('Spawn uses shell false, detached ignored stdio; resolves on spawn, unrefs and handles later errors', async () => {
  class Child extends EventEmitter { unrefCalls = 0; unref(): void { this.unrefCalls++; } }
  const child = new Child(); let resolved = false;
  const promise = launchWindowsRdpClient('C:\\Windows\\System32\\mstsc.exe', ['/v:127.0.0.1'], (file, args, options) => {
    assert.equal(file, 'C:\\Windows\\System32\\mstsc.exe'); assert.deepEqual(args, ['/v:127.0.0.1']);
    assert.deepEqual(options, { shell: false, detached: true, stdio: 'ignore', windowsHide: false }); return child;
  }).then(() => { resolved = true; });
  await Promise.resolve(); assert.equal(resolved, false); child.emit('spawn'); await promise; assert.equal(child.unrefCalls, 1);
  child.emit('error', new Error('later error')); // Handled even though launch already resolved.
});
test('Spawn error and synchronous launch exception produce controlled failure without waiting for exit', async () => {
  class Child extends EventEmitter { unref(): void { assert.fail('must not unref unsuccessful launch'); } }
  const child = new Child(); const promise = launchWindowsRdpClient('client', [], () => child);
  child.emit('error', new Error('ENOENT')); await assert.rejects(promise, code('RDP_LAUNCH_ERROR'));
  await assert.rejects(launchWindowsRdpClient('client', [], () => { throw new Error('EACCES'); }), code('RDP_LAUNCH_ERROR'));
});
test('Provider rejects hostile hosts/ports before discovery or launch', async () => {
  let calls = 0; const provider = new WindowsRdpProvider(async () => { calls++; return 'client'; }, async () => { calls++; });
  for (const host of ['host&cmd', 'host|cmd', 'host;cmd', 'host"', "host'", 'host$()', '-flag', 'host /admin', 'host:3389', 'rdp://host', 'host\ncmd']) await assert.rejects(provider.open({ host, port: 3389 }));
  await assert.rejects(provider.open({ host: 'host', port: 22 })); assert.equal(calls, 0);
});
test('Composition retains Windows RDP and SSH with configured WoL capability', () => {
  const windows = createPlatformService('win32'); assert.ok(windows.providers.remoteDesktop instanceof WindowsRdpProvider);
  assert.ok(windows.providers.ssh instanceof WindowsSshProvider); assert.ok(windows.providers.wakeOnLan);
  assert.equal(createPlatformService('linux').providers.remoteDesktop, null); assert.equal(createPlatformService('darwin').providers.remoteDesktop, null);
});
test('Disabled RDP, non-Windows computer, invalid ID/config never probe or launch', async () => {
  let probes = 0;
  for (const computer of [{ ...record, rdpEnabled: false }, { ...record, operatingSystem: 'linux' as const }, { ...record, localAddress: 'host;cmd' }]) {
    const ctx = setup(computer, async () => { probes++; return ready; }); await assert.rejects(ctx.service.open(record.id)); assert.equal(ctx.calls.length, 0);
  }
  const ctx = setup(); for (const id of [null, { id: record.id, host: 'evil' }, 'host', `${record.id};cmd`]) await assert.rejects(ctx.service.open(id), code('VALIDATION_ERROR'));
  assert.equal(ctx.calls.length, 0); assert.equal(probes, 0);
});
test('Unsupported application host returns controlled error without fresh network or process launch', async () => {
  let probes = 0; const service = new RemoteDesktopService({ get: () => record }, { checkRdp: async () => { probes++; throw new Error(); } }, null);
  await assert.rejects(service.open(record.id), code('RDP_UNSUPPORTED')); assert.equal(probes, 0);
});
test('Fresh RDP local ready chooses local only, never probes SSH, and result asserts client launch only', async () => {
  const probes: string[] = []; const ctx = setup({ ...record, remoteAddress: '192.168.1.26' }, async (host, service) => { assert.equal(service, 'rdp'); probes.push(host); return ready; });
  const result = await ctx.service.open(record.id); assert.deepEqual(probes, [record.localAddress]); assert.equal(ctx.calls[0]?.host, record.localAddress); assert.equal(result.state, 'client-opened');
  await ctx.service.open(record.id); assert.equal(probes.length, 2); // No reuse of an earlier READY.
});
test('Fresh local failure falls back to remote and launches the actual reachable address', async () => {
  const probes: string[] = []; const ctx = setup({ ...record, remoteAddress: '192.168.1.26' }, async host => { probes.push(host); return host === record.localAddress ? unavailable : ready; });
  await ctx.service.open(record.id); assert.deepEqual(probes, [record.localAddress, '192.168.1.26']); assert.equal(ctx.calls[0]?.host, '192.168.1.26');
});
test('Fresh local/remote unavailable never launch, even after a previous ready result', async () => {
  let online = true; const ctx = setup({ ...record, remoteAddress: '192.168.1.26' }, async () => online ? ready : unavailable);
  await ctx.service.open(record.id); online = false; await assert.rejects(ctx.service.open(record.id), code('RDP_UNAVAILABLE')); assert.equal(ctx.calls.length, 1);
});
test('Launch failure unlocks operation for retry and does not report authentication success', async () => {
  let fail = true; const ctx = setup(record, async () => ready, async () => { if (fail) throw new Error('mock failure'); });
  const handler = createRdpRequestHandler(() => {}, ctx.service); const error = await handler({}, record.id); assert.equal(error.ok, false);
  fail = false; const reply = await handler({}, record.id); assert.equal(reply.ok, true); if (reply.ok) assert.equal(reply.value.state, 'client-opened');
});
test('Duplicate invocation is rejected while fresh check or spawn is pending, then unlocked', async () => {
  let finish!: (value: TcpProbeResult) => void; let launchDone!: () => void;
  const ctx = setup(record, () => new Promise(resolve => { finish = resolve; }), () => new Promise(resolve => { launchDone = resolve; }));
  const first = ctx.service.open(record.id); await assert.rejects(ctx.service.open(record.id), code('RDP_BUSY'));
  finish(ready); for (let i = 0; i < 8; i++) await Promise.resolve(); await assert.rejects(ctx.service.open(record.id), code('RDP_BUSY'));
  launchDone(); await first; assert.equal(ctx.calls.length, 1);
});
test('Edit/delete or shutdown during check cancels launch; cancellation also guards async discovery', async () => {
  for (const mode of ['edit', 'close']) {
    let finish!: (value: TcpProbeResult) => void; const ctx = setup(record, () => new Promise(resolve => { finish = resolve; }));
    const task = ctx.service.open(record.id); for (let i = 0; i < 5; i++) await Promise.resolve();
    if (mode === 'edit') ctx.setComputer({ ...record, name: 'changed' }); else ctx.service.cancelPending();
    finish(ready); await assert.rejects(task, CheckCancelledError); assert.equal(ctx.calls.length, 0);
  }
  let found!: (file: string) => void; let launches = 0; const controller = new AbortController();
  const provider = new WindowsRdpProvider(() => new Promise(resolve => { found = resolve; }), async () => { launches++; });
  const task = provider.open({ host: 'host', port: 3389, signal: controller.signal }); controller.abort(); found('client');
  await assert.rejects(task, CheckCancelledError); assert.equal(launches, 0);
});
test('RDP checks share Stage4 concurrency pool without cancelling the status refresh', async () => {
  const computers = Array.from({ length: 8 }, (_, i) => ({ ...record, id: `${String(i + 1).repeat(8)}-1111-4111-8111-111111111111`, sshEnabled: false }));
  let probes = 0; const releases: (() => void)[] = [];
  const coordinator = new CheckCoordinator({ get: () => record, list: () => computers }, new NetworkService(() => { probes++; return new Promise(resolve => releases.push(() => resolve(ready))); }));
  const refresh = coordinator.refreshAllComputerStatuses(); for (let i = 0; i < 12; i++) await Promise.resolve(); assert.equal(probes, 8);
  const launchCheck = coordinator.checkRdp(record, new AbortController().signal); for (let i = 0; i < 5; i++) await Promise.resolve(); assert.equal(probes, 8);
  releases.shift()?.(); for (let i = 0; i < 15; i++) await Promise.resolve(); assert.equal(probes, 9);
  for (const release of releases) release(); await refresh; await launchCheck;
});
test('IPC rejects wrong window/frame/URL before operation; accepts ID only, never forged hosts/args', async () => {
  const frame = { url: 'nexus://app/index.html' }; const contents = { mainFrame: frame }; const window = { webContents: contents, isDestroyed: () => false };
  const good = { sender: contents, senderFrame: frame }; let calls = 0;
  const handler = createRdpRequestHandler((event: typeof good) => { if (!isTrustedIpcSender(event, window, frame.url)) throw new Error('untrusted'); }, { open: async () => { calls++; throw new Error('unused'); } });
  for (const event of [{ sender: { mainFrame: frame }, senderFrame: frame }, { sender: contents, senderFrame: { url: frame.url } }, { sender: contents, senderFrame: { url: 'https://evil.test' } }]) await assert.rejects(handler(event, record.id));
  assert.equal(isTrustedIpcSender(good, null, frame.url), false); assert.equal(isTrustedIpcSender(good, { ...window, isDestroyed: () => true }, frame.url), false);
  const reply = await handler(good, record.id, { host: 'evil', args: ['/admin'] }); assert.equal(reply.ok, false); assert.equal(calls, 0);
});
test('Demo RDP/SSH actions cannot reach native orchestration; user WoL still cannot launch anything', () => {
  let demo = 0; const rdpIds: string[] = []; const sshIds: string[] = [];
  const rdp = (id: string) => { rdpIds.push(id); }; const ssh = (id: string) => { sshIds.push(id); };
  for (const action of ['rdp', 'ssh', 'wake', 'wake-rdp'] as const) performComputerAction(true, record, action, () => { demo++; }, rdp, ssh);
  assert.equal(demo, 4); assert.equal(rdpIds.length, 0); assert.equal(sshIds.length, 0);
  for (const action of ['wake', 'wake-rdp'] as const) performComputerAction(false, record, action, () => { demo++; }, rdp, ssh);
  performComputerAction(false, record, 'rdp', () => { demo++; }, rdp, ssh);
  performComputerAction(false, record, 'ssh', () => { demo++; }, rdp, ssh);
  assert.deepEqual(rdpIds, [record.id]); assert.deepEqual(sshIds, [record.id]); assert.equal(demo, 4);
});
