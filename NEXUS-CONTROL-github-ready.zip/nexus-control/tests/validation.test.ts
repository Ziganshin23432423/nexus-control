import { test } from 'node:test';
import assert from 'node:assert/strict';
import { isValidIpv4, isValidHostname, isValidAddress, isValidMac, normalizeMac, isValidPort, isValidUsername, validateComputerDraft, validateStoredComputer } from '../src/shared/validation.js';
import { draft, record } from './fixtures.js';
test('IPv4 rejects ambiguous, truncated and out-of-range addresses', () => {
  for (const value of ['0.0.0.0','192.168.1.25','255.255.255.255']) assert.ok(isValidIpv4(value));
  for (const value of ['256.1.1.1','192.168.01.1','1.2.3','-1.2.3.4','1.2.3.4:3389','1.2.3.4\n']) assert.equal(isValidIpv4(value), false, value);
});
test('Hostname and address validation excludes command characters and malformed IP fallback', () => {
  for (const value of ['MAIN-PC','home.local','a','a-b.example']) assert.ok(isValidHostname(value));
  for (const value of ['-home','home-','home..local','a'.repeat(64),'256.1.1.1','127.1','1.2.3.4;cmd','ssh://host','host:22','$(cmd)','host name','host\n']) assert.equal(isValidAddress(value), false, value);
  assert.ok(isValidAddress('192.168.1.25')); assert.equal(isValidHostname('a.'.repeat(130)), false);
});
test('MAC validates both formats, normalizes and rejects mixed separators', () => {
  assert.ok(isValidMac('aa-bb-cc-dd-ee-ff')); assert.ok(isValidMac('AA:BB:CC:DD:EE:FF'));
  assert.equal(normalizeMac(' aa-bb-cc-dd-ee-ff '), 'AA:BB:CC:DD:EE:FF');
  for (const value of ['AA:BB-CC:DD:EE:FF','AA:BB:CC:DD:EE','GG:BB:CC:DD:EE:FF','AABBCCDDEEFF']) { assert.equal(isValidMac(value), false); assert.equal(normalizeMac(value), null); }
});
test('Port and username boundaries', () => {
  for (const value of [1,9,65535]) assert.ok(isValidPort(value));
  for (const value of [0,65536,1.5,NaN,'9',null]) assert.equal(isValidPort(value), false);
  for (const value of ['user','DOMAIN\\user','user@example.com','Иван','user-name']) assert.ok(isValidUsername(value), value);
  for (const value of ['','-option','user;cmd','a b','user@host:22','a\\b\\c','a'.repeat(129),'user\n']) assert.equal(isValidUsername(value), false, value);
});
test('Draft normalization produces only the shared configuration', () => {
  const result = validateComputerDraft({ ...draft, name: ' PC HOME ', remoteAddress: '', username: ' zigan ', notes: 'строка\nстрока' });
  assert.ok(result.ok); assert.equal(result.value.name, 'PC HOME'); assert.equal(result.value.remoteAddress, null); assert.equal(result.value.macAddress, 'AA:BB:CC:DD:EE:FF');
  assert.ok(validateComputerDraft({ ...draft, hostname: '', sshEnabled: false, username: null, wakeOnLan: null, macAddress: null }).ok);
});
test('Draft rejects untrusted values, secrets and cross-field inconsistencies', () => {
  const invalid: unknown[] = [null, [], {}, { ...draft, password: 'secret' }, { ...draft, id: record.id }, { ...draft, createdAt: record.createdAt }, { ...draft, operatingSystem: 'linux' }, { ...draft, rdpEnabled: 'true' }, { ...draft, username: null }, { ...draft, macAddress: null }, { ...draft, hostname: '-host' }, { ...draft, localAddress: 'host & cmd' }, { ...draft, remoteAddress: '999.1.1.1' }, { ...draft, wakeOnLan: { broadcastAddress: 'home', port: 9 } }, { ...draft, wakeOnLan: { broadcastAddress: '192.168.1.255', port: '9' } }, { ...draft, wakeOnLan: { ...draft.wakeOnLan, password: 'secret' } }, { ...draft, name: 'a'.repeat(65) }, { ...draft, notes: 'a'.repeat(2001) }, { ...draft, name: 'bad\u0000name' }];
  for (const value of invalid) assert.equal(validateComputerDraft(value).ok, false, JSON.stringify(value));
});
test('Stored record requires canonical main IDs, timestamps and no unknown fields', () => {
  assert.ok(validateStoredComputer(record).ok);
  for (const value of [{ ...record, id: 'demo-pc-home' }, { ...record, password: '' }, { ...record, createdAt: 'bad' }, { ...record, updatedAt: '2025-01-01T00:00:00.000Z' }, { ...record, updatedAt: '2026-10-01' }]) assert.equal(validateStoredComputer(value).ok, false);
});
