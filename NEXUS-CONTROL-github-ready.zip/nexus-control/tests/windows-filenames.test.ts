import assert from 'node:assert/strict';
import test from 'node:test';
import { readdirSync, readFileSync } from 'node:fs';
import { join, relative } from 'node:path';

const ignored = new Set(['node_modules', 'out', 'dist', 'release', 'coverage', '.test-out', '.smoke-out', '.git']);
function projectFiles(directory: string): string[] {
  return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    if (ignored.has(entry.name) || entry.isSymbolicLink()) return [];
    const path = join(directory, entry.name);
    return entry.isDirectory() ? [relative(process.cwd(), path).replaceAll('\\', '/'), ...projectFiles(path)] : [relative(process.cwd(), path).replaceAll('\\', '/')];
  });
}
function assertUniqueKeys(files: readonly string[], key: (path: string) => string): void {
  const seen = new Map<string, string>();
  for (const file of files) {
    const normalized = key(file);
    assert.equal(seen.has(normalized), false, `Windows resolution collision: ${seen.get(normalized)} / ${file}`);
    seen.set(normalized, file);
  }
}
test('Project paths remain unique on a Windows case-insensitive filesystem', () => {
  assertUniqueKeys(projectFiles(process.cwd()), path => path.toLowerCase());
});
test('Source module stems cannot collide across case or TS/TSX extensions', () => {
  const files = projectFiles(process.cwd()).filter(path => /^(src|tests)\//.test(path) && /\.(tsx?|jsx?)$/.test(path));
  assertUniqueKeys(files, path => path.replace(/\.(tsx?|jsx?)$/, '').toLowerCase());
  // Exercise the specific Windows Vite/esbuild failure, not merely literal filenames.
  assert.throws(() => assertUniqueKeys(['appearance/Starfield.tsx', 'appearance/starfield.ts'], path => path.replace(/\.tsx?$/, '').toLowerCase()), /collision/);
});
test('Starfield component and tests explicitly resolve the renamed engine', () => {
  assert.ok(readFileSync('src/renderer/appearance/starfieldEngine.ts', 'utf8').includes('export class StarfieldEngine'));
  for (const file of ['src/renderer/appearance/Starfield.tsx', 'tests/appearance.test.ts']) {
    const source = readFileSync(file, 'utf8');
    assert.match(source, /from ['"][^'"]*starfieldEngine(?:\.js)?['"]/);
    assert.doesNotMatch(source, /from ['"][^'"]*\/starfield(?:\.js)?['"]/);
  }
});
