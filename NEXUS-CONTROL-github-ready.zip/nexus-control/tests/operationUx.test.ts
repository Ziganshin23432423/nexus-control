import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { AppErrorBoundary } from '../src/renderer/components/AppErrorBoundary.js';
import { ERROR_PRESENTATIONS, SUCCESS_TITLES, presentError, progressLabel, remainingSeconds, removeProgress, safeTechnicalDetails, ToastDeduplicator, capabilityActions } from '../src/renderer/state/operationUx.js';
import { record } from './fixtures.js';

test('Every typed failure has short actionable UX; no raw exceptions or paths', () => {
  assert.equal(Object.keys(ERROR_PRESENTATIONS).length, 27);
  for (const ux of Object.values(ERROR_PRESENTATIONS)) { assert.ok(ux.title.length > 5); assert.ok(ux.description.length > 10); assert.doesNotMatch(ux.title + ux.description, /ECONN|stack|System32|Error:/); }
  assert.match(presentError('RDP_UNAVAILABLE').description, /удалённый рабочий стол/);
  assert.match(presentError('SSH_CLIENT_MISSING').description, /OpenSSH Client/);
});
test('Success acknowledges launch or send only, never login or power-on', () => {
  assert.deepEqual(SUCCESS_TITLES, {rdp: 'RDP-клиент открыт', ssh: 'SSH-терминал открыт', wake: 'Magic Packet отправлен'});
  for (const title of Object.values(SUCCESS_TITLES)) assert.doesNotMatch(title, /подключён|подключено|включён|авторизован/i);
});
test('Retry is explicit for temporary failures, absent for missing components, disabled, unsupported, busy and cancelled', () => {
  for (const code of ['WAKE_CONNECT_TIMEOUT','WOL_SEND_ERROR','WOL_TIMEOUT','NETWORK_ERROR','RDP_UNAVAILABLE','SSH_UNAVAILABLE'] as const) assert.equal(presentError(code).retry,true);
  for (const code of ['CANCELLED','SSH_CLIENT_MISSING','RDP_CLIENT_MISSING','WOL_DISABLED','WAKE_CONNECT_BUSY','RDP_UNSUPPORTED'] as const) assert.equal(presentError(code).retry,false);
});
test('Countdown clamps, rounds, avoids invented duration, formats all fixed phases', () => {
  assert.equal(remainingSeconds(-4),0); assert.equal(remainingSeconds(100),90); assert.equal(remainingSeconds(1.1),2); assert.equal(remainingSeconds(NaN),null);
  assert.equal(progressLabel({computerId:'id',service:'rdp',phase:'waiting',remainingSeconds:73}), 'Ожидание RDP · 73 сек');
  assert.equal(progressLabel({computerId:'id',service:'ssh',phase:'waiting',remainingSeconds:-1}), 'Ожидание SSH · 0 сек');
  assert.equal(progressLabel({computerId:'id',service:'ssh',phase:'sending'}), 'Отправка сигнала…');
  assert.equal(progressLabel({computerId:'id',service:'rdp',phase:'launching'}), 'Открываем клиент…');
});
test('Completion cleanup removes countdown without removing independent computer operation', () => {
  const jobs = {one:{remainingSeconds:73},two:{remainingSeconds:21}};
  const next = removeProgress(jobs,'one'); assert.deepEqual(next,{two:{remainingSeconds:21}}); assert.ok('one' in jobs);
  assert.deepEqual(removeProgress(next,'two'),{});
});
test('Identical toast spam is suppressed; independent messages and later explicit retry allowed', () => {
  const gate = new ToastDeduplicator(); assert.equal(gate.accept('error','help','error',0),true); assert.equal(gate.accept('error','help','error',100),false);
  assert.equal(gate.accept('other','help','error',100),true); assert.equal(gate.accept('error','help','error',4500),true);
  gate.clear(); assert.equal(gate.accept('error','help','error',4501),true);
});
for (const [rdp,ssh,wol,expected] of [
  [true,false,false,['rdp']], [false,true,false,['ssh']], [false,false,true,['wake']],
  [true,false,true,['rdp','wake','wake-rdp']], [false,true,true,['ssh','wake','wake-ssh']],
  [true,true,true,['rdp','ssh','wake','wake-rdp','wake-ssh']], [false,false,false,[]],
] as const) test(`Capabilities RDP=${rdp} SSH=${ssh} WoL=${wol}`, () => { assert.deepEqual(capabilityActions({...record,rdpEnabled:rdp,sshEnabled:ssh,wakeOnLan:wol?record.wakeOnLan:null}),expected); });
test('Missing MAC makes wake actions unavailable even for malformed imported capability', () => assert.deepEqual(capabilityActions({...record,macAddress:null}),['rdp','ssh']));
test('Actual Error Boundary renders safe branded fallback after failure, hides child and stack', () => {
  const boundary = new AppErrorBoundary({children:createElement('div',null,'private renderer')});
  boundary.state = AppErrorBoundary.getDerivedStateFromError();
  const html = renderToStaticMarkup(boundary.render()); assert.match(html,/NEXUS CONTROL/); assert.match(html,/Перезапустить интерфейс/); assert.doesNotMatch(html,/private renderer|stack|Error:/);
});
test('Technical details whitelist excludes extra secrets, paths, stack and config dumps', () => {
  const input = {code:'RDP_UNAVAILABLE' as const,service:'rdp' as const,addressKind:'remote' as const,timestamp:'2026-10-01T00:00:00.000Z',version:'0.1.0',password:'SECRET',stack:'PRIVATE',config:{username:'LEAK'},path:'C:\\secret'};
  const details=safeTechnicalDetails(input); assert.match(details,/RDP_UNAVAILABLE/); assert.match(details,/remote/); assert.doesNotMatch(details,/SECRET|PRIVATE|LEAK|secret|username/);
  assert.doesNotMatch(safeTechnicalDetails({...input,version:'SECRET',timestamp:'PRIVATE'}),/SECRET|PRIVATE/);
});
