// Test-only entry: unchanged production main, then explicit local UDP DI phase.
// No application test flags or renderer harness API. All UDP is own loopback.
const {ipcMain,BrowserWindow}=require('electron');
const {readFileSync}=require('node:fs');
const {pathToFileURL}=require('node:url');
const {createSocket}=require('node:dgram');
let state,server,service,handler,main;
globalThis.__nexusWolQa={
 async install({project,file}){
  const load=relative=>import(pathToFileURL(project+'/.test-out/'+relative).href);
  const {ComputerStore}=await load('src/main/services/computerStore.js');
  const {WakeOnLanService}=await load('src/main/services/wakeOnLanService.js');
  const {UdpWakeOnLanProvider}=await load('src/main/providers/UdpWakeOnLanProvider.js');
  const {createWakeRequestHandler}=await load('src/main/ipc/wakeRequest.js');
  const {isTrustedIpcSender}=await load('src/main/ipc/trustedSender.js');
  state={hold:false,fail:false,release:null,ipc:0,created:0,closed:0,active:0,sends:[],received:[]};
  server=createSocket('udp4');server.on('message',packet=>state.received.push([...packet]));
  await new Promise((resolve,reject)=>{server.once('error',reject);server.bind(0,'127.0.0.1',()=>{server.removeListener('error',reject);resolve();});});
  const port=server.address().port;
  const deps={socketFactory:()=>{
   const socket=createSocket('udp4');state.created++;state.active++;
   socket.once('close',()=>{state.closed++;state.active--;});
   return {
    onError:cb=>{socket.on('error',cb);return()=>socket.removeListener('error',cb);},
    onClose:cb=>{socket.once('close',cb);return()=>socket.removeListener('close',cb);},
    bind:(p,cb)=>{if(p!==0)throw new Error('ephemeral only');socket.bind(p,'127.0.0.1',()=>{if(state.hold)state.release=cb;else cb();});},
    setBroadcast:value=>{if(value!==true)throw new Error('broadcast required');socket.setBroadcast(value);},
    send:(packet,p,address,cb)=>{
     if(address!=='127.0.0.1'||p!==port)throw new Error('QA refuses non-local target');
     state.sends.push({packet:[...packet],port:p,address});
     if(state.fail){queueMicrotask(()=>cb(new Error('injected failure')));return;}
     socket.send(packet,p,address,cb);
    },
    close:()=>socket.close()
   };
  },schedule:(cb,ms)=>{const timer=setTimeout(cb,ms);return()=>clearTimeout(timer);}};
  const store=new ComputerStore({read:()=>JSON.parse(readFileSync(file,'utf8')).configuration,write:()=>{throw new Error('QA must never write');}});
  service=new WakeOnLanService(store,new UdpWakeOnLanProvider(deps));
  main=BrowserWindow.getAllWindows()[0];const url=main.webContents.getURL();
  handler=createWakeRequestHandler(event=>{if(!isTrustedIpcSender(event,main,url))throw new Error('untrusted');},service);
  ipcMain.removeHandler('nexus:wol:wake-computer');ipcMain.handle('nexus:wol:wake-computer',(event,...args)=>{state.ipc++;return handler(event,...args);});
  main.once('closed',()=>{service.cancelPending();server.close();});return port;
 },
 configure(values){for(const key of ['hold','fail'])if(key in values)state[key]=values[key];},
 snapshot(){return {ipc:state.ipc,created:state.created,closed:state.closed,active:state.active,sends:state.sends,received:state.received};},
 release(){state.hold=false;const cb=state.release;state.release=null;if(cb)cb();},
 extra(id,extra){return handler({sender:main.webContents,senderFrame:main.webContents.mainFrame},id,extra);}
};
import('../out/main/main.js').catch(error=>{console.error(error);process.exitCode=1;});
