import assert from 'node:assert/strict';
import test from 'node:test';
import { WakeAndConnectService } from '../src/main/services/wakeAndConnectService.js';
import { WakeOnLanService } from '../src/main/services/wakeOnLanService.js';
import { RemoteDesktopService } from '../src/main/services/remoteDesktopService.js';
import { SshTerminalService } from '../src/main/services/sshTerminalService.js';
import { CheckCoordinator } from '../src/main/services/checkCoordinator.js';
import { NetworkService, CheckCancelledError } from '../src/main/services/networkService.js';
import { ComputerStoreError } from '../src/main/services/computerStore.js';
import { WakeOnLanError } from '../src/main/services/wakeOnLanError.js';
import { RdpError } from '../src/main/services/rdpError.js';
import { SshError } from '../src/main/services/sshError.js';
import { createWakeAndConnectRequestHandler } from '../src/main/ipc/wakeAndConnectRequest.js';
import { isTrustedIpcSender } from '../src/main/ipc/trustedSender.js';
import { performComputerAction } from '../src/renderer/state/computerActions.js';
import type { Computer, WakeAndConnectProgress } from '../src/shared/types.js';
import type { PlatformProviders, WakeOnLanRequest } from '../src/main/providers/contracts.js';
import type { WorkflowClock } from '../src/main/services/workflowClock.js';
import type { TcpProbe, TcpProbeResult } from '../src/main/services/tcpProbe.js';
import { record } from './fixtures.js';
const ready: TcpProbeResult = { status:'ready',latencyMs:1,errorCode:null };
const unavailable: TcpProbeResult = { status:'unavailable',latencyMs:null,errorCode:'ECONNREFUSED' };
const code=(expected:string)=>(error:unknown)=>(expected==='CANCELLED'&&error instanceof CheckCancelledError)||typeof error==='object'&&error!==null&&'code' in error&&error.code===expected;
async function tick(){for(let i=0;i<30;i++)await Promise.resolve();}
class Clock implements WorkflowClock {
 time=0;next=0;timers=new Map<number,{due:number;callback:()=>void;ms:number}>();
 now=()=>this.time;
 schedule=(callback:()=>void,ms:number)=>{const id=++this.next;this.timers.set(id,{due:this.time+ms,callback,ms});return()=>{this.timers.delete(id);};};
 async advance(ms:number){const end=this.time+ms;while(true){const next=[...this.timers].filter(([,t])=>t.due<=end).sort((a,b)=>a[1].due-b[1].due)[0];if(!next)break;this.time=next[1].due;this.timers.delete(next[0]);next[1].callback();await tick();}this.time=end;await tick();}
}
function setup(computer:Computer=record,probe:TcpProbe=async()=>ready){
 const records=new Map([[computer.id,computer]]);const clock=new Clock();const slots=new Map<string,AbortController>();const claims=new Set<string>();
 const store={get:(id:unknown)=>{const item=records.get(String(id));if(!item)throw new ComputerStoreError('NOT_FOUND','missing');return structuredClone(item);},list:()=>[...records.values()]};
 const checks=new CheckCoordinator(store,new NetworkService(probe));const wakeCalls:WakeOnLanRequest[]=[];const launches:{service:string;host:string}[]=[];let wakeFail=false;let launchFail=false;
 const providers:PlatformProviders={wakeOnLan:{id:'mock',send:async req=>{wakeCalls.push(req);if(wakeFail)throw new WakeOnLanError('WOL_SEND_ERROR','wake failed');}},remoteDesktop:{id:'mock',open:async req=>{launches.push({service:'rdp',host:req.host});if(launchFail)throw new RdpError('RDP_LAUNCH_ERROR','launch failed');}},ssh:{id:'mock',open:async req=>{launches.push({service:'ssh',host:req.host});if(launchFail)throw new SshError('SSH_LAUNCH_ERROR','launch failed');}}};
 const wake=new WakeOnLanService(store,providers.wakeOnLan,claims);const rdp=new RemoteDesktopService(store,checks,providers.remoteDesktop,slots);const ssh=new SshTerminalService(store,checks,providers.ssh,slots);const progress:WakeAndConnectProgress[]=[];
 const flow=new WakeAndConnectService(store,checks,wake,rdp,ssh,providers,slots,claims,clock,p=>progress.push(p));
 return{flow,wake,rdp,ssh,checks,providers,store,clock,slots,claims,records,wakeCalls,launches,progress,setWakeFail:(v:boolean)=>{wakeFail=v;},setLaunchFail:(v:boolean)=>{launchFail=v;}};
}
function heldProbe(onStart:()=>void=()=>{}):TcpProbe{return(_address,_service,signal)=>new Promise((resolve)=>{onStart();const abort=()=>{signal?.removeEventListener('abort',abort);resolve({status:'unavailable',latencyMs:null,errorCode:'CANCELLED'});};signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();});}
for(const kind of ['rdp','ssh'] as const){
 const start=(ctx:ReturnType<typeof setup>,id:unknown=record.id)=>kind==='rdp'?ctx.flow.openRdp(id):ctx.flow.openSsh(id);
 test(kind+' workflow validates IDs, missing computer, corrupt records and Windows target before wake',async()=>{
  const ctx=setup();for(const id of ['bad',null,{},'demo-main-pc'])await assert.rejects(start(ctx,id),code('VALIDATION_ERROR'));await assert.rejects(start(ctx,'ffffffff-ffff-4fff-8fff-ffffffffffff'),code('NOT_FOUND'));
  for(const comp of [{...record,name:''},{...record,localAddress:'host;cmd'},{...record,macAddress:'invalid'},{...record,wakeOnLan:{broadcastAddress:'evil',port:9}},{...record,wakeOnLan:{broadcastAddress:'192.168.1.255',port:0}}]){const bad=setup(comp);await assert.rejects(start(bad),code('VALIDATION_ERROR'));assert.equal(bad.wakeCalls.length,0);}
  const linux=setup({...record,operatingSystem:'linux'});await assert.rejects(start(linux),code('WAKE_CONNECT_UNSUPPORTED'));assert.equal(linux.wakeCalls.length,0);
 });
 test(kind+' workflow rejects disabled WoL/service and unsupported host before side effects',async()=>{
  for(const comp of [{...record,wakeOnLan:null},{...record,wakeOnLan:null,macAddress:null}])await assert.rejects(start(setup(comp)),code('WOL_DISABLED'));
  const disabled=setup({...record,[kind==='rdp'?'rdpEnabled':'sshEnabled']:false});await assert.rejects(start(disabled),code(kind==='rdp'?'RDP_DISABLED':'SSH_DISABLED'));
  const ctx=setup();for(const providers of [{...ctx.providers,wakeOnLan:null},{...ctx.providers,[kind==='rdp'?'remoteDesktop':'ssh']:null}]){const flow=new WakeAndConnectService(ctx.store,ctx.checks,ctx.wake,ctx.rdp,ctx.ssh,providers,ctx.slots,ctx.claims,ctx.clock);await assert.rejects(kind==='rdp'?flow.openRdp(record.id):flow.openSsh(record.id),code('WAKE_CONNECT_UNSUPPORTED'));}assert.equal(ctx.wakeCalls.length,0);
 });
 test(kind+' workflow wake failure stops before checks and can retry',async()=>{
  let probes=0;const ctx=setup(record,async()=>{probes++;return ready;});ctx.setWakeFail(true);await assert.rejects(start(ctx),code('WOL_SEND_ERROR'));assert.equal(probes,0);assert.equal(ctx.launches.length,0);assert.equal(ctx.slots.size,0);assert.equal(ctx.clock.timers.size,0);ctx.setWakeFail(false);await start(ctx);assert.equal(probes,2);assert.equal(ctx.launches.length,1);
 });
 test(kind+' unavailable checks sequentially wait 2000ms; eventually ready launches with final fresh check',async()=>{
  let calls=0,active=0,max=0;const seen:string[]=[];const ctx=setup(record,async(_address,service)=>{active++;max=Math.max(max,active);seen.push(service);calls++;await Promise.resolve();active--;return calls<=2?unavailable:ready;});const pending=start(ctx);await tick();assert.equal(calls,1);assert.ok([...ctx.clock.timers.values()].some(t=>t.ms===2000));await ctx.clock.advance(1999);assert.equal(calls,1);await ctx.clock.advance(1);assert.equal(calls,2);await ctx.clock.advance(2000);const result=await pending;
  assert.equal(calls,4);assert.equal(max,1);assert.deepEqual(seen,[kind,kind,kind,kind]);assert.equal(ctx.wakeCalls.length,1);assert.equal(ctx.launches.length,1);assert.equal(result.wakeSent,true);assert.equal(result.waitedMs,4000);assert.equal(result.state,kind==='rdp'?'client-opened':'terminal-opened');assert.deepEqual(ctx.progress.map(p=>p.phase).filter((phase,index,all)=>index===0||phase!==all[index-1]),['sending','waiting','launching']);assert.equal(ctx.clock.timers.size,0);assert.equal(ctx.slots.size,0);await ctx.clock.advance(100000);assert.equal(calls,4);
 });
 test(kind+' local success and remote fallback reuse NetworkService selection on wait AND fresh launch',async()=>{
  for(const fallback of [false,true]){const seen:string[]=[];const ctx=setup({...record,remoteAddress:'10.0.0.25'},async address=>{seen.push(address);return fallback&&address===record.localAddress?unavailable:ready;});await start(ctx);assert.deepEqual(seen,fallback?[record.localAddress,'10.0.0.25',record.localAddress,'10.0.0.25']:[record.localAddress,record.localAddress]);assert.equal(ctx.launches[0]?.host,fallback?'10.0.0.25':record.localAddress);}
 });
 test(kind+' WAIT ready never bypasses final unavailable check or launch error; retry releases ownership',async()=>{
  let calls=0;const ctx=setup(record,async()=>++calls%2===1?ready:unavailable);await assert.rejects(start(ctx),code(kind==='rdp'?'RDP_UNAVAILABLE':'SSH_UNAVAILABLE'));assert.equal(ctx.launches.length,0);assert.equal(ctx.slots.size,0);
  const fail=setup();fail.setLaunchFail(true);await assert.rejects(start(fail),code(kind==='rdp'?'RDP_LAUNCH_ERROR':'SSH_LAUNCH_ERROR'));assert.equal(fail.clock.timers.size,0);fail.setLaunchFail(false);await start(fail);assert.equal(fail.launches.length,2);
 });
 test(kind+' deadline exactly 90 seconds aborts in-flight check, clears timers and permits retry',async()=>{
  let holding=true;const ctx=setup(record,(...args)=>holding?heldProbe()(...args):Promise.resolve(ready));const pending=assert.rejects(start(ctx),code('WAKE_CONNECT_TIMEOUT'));await tick();await ctx.clock.advance(89999);assert.equal(ctx.slots.size,1);await ctx.clock.advance(1);await pending;assert.equal(ctx.launches.length,0);assert.equal(ctx.clock.timers.size,0);assert.equal(ctx.slots.size,0);holding=false;await start(ctx);assert.equal(ctx.launches.length,1);
 });
 test(kind+' cancel during TCP check/delay and shutdown stops checks and cleans ownership, retry works',async()=>{
  for(const phase of ['check','delay','shutdown']){let unavailableMode=true;let calls=0;const probe:TcpProbe=(...args)=>{calls++;return unavailableMode?(phase==='delay'?Promise.resolve(unavailable):heldProbe()(...args)):Promise.resolve(ready);};const ctx=setup(record,probe);const pending=assert.rejects(start(ctx),code('CANCELLED'));await tick();if(phase==='shutdown')ctx.flow.cancelAll();else assert.equal(ctx.flow.cancel(record.id).cancelled,true);await pending;const count=calls;await ctx.clock.advance(100000);assert.equal(calls,count);assert.equal(ctx.launches.length,0);assert.equal(ctx.clock.timers.size,0);assert.equal(ctx.claims.size,0);assert.equal(ctx.slots.size,0);unavailableMode=false;await start(ctx);assert.equal(ctx.launches.length,1);}
 });
 test(kind+' deadline includes repeated attempts and pauses, not 90 seconds of delay alone',async()=>{
  let probes=0;const ctx=setup(record,async()=>{probes++;ctx.clock.time+=1000;return unavailable;});const pending=assert.rejects(start(ctx),code('WAKE_CONNECT_TIMEOUT'));await tick();await ctx.clock.advance(90000);await pending;assert.ok(probes<45);assert.equal(ctx.launches.length,0);assert.equal(ctx.clock.timers.size,0);
 });
 test(kind+' external edit/delete during wait cancels without stale launch or extra burst',async()=>{
  for(const deleted of [false,true]){const ctx=setup(record,async()=>unavailable);const pending=assert.rejects(start(ctx),code('CANCELLED'));await tick();if(deleted)ctx.records.delete(record.id);else ctx.records.set(record.id,{...record,localAddress:'10.0.0.99'});await ctx.clock.advance(2000);await pending;assert.equal(ctx.launches.length,0);assert.equal(ctx.wakeCalls.length,1);assert.equal(ctx.clock.timers.size,0);assert.equal(ctx.slots.size,0);}
 });
 test(kind+' cancellation during final fresh check cannot spawn and still clears workflow claim',async()=>{
  let calls=0;const ctx=setup(record,(...args)=>++calls===1?Promise.resolve(ready):heldProbe()(...args));const pending=assert.rejects(start(ctx),code('CANCELLED'));await tick();assert.equal(calls,2);ctx.flow.cancel(record.id);await pending;assert.equal(ctx.launches.length,0);assert.equal(ctx.slots.size,0);
 });
}
test('SSH missing/hostile username is validated before UDP/check/native launch',async()=>{
 for(const username of [null,'user;cmd','-flag','user name']){const ctx=setup({...record,username});await assert.rejects(ctx.flow.openSsh(record.id),code('VALIDATION_ERROR'));assert.equal(ctx.wakeCalls.length,0);assert.equal(ctx.launches.length,0);}
});
test('Shared ownership blocks duplicate/mixed workflows and direct RDP/SSH/WoL for same ID; releases afterwards',async()=>{
 let hold=true;const ctx=setup(record,(...args)=>hold?heldProbe()(...args):Promise.resolve(ready));const pending=assert.rejects(ctx.flow.openRdp(record.id),code('CANCELLED'));await tick();
 await assert.rejects(ctx.flow.openRdp(record.id),code('WAKE_CONNECT_BUSY'));await assert.rejects(ctx.flow.openSsh(record.id),code('WAKE_CONNECT_BUSY'));await assert.rejects(ctx.rdp.open(record.id),code('RDP_BUSY'));await assert.rejects(ctx.ssh.open(record.id),code('SSH_BUSY'));await assert.rejects(ctx.wake.wake(record.id),code('WOL_BUSY'));assert.equal(ctx.wakeCalls.length,1);assert.equal(ctx.launches.length,0);
 ctx.flow.cancel(record.id);await pending;hold=false;await ctx.rdp.open(record.id);await ctx.ssh.open(record.id);await ctx.wake.wake(record.id);assert.equal(ctx.launches.length,2);assert.equal(ctx.claims.size,0);
});
test('Direct launch already owning ID prevents workflow from waking; different IDs remain independent',async()=>{
 let hold=true;const ctx=setup(record,(...args)=>hold?heldProbe()(...args):Promise.resolve(ready));const direct=assert.rejects(ctx.rdp.open(record.id),code('CANCELLED'));await tick();await assert.rejects(ctx.flow.openSsh(record.id),code('WAKE_CONNECT_BUSY'));assert.equal(ctx.wakeCalls.length,0);
 const other={...record,id:'22222222-2222-4222-8222-222222222222'};ctx.records.set(other.id,other);hold=false;await ctx.flow.openSsh(other.id);assert.equal(ctx.launches.length,1);ctx.rdp.cancelPending();await direct;
});
test('Two workflows for different IDs can wait and cancel independently',async()=>{
 const ctx=setup(record,heldProbe());const other={...record,id:'22222222-2222-4222-8222-222222222222'};ctx.records.set(other.id,other);const a=assert.rejects(ctx.flow.openRdp(record.id),code('CANCELLED'));const b=assert.rejects(ctx.flow.openSsh(other.id),code('CANCELLED'));await tick();assert.equal(ctx.slots.size,2);ctx.flow.cancel(record.id);await a;assert.equal(ctx.slots.size,1);ctx.flow.cancel(other.id);await b;assert.equal(ctx.clock.timers.size,0);
});
test('Owned final launch rejects foreign controller and changed config, never leaves partial ownership',async()=>{
 const ctx=setup();const controller=new AbortController();for(const launch of [ctx.rdp,ctx.ssh])await assert.rejects(launch.openOwned(record.id,{controller,computer:record}),code('CANCELLED'));
 ctx.slots.set(record.id,controller);ctx.records.set(record.id,{...record,name:'edited'});for(const launch of [ctx.rdp,ctx.ssh])await assert.rejects(launch.openOwned(record.id,{controller,computer:record}),code('CANCELLED'));assert.equal(ctx.launches.length,0);ctx.slots.delete(record.id);
});
test('Cancel after successful client ACK is a no-op and never closes a native session',async()=>{
 const ctx=setup();await ctx.flow.openSsh(record.id);assert.deepEqual(ctx.flow.cancel(record.id),{computerId:record.id,cancelled:false});assert.equal(ctx.launches.length,1);ctx.flow.cancelAll();assert.equal(ctx.launches.length,1);
});
test('All three workflow IPC operations enforce sender and ID-only arguments including cancel',async()=>{
 const frame={url:'nexus://app/index.html'},contents={mainFrame:frame},window={isDestroyed:()=>false,webContents:contents},event={sender:contents,senderFrame:frame};
 const ctx=setup();const operations: Array<(id: unknown) => unknown> = [(id:unknown)=>ctx.flow.openRdp(id),(id:unknown)=>ctx.flow.openSsh(id),(id:unknown)=>ctx.flow.cancel(id)];
 for(const operation of operations){const handler=createWakeAndConnectRequestHandler((candidate:{sender:unknown;senderFrame:{url:string}|null})=>{if(!isTrustedIpcSender(candidate,window,frame.url))throw new Error('untrusted');},operation);
  for(const bad of [{...event,sender:{}},{...event,senderFrame:{...frame}},{...event,senderFrame:{url:'https://evil'}},{...event,senderFrame:null}])await assert.rejects(handler(bad,record.id),/untrusted/);
  for(const id of [{id:record.id,host:'evil',mac:'bad',port:1,timeout:1,action:'cmd'},'bad',null]){const result=await handler(event,id);assert.equal(result.ok,false);if(!result.ok)assert.equal(result.error.code,'VALIDATION_ERROR');}
  const extra=await handler(event,record.id,{timeout:1,protocol:'custom'});assert.equal(extra.ok,false);if(!extra.ok)assert.equal(extra.error.code,'VALIDATION_ERROR');
 }
 assert.equal(ctx.wakeCalls.length,0);assert.equal(ctx.launches.length,0);
});
test('Workflow IPC maps unexpected/storage/cancel/timeout errors without secret leakage',async()=>{
 for(const [error,expected] of [[new Error('secret'),'NETWORK_ERROR'],[new SyntaxError('secret'),'STORAGE_ERROR'],[new CheckCancelledError(),'CANCELLED']] as const){const handler=createWakeAndConnectRequestHandler(()=>{},()=>{throw error;});const result=await handler({},record.id);assert.equal(result.ok,false);if(!result.ok){assert.equal(result.error.code,expected);assert.ok(!result.error.message.includes('secret'));}}
});
test('DEMO combined RDP and SSH always dispatch mock first, USER actions forward only saved ID',()=>{
 const calls:string[]=[];for(const action of ['wake-rdp','wake-ssh'] as const){performComputerAction(true,record,action,()=>calls.push('demo'),()=>assert.fail(),()=>assert.fail(),()=>assert.fail(),()=>assert.fail(),()=>assert.fail());}
 for(const action of ['wake-rdp','wake-ssh'] as const)performComputerAction(false,record,action,()=>assert.fail(),()=>assert.fail(),()=>assert.fail(),()=>assert.fail(),id=>calls.push('rdp:'+id),id=>calls.push('ssh:'+id));assert.deepEqual(calls,['demo','demo','rdp:'+record.id,'ssh:'+record.id]);
});
test('Cancellation while WoL is sending aborts its shared signal and never starts TCP polling',async()=>{
 const ctx=setup();let signal:AbortSignal|undefined;let release=()=>{};
 const wake=new WakeOnLanService(ctx.store,{id:'held-wake',send:async req=>{signal=req.signal;await new Promise<void>(resolve=>{release=resolve;req.signal?.addEventListener('abort',()=>resolve(),{once:true});});}},ctx.claims);
 const flow=new WakeAndConnectService(ctx.store,ctx.checks,wake,ctx.rdp,ctx.ssh,ctx.providers,ctx.slots,ctx.claims,ctx.clock);
 const pending=assert.rejects(flow.openRdp(record.id),code('CANCELLED'));await tick();flow.cancel(record.id);release();await pending;assert.equal(signal?.aborted,true);assert.equal(ctx.clock.timers.size,0);assert.equal(ctx.launches.length,0);assert.equal(ctx.slots.size,0);
});
test('Original deadline also aborts final fresh check; no native launch even after WAIT READY',async()=>{
 let calls=0;const ctx=setup(record,(...args)=>++calls===1?Promise.resolve(ready):heldProbe()(...args));const pending=assert.rejects(ctx.flow.openSsh(record.id),code('WAKE_CONNECT_TIMEOUT'));await tick();assert.equal(calls,2);await ctx.clock.advance(90000);await pending;assert.equal(ctx.launches.length,0);assert.equal(ctx.clock.timers.size,0);
});
test('Edit between WAIT READY and final fresh completion is rejected by existing launch safety check',async()=>{
 let calls=0;let ctx:ReturnType<typeof setup>;ctx=setup(record,async()=>{calls++;if(calls===2)ctx.records.set(record.id,{...record,localAddress:'10.0.0.99'});return ready;});await assert.rejects(ctx.flow.openRdp(record.id),code('CANCELLED'));assert.equal(calls,2);assert.equal(ctx.launches.length,0);assert.equal(ctx.slots.size,0);
});

test('Main countdown starts after send ACK, ticks at 1Hz, clears after cancel and retry',async()=>{
 const ctx=setup(record,async()=>unavailable);const pending=assert.rejects(ctx.flow.openRdp(record.id),code('CANCELLED'));await tick();
 assert.equal(ctx.progress[0]?.remainingSeconds,undefined);assert.equal(ctx.progress[1]?.remainingSeconds,90);
 await ctx.clock.advance(17000);assert.equal(ctx.progress.at(-1)?.remainingSeconds,73);
 assert.equal(ctx.progress.filter(p=>p.phase==='waiting').length,18);
 ctx.flow.cancel(record.id);await pending;const count=ctx.progress.length;await ctx.clock.advance(100000);
 assert.equal(ctx.progress.length,count);assert.equal(ctx.clock.timers.size,0);
});
