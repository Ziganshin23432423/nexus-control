import assert from 'node:assert/strict';
import test from 'node:test';
import { readFileSync } from 'node:fs';
import { runWindowsReadiness, smokeExitCode, smokeSummary } from '../src/main/readiness/windowsReadiness.js';
import type { ReadinessDependencies, SmokeScenario } from '../src/main/readiness/windowsReadiness.js';
import { auditProject, filenameIssues, referenceIssues, archiveMemberIssues } from '../src/main/readiness/sourceAudit.js';
import { isTrustedWindowsDirectory } from '../src/main/providers/windows/trustedWindowsPath.js';
import { findWindowsRdpClient } from '../src/main/providers/windows/WindowsRdpProvider.js';
import { findWindowsSshClients } from '../src/main/providers/windows/windowsSshDiscovery.js';
const setup=(scenario:SmokeScenario='all'):ReadinessDependencies=>({platform:'win32',architecture:'x64',version:'0.1.0',scenario,environment:{SystemRoot:'C:\\Windows',LOCALAPPDATA:'C:\\Users\\Иван Петров\\AppData\\Local',PATH:'C:\\UNTRUSTED'},isFile:async()=>true,isAlias:async()=>true,sourceSafe:async()=>true,buildReady:async()=>true,userDataWritable:async()=>true,rendererStorage:async()=>true,udpLifecycle:async()=>true});
test('Readiness mappings: PASS, selected missing clients WARN, core failure FAIL',async()=>{
 const pass=await runWindowsReadiness(setup());assert.ok(pass.checks.every(row=>row.status==='PASS'));assert.equal(smokeExitCode(pass),0);
 const warn=await runWindowsReadiness({...setup(),isFile:async()=>false,isAlias:async()=>false});assert.equal(warn.checks.find(row=>row.id==='ssh')?.status,'WARN');assert.equal(smokeExitCode(warn),0);
 const fail=await runWindowsReadiness({...setup(),rendererStorage:async()=>{throw new Error('private environment');}});assert.equal(smokeExitCode(fail),1);assert.doesNotMatch(smokeSummary(fail),/private environment/);
});
test('Unused clients never warn; Console Host fallback and Terminal make the other host optional',async()=>{
 const app=await runWindowsReadiness({...setup('app'),environment:{},isFile:async()=>false,isAlias:async()=>false});assert.ok(app.checks.every(row=>row.status==='PASS'));
 const fallback=await runWindowsReadiness({...setup('ssh'),isAlias:async()=>false});assert.equal(fallback.checks.find(row=>row.id==='terminal')?.status,'PASS');
 const terminal=await runWindowsReadiness({...setup('ssh'),isFile:async path=>!path.endsWith('conhost.exe')});assert.equal(terminal.checks.find(row=>row.id==='conhost')?.status,'PASS');assert.ok(!terminal.checks.some(row=>/Server/.test(row.id)));
});
test('Linux is explicit FAIL host and never probes native clients or UDP',async()=>{
 const result=await runWindowsReadiness({...setup(),platform:'linux',isFile:async()=>assert.fail('Windows discovery'),isAlias:async()=>assert.fail('Windows alias'),udpLifecycle:async()=>assert.fail('UDP')});assert.equal(smokeExitCode(result),1);assert.match(smokeSummary(result),/не является проверкой Windows hardware/);
});
test('Diagnostic outputs exclude paths, usernames, secrets and raw exceptions',async()=>{
 const result=await runWindowsReadiness({...setup(),userDataWritable:async()=>{throw new Error('SECRET_PATH');}});const summary=JSON.stringify(result);for(const value of ['Иван','UNTRUSTED','SECRET_PATH','C:\\'])assert.ok(!summary.includes(value));
});
test('Trusted directories support Unicode and spaces, reject expansion, traversal and Windows aliases',async()=>{
 for(const value of ['C:\\Windows','D:\\Windows Folder','C:\\Users\\Иван Петров\\AppData\\Local'])assert.ok(isTrustedWindowsDirectory(value));
 for(const value of [undefined,'Windows','C:/Windows','C:\\Windows/../evil','C:\\Windows\\..\\evil','C:\\Windows.','C:\\Windows ','C:\\%ROOT%','C:\\Windows;evil','C:\\NUL','C:\\CON.txt','\\\\server\\share','C:\\Windows\\\\Other'])assert.equal(isTrustedWindowsDirectory(value),false,value);
 const root='D:\\Система Windows';assert.equal(await findWindowsRdpClient({SystemRoot:root,PATH:'unsafe'},async path=>{assert.equal(path,root+'\\System32\\mstsc.exe');return true;}),root+'\\System32\\mstsc.exe');
 const clients=await findWindowsSshClients({environment:{SystemRoot:root,LOCALAPPDATA:'C:\\Users\\Иван Петров\\AppData\\Local'},isFile:async()=>true,isAlias:async path=>{assert.match(path,/Иван Петров/);return true;}});assert.match(clients.ssh,/Система Windows/);
});
test('RDP discovery rejects slash traversal before any file access; inaccessible files map to controlled error',async()=>{
 let probes=0;for(const root of ['C:\\Windows/../evil','C:\\Windows.','C:\\%ROOT%'])await assert.rejects(findWindowsRdpClient({SystemRoot:root},async()=>{probes++;return true;}));assert.equal(probes,0);
 await assert.rejects(findWindowsRdpClient({SystemRoot:'C:\\Windows'},async()=>{throw new Error('EACCES');}),error=>error instanceof Error&&'code' in error&&error.code==='RDP_CLIENT_MISSING');
});
test('Case scanning catches filenames, module stems, imports and local SVG spelling',async()=>{
 assert.ok(filenameIssues(['a/Starfield.tsx','a/starfield.ts']).length);assert.ok(filenameIssues(['Img.svg','img.svg']).length);
 assert.deepEqual(referenceIssues('src/App.tsx',"import {X} from './Card'",['src/card.tsx']),['Reference case mismatch in src/App.tsx: ./Card']);
 assert.ok(referenceIssues('src/index.html','<img src="./Mark.svg">',['src/public/mark.svg']).length);
 assert.deepEqual(await auditProject(process.cwd()),[]);
});
test('ZIP cleanliness rejects generated folders, profiles, stale engine, env files and nested archives',()=>{
 for(const name of ['nexus/node_modules/pkg/index.js','nexus/out/main.js','nexus/.smoke-out/run.js','nexus/profiles/user.json','nexus/src/appearance/starfield.ts','nexus/.env','nexus/old-stage.zip','../outside'])assert.deepEqual(archiveMemberIssues([name]),[name]);
 assert.deepEqual(archiveMemberIssues(['nexus/src/appearance/starfieldEngine.ts','nexus/package-lock.json','nexus/docs/STAGE12.md']),[]);
});
test('Smoke capability surface has no clients, commands, settings mutation, credentials or renderer API',()=>{
 for(const file of ['src/main/readiness/windowsReadiness.ts','scripts/windowsSmokeMain.ts']){
  const source=readFileSync(file,'utf8');assert.doesNotMatch(source,/\.send\s*\(|execFile\s*\(|spawn\s*\(|powershell|cmd\.exe|StrictHostKeyChecking|contextBridge|ipcMain\.handle/i);
 }
 const launcher=readFileSync('scripts/windowsSmokeLauncher.ts','utf8');assert.match(launcher,/shell:false/);assert.match(launcher,/createRequire\(import.meta.url\)\('electron'\)/);assert.doesNotMatch(launcher,/process\.env\[['"](?:SystemRoot|LOCALAPPDATA)['"]\]\s*=/);
});

test('Writable diagnostic never deletes an existing file, and cleans its exclusively owned file',async()=>{
 const {mkdtemp,writeFile,readFile,access,rm}=await import('node:fs/promises');const {tmpdir}=await import('node:os');const {join}=await import('node:path');const {exclusiveWritableProbe}=await import('../src/main/readiness/fileProbe.js');
 const directory=await mkdtemp(join(tmpdir(),'nexus-probe-test-'));const existing=join(directory,'nexus-smoke-existing.tmp');
 try{await writeFile(existing,'preserve');await assert.rejects(exclusiveWritableProbe(directory,'existing'));assert.equal(await readFile(existing,'utf8'),'preserve');assert.equal(await exclusiveWritableProbe(directory,'owned'),true);await assert.rejects(access(join(directory,'nexus-smoke-owned.tmp')));await assert.rejects(exclusiveWritableProbe(directory,'../outside'));}
 finally{await rm(directory,{recursive:true,force:true});}
});
