import assert from 'node:assert/strict';
import test from 'node:test';
import { createMagicPacket } from '../src/shared/magicPacket.js';
import { UdpWakeOnLanProvider } from '../src/main/providers/UdpWakeOnLanProvider.js';
import type { WakeSocket, WakeTransportDependencies } from '../src/main/providers/UdpWakeOnLanProvider.js';
import type { WakeOnLanRequest } from '../src/main/providers/contracts.js';
import { WakeOnLanService } from '../src/main/services/wakeOnLanService.js';
import { WakeOnLanError } from '../src/main/services/wakeOnLanError.js';
import { ComputerStoreError } from '../src/main/services/computerStore.js';
import { createWakeRequestHandler } from '../src/main/ipc/wakeRequest.js';
import { isTrustedIpcSender } from '../src/main/ipc/trustedSender.js';
import { createPlatformService } from '../src/main/platform/createPlatformService.js';
import { performComputerAction } from '../src/renderer/state/computerActions.js';
import type { Computer } from '../src/shared/types.js';
import { record } from './fixtures.js';

const code = (expected: string) => (error: unknown) => typeof error === 'object' && error !== null && 'code' in error && error.code === expected;
const request = (): WakeOnLanRequest => ({ macAddress: record.macAddress, broadcastAddress: '192.168.1.255', port: 9, packet: createMagicPacket(record.macAddress) });
function transport(mode = 'success') {
  const sends: { packet: Uint8Array; port: number; address: string }[] = [];
  const events: string[] = []; const timers = new Map<number, { callback: () => void; ms: number }>();
  let next = 0; let bound: (() => void) | undefined; let onError = () => {}; let onClose = () => {};
  let sendCallback: ((error: Error | null) => void) | undefined;
  const socket: WakeSocket = {
    onError: cb => { onError = cb; return () => { onError = () => {}; events.push('remove-error'); }; },
    onClose: cb => { onClose = cb; return () => { onClose = () => {}; events.push('remove-close'); }; },
    bind: (port, cb) => { assert.equal(port, 0); events.push('bind'); bound = cb; if (mode === 'bind-throw') throw new Error('bind'); if (mode !== 'bind-pending') queueMicrotask(cb); },
    setBroadcast: value => { assert.equal(value, true); events.push('broadcast'); if (mode === 'broadcast-throw') throw new Error('broadcast'); },
    send: (packet, port, address, cb) => { events.push('send'); sends.push({ packet: packet.slice(), port, address }); sendCallback = cb; if (mode === 'send-throw') throw new Error('send'); if (mode !== 'send-pending') queueMicrotask(() => cb(mode === 'send-error' ? new Error('send') : null)); },
    close: () => { events.push('close'); if (mode === 'close-throw') throw new Error('not running'); queueMicrotask(onClose); },
  };
  const deps: WakeTransportDependencies = { socketFactory: () => { events.push('create'); if (mode === 'create-throw') throw new Error('create'); return socket; }, schedule: (callback, ms) => { const id = ++next; timers.set(id, { callback, ms }); return () => { timers.delete(id); }; } };
  return { provider: new UdpWakeOnLanProvider(deps), sends, events, timers,
    error: () => onError(), close: () => onClose(), bind: () => bound?.(), callback: () => sendCallback?.(null),
    fire: (ms: number) => { const item = [...timers].find(([,timer]) => timer.ms === ms); assert.ok(item); timers.delete(item[0]); item[1].callback(); },
  };
}
async function tick(): Promise<void> { for (let i = 0; i < 8; i++) await Promise.resolve(); }
function service(computer: Computer = record, send: (request: WakeOnLanRequest) => Promise<void> = async () => {}) {
  const calls: WakeOnLanRequest[] = [];
  return { calls, service: new WakeOnLanService({ get: () => computer }, { id: 'mock', send: async req => { calls.push(req); await send(req); } }) };
}

test('Magic Packet exact 102 bytes, six FF and ordered MAC repeated sixteen times', () => {
  const mac = [0x01,0x23,0x45,0x67,0x89,0xab]; const packet = createMagicPacket('01:23:45:67:89:AB');
  assert.equal(packet.length, 102); assert.deepEqual([...packet.slice(0,6)], Array(6).fill(255));
  for (let i=0;i<16;i++) assert.deepEqual([...packet.slice(6+i*6,12+i*6)],mac);
});
test('Magic Packet normalized MAC formats agree, invalid MACs rejected, no shared mutable packet', () => {
  assert.deepEqual(createMagicPacket('aa-bb-cc-dd-ee-ff'),createMagicPacket('AA:BB:CC:DD:EE:FF'));
  for (const mac of ['', 'AA:BB:CC:DD:EE', 'GG:BB:CC:DD:EE:FF', 'AA-BB:CC-DD-EE-FF','AA:BB:CC:DD:EE:FF;cmd']) assert.throws(()=>createMagicPacket(mac));
  const packet=createMagicPacket(record.macAddress); packet[0]=0; assert.equal(createMagicPacket(record.macAddress)[0],255);
});
test('UDP4 binds ephemeral port, enables broadcast, sends exactly three identical standard packets, closes before resolution', async () => {
  const ctx=transport(); const promise=ctx.provider.send(request()); await tick();
  assert.equal(ctx.sends.length,1); ctx.fire(100); await tick(); assert.equal(ctx.sends.length,2);ctx.fire(100);await promise;
  assert.equal(ctx.sends.length,3); for(const send of ctx.sends){assert.deepEqual(send.packet,request().packet);assert.equal(send.address,'192.168.1.255');assert.equal(send.port,9);}
  assert.deepEqual(ctx.events.slice(0,4),['create','bind','broadcast','send']);assert.equal(ctx.events.filter(e=>e==='close').length,1);assert.equal(ctx.timers.size,0);assert.ok(ctx.events.includes('remove-error'));
});
test('UDP fixed destination and packet are snapshotted before asynchronous bind', async () => {
  const ctx=transport('bind-pending'); const mutable={...request()};const pending=ctx.provider.send(mutable);mutable.broadcastAddress='203.0.113.1';mutable.port=999;mutable.packet.fill(0);ctx.bind();await tick();ctx.fire(100);await tick();ctx.fire(100);await pending;
  for(const send of ctx.sends){assert.equal(send.address,'192.168.1.255');assert.equal(send.port,9);assert.deepEqual(send.packet,request().packet);}
});
test('UDP provider rejects malformed destination/port/MAC/arbitrary payload before creating a socket', async () => {
  for(const bad of [{broadcastAddress:'host.test'}, {broadcastAddress:'1.2.3.999'}, {port:0}, {port:9.1}, {port:65536}, {macAddress:'bad'}, {packet:new Uint8Array(102)}, {packet:new Uint8Array(103)}]){
    const ctx=transport(); await assert.rejects(ctx.provider.send({...request(),...bad}),code('WOL_SEND_ERROR'));assert.deepEqual(ctx.events,[]);
  }
});
for(const mode of ['bind-throw','broadcast-throw','send-throw','send-error','close-throw']) test('UDP '+mode+' is controlled and closes socket, cancels all timers',async()=>{
  const ctx=transport(mode);const pending=assert.rejects(ctx.provider.send(request()),code('WOL_SEND_ERROR'));await tick();
  if(mode==='close-throw'){ctx.fire(100);await tick();ctx.fire(100);}await pending;assert.equal(ctx.events.filter(e=>e==='close').length,1);assert.equal(ctx.timers.size,0);
});
test('UDP socket error while binding closes, late callbacks cannot send or restart burst', async()=>{
  const ctx=transport('bind-pending');const pending=assert.rejects(ctx.provider.send(request()),code('WOL_SEND_ERROR'));ctx.error();ctx.bind();await pending;ctx.error();assert.equal(ctx.sends.length,0);assert.equal(ctx.timers.size,0);
});
test('UDP socket error during send and unsolicited close stop further packets',async()=>{
  for(const closed of [false,true]){const ctx=transport('send-pending');const pending=assert.rejects(ctx.provider.send(request()),code('WOL_SEND_ERROR'));await tick();if(closed)ctx.close();else ctx.error();ctx.callback();await pending;assert.equal(ctx.sends.length,1);assert.equal(ctx.timers.size,0);}
});
test('UDP deadline during bind/send/interval guarantees cleanup with no further sends',async()=>{
  for(const mode of ['bind-pending','send-pending','success']){const ctx=transport(mode);const pending=assert.rejects(ctx.provider.send(request()),code('WOL_TIMEOUT'));await tick();ctx.fire(2500);ctx.bind();ctx.callback();await pending;assert.equal(ctx.events.filter(e=>e==='close').length,1);assert.equal(ctx.timers.size,0);assert.ok(ctx.sends.length<=1);}
});
test('UDP cancellation before creation and during burst cleans handles; create throw is controlled',async()=>{
  const aborted=new AbortController();aborted.abort();const before=transport();await assert.rejects(before.provider.send({...request(),signal:aborted.signal}),code('CANCELLED'));assert.deepEqual(before.events,[]);
  const controller=new AbortController();const ctx=transport('send-pending');const pending=assert.rejects(ctx.provider.send({...request(),signal:controller.signal}),code('CANCELLED'));await tick();controller.abort();await pending;assert.equal(ctx.timers.size,0);assert.equal(ctx.events.filter(e=>e==='close').length,1);
  await assert.rejects(transport('create-throw').provider.send(request()),code('WOL_SEND_ERROR'));
});
test('WoL service rejects invalid ID before store and returns missing computer without provider calls',async()=>{
  let gets=0;const ctx=new WakeOnLanService({get:()=>{gets++;throw new ComputerStoreError('NOT_FOUND','missing');}},null);
  for(const id of ['bad',null,{},'demo-main-pc'])await assert.rejects(ctx.wake(id),code('VALIDATION_ERROR'));assert.equal(gets,0);await assert.rejects(ctx.wake(record.id),code('NOT_FOUND'));
});
test('WoL validates saved config again: corrupt record/MAC/broadcast/port never invokes provider',async()=>{
  for(const computer of [{...record,name:''},{...record,macAddress:null},{...record,macAddress:'bad'},{...record,wakeOnLan:{broadcastAddress:'host.test',port:9}},{...record,wakeOnLan:{broadcastAddress:'192.168.1.255',port:0}},{...record,wakeOnLan:{broadcastAddress:'192.168.1.255',port:9.5}},{...record,wakeOnLan:{broadcastAddress:'192.168.1.255',port:65536}}]){
    const ctx=service(computer);await assert.rejects(ctx.service.wake(record.id),code('VALIDATION_ERROR'));assert.equal(ctx.calls.length,0);
  }
});
test('WoL unsupported remote, missing config/MAC and unsupported host have controlled outcomes',async()=>{
  const linux=service({...record,operatingSystem:'linux'});await assert.rejects(linux.service.wake(record.id),code('WOL_UNSUPPORTED'));
  for(const computer of [{...record,wakeOnLan:null},{...record,wakeOnLan:null,macAddress:null}])await assert.rejects(service(computer).service.wake(record.id),code('WOL_DISABLED'));
  await assert.rejects(new WakeOnLanService({get:()=>record},null).wake(record.id),code('WOL_UNSUPPORTED'));
});
test('WoL success uses only saved normalized fields, no checks or writes/status changes, retry after success',async()=>{
  const before=JSON.stringify(record);const ctx=service({...record,macAddress:'aa-bb-cc-dd-ee-ff',rdpEnabled:false,sshEnabled:false});
  for(let i=0;i<2;i++){assert.deepEqual(await ctx.service.wake(record.id),{computerId:record.id,state:'packet-sent',packetsSent:3});}
  assert.equal(ctx.calls.length,2);for(const req of ctx.calls){assert.equal(req.macAddress,'AA:BB:CC:DD:EE:FF');assert.equal(req.broadcastAddress,'192.168.1.255');assert.equal(req.port,9);assert.deepEqual(req.packet,createMagicPacket(record.macAddress));}assert.equal(JSON.stringify(record),before);
});
test('WoL same ID duplicate guard, other IDs independent, guard clears after error and shutdown cancellation',async()=>{
  let release=()=>{};let fail=true;
  const ctx=service(record,async()=>{await new Promise<void>(resolve=>{release=resolve;});if(fail)throw new WakeOnLanError('WOL_SEND_ERROR','failed');});
  const pending=assert.rejects(ctx.service.wake(record.id),code('WOL_SEND_ERROR'));await assert.rejects(ctx.service.wake(record.id),code('WOL_BUSY'));assert.equal(ctx.calls.length,1);release();await pending;
  fail=false;const retry=ctx.service.wake(record.id);release();await retry;
  const waiting=assert.rejects(ctx.service.wake(record.id),code('CANCELLED'));ctx.service.cancelPending();assert.equal(ctx.calls.at(-1)?.signal?.aborted,true);release();await waiting;
  let resolve=()=>{};const other={...record,id:'22222222-2222-4222-8222-222222222222'};const svc=new WakeOnLanService({get:id=>id===record.id?record:other},{id:'mock',send:async req=>{if(req.macAddress)await new Promise<void>(r=>{resolve=r;});}});
  const first=svc.wake(record.id);const doneFirst=resolve;const second=svc.wake(other.id);doneFirst();resolve();await Promise.all([first,second]);
});
test('WoL IPC trusted identity/frame/window/url guard, ID-only rejects forged payload and extra arguments',async()=>{
  const frame={url:'nexus://app/index.html'};const contents={mainFrame:frame};const window={isDestroyed:()=>false,webContents:contents};const event={sender:contents,senderFrame:frame};let calls=0;
  const real=service();const handler=createWakeRequestHandler((candidate:{ sender: unknown; senderFrame: { url: string } | null })=>{if(!isTrustedIpcSender(candidate,window,frame.url))throw new Error('untrusted');},{wake:async id=>{calls++;return real.service.wake(id);}});
  for(const forged of [{...event,sender:{}},{...event,senderFrame:{...frame}},{...event,senderFrame:{url:'https://evil'} }])await assert.rejects(handler(forged,record.id),/untrusted/);
  assert.equal(isTrustedIpcSender(event,{...window,isDestroyed:()=>true},frame.url),false);assert.equal(isTrustedIpcSender(event,null,frame.url),false);
  assert.equal((await handler(event,record.id,{mac:'bad',address:'evil',port:999,payload:[1]})).ok,false);assert.equal(calls,0);
  for(const id of [{id:record.id,macAddress:record.macAddress},'bad',null]){const reply=await handler(event,id);assert.equal(reply.ok,false);if(!reply.ok)assert.equal(reply.error.code,'VALIDATION_ERROR');}
  assert.equal((await handler(event,record.id)).ok,true);assert.equal(real.calls.length,1);
});
test('WoL IPC maps controlled storage/send errors and never reveals unexpected errors',async()=>{
  for(const [error,expected] of [[new SyntaxError('secret'),'STORAGE_ERROR'],[new WakeOnLanError('WOL_TIMEOUT','timeout'),'WOL_TIMEOUT'],[new Error('secret'),'WOL_SEND_ERROR']] as const){
    const handler=createWakeRequestHandler(()=>{},{wake:async()=>{throw error;}});const reply=await handler({},record.id);assert.equal(reply.ok,false);if(!reply.ok){assert.equal(reply.error.code,expected);assert.ok(!reply.error.message.includes('secret'));}
  }
});
test('WoL provider composition Windows only; demo routing never invokes user wake or wait-connect',()=>{
  assert.ok(createPlatformService('win32').providers.wakeOnLan instanceof UdpWakeOnLanProvider);for(const host of ['linux','darwin'] as const)assert.equal(createPlatformService(host).providers.wakeOnLan,null);
  const calls:string[]=[];for(const action of ['wake','wake-rdp'] as const)performComputerAction(true,record,action,()=>calls.push('demo'),()=>assert.fail('rdp'),()=>assert.fail('ssh'),()=>assert.fail('udp'));
  performComputerAction(false,record,'wake',()=>assert.fail('demo'),()=>assert.fail('rdp'),()=>assert.fail('ssh'),id=>calls.push(id));
  performComputerAction(false,record,'wake-rdp',()=>assert.fail('demo'),()=>assert.fail('rdp'),()=>assert.fail('ssh'),()=>assert.fail('udp'));
  assert.deepEqual(calls,['demo','demo',record.id]);
});
