// Test-only Electron main entry: loads the unchanged production application.
// The harness is Node-only; no renderer API, IPC handler or production flag.
globalThis.__nexusRdpHarness = async ({project,file,id,mode}) => {
   const {pathToFileURL}=await import('node:url');const {readFileSync}=await import('node:fs');
   const load=relative=>import(pathToFileURL(project+'/.test-out/'+relative).href);
   const {ComputerStore}=await load('src/main/services/computerStore.js');
   const {CheckCoordinator}=await load('src/main/services/checkCoordinator.js');
   const {RemoteDesktopService}=await load('src/main/services/remoteDesktopService.js');
   const {WindowsRdpProvider}=await load('src/main/providers/windows/WindowsRdpProvider.js');
   const store=new ComputerStore({read:()=>JSON.parse(readFileSync(file,'utf8')).configuration,write:()=>{throw new Error('Harness must never write configuration');}});
   const calls=[];let release;let reached;
   const launched=new Promise(resolve=>reached=resolve);
   const provider=new WindowsRdpProvider(async()=> 'C:\\Windows\\System32\\mstsc.exe',async(executable,args)=>{
     calls.push({executable,args});reached();
     if(mode==='failure')throw new Error('mock spawn failure');
     if(mode==='duplicate')await new Promise(resolve=>release=resolve);
   });
   const service=new RemoteDesktopService(store,new CheckCoordinator(store),provider);
   const first=service.open(id);let duplicateCode=null;
   if(mode==='duplicate'){await launched;try{await service.open(id);}catch(error){duplicateCode=error.code;}release();}
   try{return {ok:true,result:await first,calls,duplicateCode};}catch(error){return {ok:false,error:{code:error.code||null,message:error.message},calls,duplicateCode};}
};
import('../out/main/main.js').catch(error => { console.error(error); process.exitCode = 1; });
