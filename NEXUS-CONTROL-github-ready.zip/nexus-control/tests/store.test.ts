import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ComputerStore, ComputerStoreError } from '../src/main/services/computerStore.js';
import type { ConfigurationRepository } from '../src/main/services/computerStore.js';
import { migrateConfiguration, parseStorageFile, StorageFormatError, MAX_COMPUTERS } from '../src/main/services/storageSchema.js';
import type { ComputerConfiguration } from '../src/main/services/storageSchema.js';
import { draft, record } from './fixtures.js';
class MemoryRepository implements ConfigurationRepository {
  value: unknown = undefined;
  writes = 0;
  fail = false;
  read(): unknown { return structuredClone(this.value); }
  write(value: ComputerConfiguration): void { if (this.fail) throw new Error('disk unavailable'); this.writes++; this.value = structuredClone(value); }
}
test('Versioned envelope rejects corrupt, future and duplicate configurations', () => {
  assert.deepEqual(migrateConfiguration({ schemaVersion: 1, computers: [] }), { schemaVersion: 1, computers: [] });
  for (const value of [null, {}, { schemaVersion: 2, computers: [] }, { schemaVersion: 0, computers: [] }, { schemaVersion: 1, computers: 'bad' }, { schemaVersion: 1, computers: [record,record] }, { schemaVersion: 1, computers: [], password: '' }, { schemaVersion: 1, computers: [{ ...record, id: 'bad' }] }]) assert.throws(() => migrateConfiguration(value), StorageFormatError);
});
test('Migration entry point applies explicit sequential transformations and validates output', () => {
  assert.deepEqual(migrateConfiguration({ schemaVersion: 0, legacy: [] }, { 0: () => ({ schemaVersion: 1, computers: [] }) }), { schemaVersion: 1, computers: [] });
  assert.throws(() => migrateConfiguration({ schemaVersion: 0 }, { 0: () => ({ schemaVersion: 0, computers: [] }) }), StorageFormatError);
  assert.throws(() => migrateConfiguration({ schemaVersion: 0 }, { 0: () => ({ schemaVersion: 1, computers: [{ password: 'secret' }] }) }), StorageFormatError);
});
test('Persistent CRUD assigns main metadata, preserves identity and survives a new service instance', () => {
  const repo = new MemoryRepository();
  const store = new ComputerStore(repo, () => record.id, () => record.createdAt);
  assert.deepEqual(store.list(), []);
  const saved = store.create(draft); assert.equal(saved.id, record.id); assert.equal(saved.macAddress, record.macAddress);
  const restarted = new ComputerStore(repo, () => record.id, () => '2026-10-02T00:00:00.000Z');
  assert.deepEqual(restarted.list(), [saved]);
  const edited = restarted.update(saved.id, { ...draft, name: 'EDITED' });
  assert.equal(edited.createdAt, saved.createdAt); assert.equal(edited.id, saved.id); assert.equal(edited.updatedAt, '2026-10-02T00:00:00.000Z');
  assert.equal(new ComputerStore(repo).list()[0]?.name, 'EDITED');
  restarted.delete(saved.id); assert.deepEqual(new ComputerStore(repo).list(), []);
  assert.throws(() => restarted.delete(saved.id), (error: unknown) => error instanceof ComputerStoreError && error.code === 'NOT_FOUND');
});
test('Repeated main validation blocks invalid payloads without writes', () => {
  const repo = new MemoryRepository(); const store = new ComputerStore(repo); store.list(); const before = repo.writes;
  for (const value of [{ ...draft, password: 'secret' }, { ...draft, localAddress: 'host;cmd' }, { ...draft, id: record.id }]) assert.throws(() => store.create(value), ComputerStoreError);
  assert.throws(() => store.update('demo-pc-home', draft), ComputerStoreError); assert.throws(() => store.delete('-option'), ComputerStoreError);
  assert.equal(repo.writes, before); assert.deepEqual(store.list(), []);
});
test('Read corruption never overwrites original data; failed writes never acknowledge a mutation', () => {
  const repo = new MemoryRepository(); repo.value = { schemaVersion: 2, computers: [record] }; const original = structuredClone(repo.value);
  const store = new ComputerStore(repo); assert.throws(() => store.list(), StorageFormatError); assert.throws(() => store.create(draft), StorageFormatError);
  assert.equal(repo.writes, 0); assert.deepEqual(repo.value, original);
  repo.value = { schemaVersion: 1, computers: [record] }; repo.fail = true;
  assert.throws(() => store.update(record.id, { ...draft, name: 'changed' }), /disk unavailable/);
  assert.throws(() => store.delete(record.id), /disk unavailable/); assert.deepEqual(store.list(), [record]);
});
test('Returned objects do not mutate storage and clock reversal cannot regress updatedAt', () => {
  const repo = new MemoryRepository(); repo.value = { schemaVersion: 1, computers: [record] };
  const store = new ComputerStore(repo, () => record.id, () => '2025-01-01T00:00:00.000Z');
  const listed = store.list(); Reflect.set(listed[0] ?? {}, 'name', 'tampered'); assert.equal(store.list()[0]?.name, record.name);
  assert.equal(store.update(record.id, draft).updatedAt, record.updatedAt);
});
test('Configured count limit is enforced before writing', () => {
  const repo = new MemoryRepository(); repo.value = { schemaVersion: 1, computers: Array.from({ length: MAX_COMPUTERS }, (_, index) => ({ ...record, id: `${index.toString(16).padStart(8,'0')}-1111-4111-8111-111111111111` })) };
  const store = new ComputerStore(repo); assert.throws(() => store.create(draft), (error: unknown) => error instanceof ComputerStoreError && error.code === 'LIMIT_REACHED'); assert.equal(repo.writes, 0);
});

test('Raw file parsing rejects primitive, array and missing roots before coercion', () => {
  for (const value of ['[]', 'null', '1', '{}', '{"configuration":null,"password":"secret"}', '{broken']) assert.throws(() => parseStorageFile(value));
  assert.deepEqual(parseStorageFile('{"configuration":{"schemaVersion":1,"computers":[]}}'), { configuration: { schemaVersion: 1, computers: [] } });
});
