// Explicit test-only DI. Production source/entry contains no overrides or QA flags.
const {ipcMain,BrowserWindow}=require('electron');const {readFileSync}=require('node:fs');const {pathToFileURL}=require('node:url');
let env,flow,slots,claims,clock,handlers,main;
async function tick(){for(let i=0;i<40;i++)await Promise.resolve();}
globalThis.__nexusFlowQa={
 async install({project,file}){
  const load=relative=>import(pathToFileURL(project+'/.test-out/'+relative).href);
  const {ComputerStore}=await load('src/main/services/computerStore.js');const {NetworkService}=await load('src/main/services/networkService.js');const {CheckCoordinator}=await load('src/main/services/checkCoordinator.js');
  const {WakeOnLanService}=await load('src/main/services/wakeOnLanService.js');const {UdpWakeOnLanProvider}=await load('src/main/providers/UdpWakeOnLanProvider.js');const {RemoteDesktopService}=await load('src/main/services/remoteDesktopService.js');const {SshTerminalService}=await load('src/main/services/sshTerminalService.js');const {WakeAndConnectService}=await load('src/main/services/wakeAndConnectService.js');
  const {WindowsRdpProvider}=await load('src/main/providers/windows/WindowsRdpProvider.js');const {WindowsSshProvider}=await load('src/main/providers/windows/WindowsSshProvider.js');const {RdpError}=await load('src/main/services/rdpError.js');const {SshError}=await load('src/main/services/sshError.js');
  const {createWakeAndConnectRequestHandler}=await load('src/main/ipc/wakeAndConnectRequest.js');const {createRdpRequestHandler}=await load('src/main/ipc/rdpRequest.js');const {createSshRequestHandler}=await load('src/main/ipc/sshRequest.js');const {createWakeRequestHandler}=await load('src/main/ipc/wakeRequest.js');const {isTrustedIpcSender}=await load('src/main/ipc/trustedSender.js');
  env={ready:false,holdWake:false,holdCheck:false,wakeFail:false,launchFail:false,finalUnavailable:false,releaseWake:null,probes:[],launches:[],packets:[],progress:[],activeSockets:0,activeProbes:0,ipc:0};
  clock={time:0,next:0,timers:new Map(),now:()=>clock.time,schedule:(cb,ms)=>{const id=++clock.next;clock.timers.set(id,{due:clock.time+ms,cb});return()=>clock.timers.delete(id);}};
  const store=new ComputerStore({read:()=>JSON.parse(readFileSync(file,'utf8')).configuration,write:()=>{throw new Error('QA must never normalize/write');}});
  const wakeProvider=new UdpWakeOnLanProvider({socketFactory:()=>{
   env.activeSockets++;let onClose=()=>{},onError=()=>{};let closed=false;
   return{onClose:cb=>{onClose=cb;return()=>{onClose=()=>{};}},onError:cb=>{onError=cb;return()=>{onError=()=>{};}},bind:(port,cb)=>{if(port!==0)throw new Error('ephemeral only');if(env.holdWake)env.releaseWake=cb;else queueMicrotask(cb);},setBroadcast:flag=>{if(flag!==true)throw new Error('broadcast only');},send:(packet,port,address,cb)=>{if(address!=='127.0.0.1'||port!==9)throw new Error('QA destination restriction');env.packets.push([...packet]);queueMicrotask(()=>cb(env.wakeFail?new Error('injected error'):null));},close:()=>{if(closed)return;closed=true;env.activeSockets--;queueMicrotask(onClose);}};
  },schedule:(cb,ms)=>{const timer=setTimeout(cb,ms===2500?2500:0);return()=>clearTimeout(timer);}});
  const network=new NetworkService(async(address,service,signal)=>{
   env.probes.push({address,service});env.activeProbes++;let result;
   try{
    if(env.holdCheck)await new Promise(resolve=>{const abort=()=>{signal.removeEventListener('abort',abort);resolve();};signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();});
    const attempts=env.probes.filter(p=>p.service===service&&p.address===address).length;
    result=!signal.aborted&&env.ready&&address==='127.0.0.1'&&!(env.finalUnavailable&&attempts%2===0)?{status:'ready',latencyMs:1,errorCode:null}:{status:'unavailable',latencyMs:null,errorCode:signal.aborted?'CANCELLED':'ECONNREFUSED'};
    return result;
   }finally{env.activeProbes--;}
  });
  const checks=new CheckCoordinator(store,network);slots=new Map();claims=new Set();
  const providers={wakeOnLan:wakeProvider,remoteDesktop:new WindowsRdpProvider(async()=> 'C:\\Windows\\System32\\mstsc.exe',async(executable,args)=>{if(env.launchFail)throw new RdpError('RDP_LAUNCH_ERROR','Не удалось открыть RDP-клиент Windows.');env.launches.push({service:'rdp',executable,args:[...args]});}),ssh:new WindowsSshProvider(async()=>({ssh:'C:\\Windows\\System32\\OpenSSH\\ssh.exe',terminal:'C:\\Users\\Alex\\AppData\\Local\\Microsoft\\WindowsApps\\wt.exe',consoleHost:null}),async(executable,args)=>{if(env.launchFail)throw new SshError('SSH_LAUNCH_ERROR','Не удалось открыть SSH-терминал.');env.launches.push({service:'ssh',executable,args:[...args]});})};
  const wake=new WakeOnLanService(store,providers.wakeOnLan,claims);const rdp=new RemoteDesktopService(store,checks,providers.remoteDesktop,slots);const ssh=new SshTerminalService(store,checks,providers.ssh,slots);
  main=BrowserWindow.getAllWindows()[0];const url=main.webContents.getURL();const guard=event=>{if(!isTrustedIpcSender(event,main,url))throw new Error('untrusted');};
  flow=new WakeAndConnectService(store,checks,wake,rdp,ssh,providers,slots,claims,clock,p=>{env.progress.push(p);main.webContents.send('nexus:wake-connect:progress',p);});
  handlers={rdp:createWakeAndConnectRequestHandler(guard,id=>flow.openRdp(id)),ssh:createWakeAndConnectRequestHandler(guard,id=>flow.openSsh(id)),cancel:createWakeAndConnectRequestHandler(guard,id=>flow.cancel(id))};
  for(const [channel,handler] of [['nexus:wake-connect:rdp',handlers.rdp],['nexus:wake-connect:ssh',handlers.ssh],['nexus:wake-connect:cancel',handlers.cancel],['nexus:rdp:open',createRdpRequestHandler(guard,rdp)],['nexus:ssh:open-terminal',createSshRequestHandler(guard,ssh)],['nexus:wol:wake-computer',createWakeRequestHandler(guard,wake)]]){ipcMain.removeHandler(channel);ipcMain.handle(channel,(event,...args)=>{env.ipc++;return handler(event,...args);});}
  main.once('closed',()=>{flow.cancelAll();wake.cancelPending();rdp.cancelPending();ssh.cancelPending();});
 },
 configure(values){for(const key of ['ready','holdWake','holdCheck','wakeFail','launchFail','finalUnavailable'])if(key in values)env[key]=values[key];},
 snapshot(){return{probes:env.probes,launches:env.launches,packets:env.packets,progress:env.progress,activeSockets:env.activeSockets,activeProbes:env.activeProbes,slots:slots.size,claims:claims.size,timers:clock.timers.size,ipc:env.ipc};},
 releaseWake(){env.holdWake=false;const cb=env.releaseWake;env.releaseWake=null;if(cb)cb();},
 async advance(ms){const end=clock.time+ms;while(true){const next=[...clock.timers].filter(([,t])=>t.due<=end).sort((a,b)=>a[1].due-b[1].due)[0];if(!next)break;clock.time=next[1].due;clock.timers.delete(next[0]);next[1].cb();await tick();}clock.time=end;await tick();},
 extra(kind,id,payload){return handlers[kind]({sender:main.webContents,senderFrame:main.webContents.mainFrame},id,payload);},
 cancelAll(){flow.cancelAll();}
};
import('../out/main/main.js').catch(error=>{console.error(error);process.exitCode=1;});
