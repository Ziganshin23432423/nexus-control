import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import test from 'node:test';
import { WindowsSshProvider, launchWindowsSshHost } from '../src/main/providers/windows/WindowsSshProvider.js';
import { findWindowsSshClients } from '../src/main/providers/windows/windowsSshDiscovery.js';
import { SshTerminalService } from '../src/main/services/sshTerminalService.js';
import { RemoteDesktopService } from '../src/main/services/remoteDesktopService.js';
import { NetworkService, CheckCancelledError } from '../src/main/services/networkService.js';
import { CheckCoordinator } from '../src/main/services/checkCoordinator.js';
import { createSshRequestHandler } from '../src/main/ipc/sshRequest.js';
import { isTrustedIpcSender } from '../src/main/ipc/trustedSender.js';
import { createPlatformService } from '../src/main/platform/createPlatformService.js';
import { performComputerAction } from '../src/renderer/state/computerActions.js';
import { ComputerStoreError } from '../src/main/services/computerStore.js';
import type { Computer } from '../src/shared/types.js';
import type { SshTarget } from '../src/main/providers/contracts.js';
import type { TcpProbe, TcpProbeResult } from '../src/main/services/tcpProbe.js';
import { record } from './fixtures.js';

const ready: TcpProbeResult = { status: 'ready', latencyMs: 1, errorCode: null };
const unavailable: TcpProbeResult = { status: 'unavailable', latencyMs: null, errorCode: 'ECONNREFUSED' };
const clients = { ssh: 'C:\\Windows\\System32\\OpenSSH\\ssh.exe', terminal: 'C:\\Users\\Alex\\AppData\\Local\\Microsoft\\WindowsApps\\wt.exe', consoleHost: null };
const code = (expected: string) => (error: unknown) => typeof error === 'object' && error !== null && 'code' in error && error.code === expected;
function setup(computer: Computer = record, probe: TcpProbe = async () => ready, launch: (target: SshTarget) => Promise<void> = async () => {}) {
  const calls: SshTarget[] = []; let current = computer; let deleted = false;
  const store = { get: () => { if (deleted) throw new ComputerStoreError('NOT_FOUND', 'deleted'); return current; }, list: () => [current] };
  const checks = new CheckCoordinator(store, new NetworkService(probe));
  const pending = new Map<string, AbortController>();
  const service = new SshTerminalService(store, checks, { id: 'mock', open: async target => { calls.push(target); await launch(target); } }, pending);
  return { service, store, checks, pending, calls, setComputer: (value: Computer) => { current = value; }, deleteComputer: () => { deleted = true; } };
}
async function tick(): Promise<void> { for (let i = 0; i < 15; i++) await Promise.resolve(); }

test('SSH system client and standard Windows Terminal alias discovery never search PATH', async () => {
  const inspected: string[] = []; const result = await findWindowsSshClients({ environment: { SystemRoot: 'D:\\Windows', LOCALAPPDATA: 'C:\\Users\\Alex Smith\\AppData\\Local', PATH: 'C:\\evil' }, isFile: async path => { inspected.push(path); return true; }, isAlias: async path => { inspected.push(path); return true; } });
  assert.equal(result.ssh, 'D:\\Windows\\System32\\OpenSSH\\ssh.exe'); assert.equal(result.terminal, 'C:\\Users\\Alex Smith\\AppData\\Local\\Microsoft\\WindowsApps\\wt.exe'); assert.equal(result.consoleHost, null); assert.equal(inspected.length, 2);
});
test('Missing/inaccessible OpenSSH Client fails without probing aliases or arbitrary PATH', async () => {
  for (const isFile of [async () => false, async () => { throw new Error('missing'); }]) await assert.rejects(findWindowsSshClients({ environment: { SystemRoot: 'C:\\Windows' }, isFile, isAlias: async () => { assert.fail('no alias lookup without ssh'); } }), code('SSH_CLIENT_MISSING'));
  for (const root of [undefined, 'Windows', '\\\\server\\share', 'C:\\Windows\\..\\evil', 'C:\\Windows/../evil', 'C:\\%EVIL%', 'C:\\Windows;evil']) await assert.rejects(findWindowsSshClients({ environment: root ? { SystemRoot: root } : {}, isFile: async () => true, isAlias: async () => true }), code('SSH_CLIENT_MISSING'));
});
test('Absent/disabled Terminal alias uses the system Console Host; invalid LOCALAPPDATA never searches elsewhere', async () => {
  for (const local of [undefined, 'relative', 'C:\\Users\\Alex\\AppData\\Local']) {
    const result = await findWindowsSshClients({ environment: { SystemRoot: 'C:\\Windows', ...(local ? { LOCALAPPDATA: local } : {}) }, isFile: async () => true, isAlias: async () => false });
    assert.equal(result.terminal, null); assert.equal(result.consoleHost, 'C:\\Windows\\System32\\conhost.exe');
  }
});
test('No available Terminal or Console Host returns a controlled host error', async () => {
  await assert.rejects(findWindowsSshClients({ environment: { SystemRoot: 'C:\\Windows', LOCALAPPDATA: 'C:\\Users\\Alex\\AppData\\Local' }, isFile: async path => path.endsWith('ssh.exe'), isAlias: async () => { throw new Error('alias disabled'); } }), code('SSH_HOST_MISSING'));
});
test('Terminal available uses new window with absolute ssh and separate login argument, supporting user/domain/UPN', async () => {
  for (const username of ['zigan', 'DOMAIN\\user', 'user@domain.test', 'Алексей']) {
    const calls: { file: string; args: readonly string[] }[] = [];
    await new WindowsSshProvider(async () => clients, async (file, args) => { calls.push({ file, args }); }).open({ host: 'HOME-PC', username, port: 22 });
    assert.deepEqual(calls, [{ file: clients.terminal, args: ['-w', '-1', 'new-tab', '--', clients.ssh, '-l', username, '-p', '22', '--', 'HOME-PC'] }]);
    assert.equal(calls[0]?.args.at(-1), 'HOME-PC'); // There is no argument after destination: no remote command.
  }
});
test('Terminal unavailable opens interactive Console Host directly, without PowerShell or cmd commands', async () => {
  let args: readonly string[] = []; const fallback = { ...clients, terminal: null, consoleHost: 'C:\\Windows\\System32\\conhost.exe' };
  await new WindowsSshProvider(async () => fallback, async (file, values) => { assert.equal(file, fallback.consoleHost); args = values; }).open({ host: '192.168.1.25', username: 'user@domain.test', port: 22 });
  assert.deepEqual(args, ['--', clients.ssh, '-l', 'user@domain.test', '-p', '22', '--', '192.168.1.25']);
  assert.ok(!args.some(value => /StrictHostKeyChecking|BatchMode|password|Command|cmd\.exe|powershell/i.test(value)));
});
test('Host spawn is detached shell:false, ignored stdio, resolves on spawn and does not wait for SSH exit', async () => {
  class Child extends EventEmitter { count = 0; unref(): void { this.count++; } }
  const child = new Child(); let done = false;
  const task = launchWindowsSshHost('host.exe', ['ssh.exe'], (file, args, options) => { assert.equal(file, 'host.exe'); assert.deepEqual(args, ['ssh.exe']); assert.deepEqual(options, { shell: false, detached: true, stdio: 'ignore', windowsHide: false }); return child; }).then(() => { done = true; });
  await tick(); assert.equal(done, false); child.emit('spawn'); await task; assert.equal(child.count, 1); child.emit('error', new Error('late')); assert.equal(done, true);
});
test('Host spawn error or synchronous throw returns SSH_LAUNCH_ERROR', async () => {
  class Child extends EventEmitter { unref(): void { assert.fail('not spawned'); } }
  const child = new Child(); const task = launchWindowsSshHost('host.exe', [], () => child); child.emit('error', new Error('ENOENT')); await assert.rejects(task, code('SSH_LAUNCH_ERROR'));
  await assert.rejects(launchWindowsSshHost('host.exe', [], () => { throw new Error('denied'); }), code('SSH_LAUNCH_ERROR'));
});
test('Hostile username/address cannot become flags, shell tokens, Terminal commands or remote commands', async () => {
  let calls = 0; const provider = new WindowsSshProvider(async () => { calls++; return clients; }, async () => { calls++; });
  const bad = ['a&b','a|b','a;b','a"b',"a'b",'a$b','a\nb','a b','-oProxyCommand=evil','ssh://host','host:22'];
  for (const value of bad) { await assert.rejects(provider.open({ host: value, username: 'user', port: 22 })); await assert.rejects(provider.open({ host: 'host', username: value, port: 22 })); }
  await assert.rejects(provider.open({ host: 'host', username: 'user', port: 3389 })); assert.equal(calls, 0);
  let found!: (value: typeof clients) => void;
  const target = { host: 'HOME-PC', username: 'DOMAIN\\user', port: 22 };
  const snapshotProvider = new WindowsSshProvider(() => new Promise(resolve => { found = resolve; }), async (_file, args) => {
    assert.equal(args.at(-1), 'HOME-PC'); assert.equal(args[6], 'DOMAIN\\user');
  });
  const pending = snapshotProvider.open(target); target.host = 'host;cmd'; target.username = '-flag'; found(clients); await pending;

});
test('Windows composition supplies SSH and RDP, other hosts have neither', () => {
  const platform = createPlatformService('win32'); assert.ok(platform.providers.ssh instanceof WindowsSshProvider); assert.ok(platform.providers.remoteDesktop); assert.ok(platform.providers.wakeOnLan);
  for (const host of ['linux','darwin'] as const) assert.equal(createPlatformService(host).providers.ssh, null);
});
test('SSH disabled, missing username, invalid computer and non-Windows remote never probe or launch', async () => {
  let probes = 0;
  for (const computer of [{ ...record, sshEnabled: false }, { ...record, username: null }, { ...record, operatingSystem: 'linux' as const }, { ...record, username: 'user;cmd' }, { ...record, localAddress: 'host|cmd' }]) {
    const ctx = setup(computer, async () => { probes++; return ready; }); await assert.rejects(ctx.service.open(record.id)); assert.equal(ctx.calls.length, 0);
  }
  assert.equal(probes, 0);
});
test('Unsupported host OS returns controlled error without network or process launch', async () => {
  let probes = 0; const service = new SshTerminalService({ get: () => record }, { checkSsh: async () => { probes++; throw new Error(); } }, null);
  await assert.rejects(service.open(record.id), code('SSH_UNSUPPORTED')); assert.equal(probes, 0);
});
test('Fresh SSH local ready uses stored username/local address and only probes TCP22', async () => {
  const hosts: string[] = []; const ctx = setup({ ...record, remoteAddress: '192.168.1.26', username: 'DOMAIN\\user' }, async (host, service) => { assert.equal(service,'ssh'); hosts.push(host); return ready; });
  const result = await ctx.service.open(record.id); assert.equal(result.state, 'terminal-opened'); assert.deepEqual(hosts, [record.localAddress]); assert.equal(ctx.calls[0]?.host, record.localAddress); assert.equal(ctx.calls[0]?.username,'DOMAIN\\user');
  await ctx.service.open(record.id); assert.equal(hosts.length,2);
});
test('Fresh local failure falls back to the saved remote address', async () => {
  const hosts: string[] = []; const ctx = setup({ ...record, remoteAddress: '192.168.1.26' }, async host => { hosts.push(host); return host === record.localAddress ? unavailable : ready; });
  const result = await ctx.service.open(record.id); assert.deepEqual(hosts, [record.localAddress,'192.168.1.26']); assert.equal(ctx.calls[0]?.host,'192.168.1.26'); assert.equal(result.ssh.addressKind,'remote');
});
test('Both unavailable and fresh failure after old ready never launch a terminal', async () => {
  let online = true; const ctx = setup({ ...record, remoteAddress: '192.168.1.26' }, async () => online ? ready : unavailable);
  await ctx.service.open(record.id); online=false; await assert.rejects(ctx.service.open(record.id),code('SSH_UNAVAILABLE')); assert.equal(ctx.calls.length,1);
});
test('Duplicate SSH check/launch is blocked; failure clears guard and permits retry', async () => {
  let checked!: (value: TcpProbeResult) => void; let launched!: () => void;
  const ctx = setup(record, () => new Promise(resolve => { checked = resolve; }), () => new Promise(resolve => { launched=resolve; }));
  const task=ctx.service.open(record.id); await tick(); await assert.rejects(ctx.service.open(record.id),code('SSH_BUSY')); checked(ready); await tick(); await assert.rejects(ctx.service.open(record.id),code('SSH_BUSY')); launched(); await task; assert.equal(ctx.calls.length,1); assert.equal(ctx.pending.size,0);
  let fail=true; const retry=setup(record,async()=>ready,async()=>{if(fail)throw new Error('spawn failed');}); const handler=createSshRequestHandler(()=>{},retry.service);
  assert.equal((await handler({},record.id)).ok,false); fail=false; assert.equal((await handler({},record.id)).ok,true);
});
test('RDP and SSH share one active launch per computer in the composition boundary', async () => {
  let finish!: () => void; const ctx=setup(record,async()=>ready,()=>new Promise(resolve=>{finish=resolve;}));
  const rdp=new RemoteDesktopService(ctx.store,ctx.checks,{id:'rdp-mock',open:async()=>assert.fail('must not launch during SSH')},ctx.pending);
  const task=ctx.service.open(record.id); await tick(); await assert.rejects(rdp.open(record.id),code('RDP_BUSY')); finish();await task;
  ctx.pending.set(record.id,new AbortController()); await assert.rejects(ctx.service.open(record.id),code('SSH_BUSY'));ctx.pending.clear();
});
test('Edit/delete/abort during fresh check prevent launch; provider also checks abort after discovery', async () => {
  for (const mode of ['edit','delete','abort']) {
    let finish!: (value: TcpProbeResult) => void; const ctx=setup(record,()=>new Promise(resolve=>{finish=resolve;}));const task=ctx.service.open(record.id);await tick();
    if(mode==='edit')ctx.setComputer({...record,username:'changed'});else if(mode==='delete')ctx.deleteComputer();else ctx.service.cancelPending();
    finish(ready);await assert.rejects(task);assert.equal(ctx.calls.length,0);assert.equal(ctx.pending.size,0);
  }
  let found!: (value: typeof clients) => void;let launches=0;const controller=new AbortController();const provider=new WindowsSshProvider(()=>new Promise(resolve=>{found=resolve;}),async()=>{launches++;});
  const task=provider.open({host:'host',username:'user',port:22,signal:controller.signal});controller.abort();found(clients);await assert.rejects(task,CheckCancelledError);assert.equal(launches,0);
});
test('Fresh SSH uses the existing global check pool and does not supersede status refresh', async () => {
  const computers=Array.from({length:8},(_,i)=>({...record,id:`${String(i+1).repeat(8)}-1111-4111-8111-111111111111`,rdpEnabled:false}));let probes=0;const releases:(()=>void)[]=[];
  const checks=new CheckCoordinator({get:()=>record,list:()=>computers},new NetworkService(()=>{probes++;return new Promise(resolve=>releases.push(()=>resolve(ready)));}));
  const refresh=checks.refreshAllComputerStatuses();await tick();assert.equal(probes,8);const fresh=checks.checkSsh(record,new AbortController().signal);await tick();assert.equal(probes,8);releases.shift()?.();await tick();assert.equal(probes,9);for(const release of releases)release();await refresh;await fresh;
});
test('SSH IPC authorizes sender/frame first and rejects extra parameters and forged targets', async () => {
  const frame={url:'nexus://app/index.html'};const contents={mainFrame:frame};const window={webContents:contents,isDestroyed:()=>false};const good={sender:contents,senderFrame:frame};const ctx=setup();
  const handler=createSshRequestHandler((event:typeof good)=>{if(!isTrustedIpcSender(event,window,frame.url))throw new Error('untrusted');},ctx.service);
  for(const event of [{sender:{mainFrame:frame},senderFrame:frame},{sender:contents,senderFrame:{url:frame.url}},{sender:contents,senderFrame:{url:'https://evil.test'}}])await assert.rejects(handler(event,record.id));
  const extra=await handler(good,record.id,{host:'evil',username:'evil',port:80,executable:'evil.exe',args:['command']});assert.equal(extra.ok,false);
  for(const id of [null,'bad',{id:record.id,host:'evil',command:'whoami'}]){const reply=await handler(good,id);assert.equal(reply.ok,false);if(!reply.ok)assert.equal(reply.error.code,'VALIDATION_ERROR');}assert.equal(ctx.calls.length,0);
});
test('Demo SSH bypasses all user capabilities; user SSH transmits ID only and WoL stays inactive', () => {
  let demo=0;const ids:string[]=[];
  for(const action of ['ssh','rdp','wake','wake-rdp'] as const)performComputerAction(true,record,action,()=>{demo++;},()=>assert.fail('demo RDP'),id=>ids.push(id));
  assert.equal(demo,4);assert.equal(ids.length,0);performComputerAction(false,record,'ssh',()=>assert.fail('user demo'),()=>assert.fail('user RDP'),id=>ids.push(id));assert.deepEqual(ids,[record.id]);
  performComputerAction(false,record,'wake',()=>assert.fail(),()=>assert.fail(),()=>assert.fail());
});
