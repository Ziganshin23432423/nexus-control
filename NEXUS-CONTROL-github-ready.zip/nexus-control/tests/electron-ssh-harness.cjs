// Test-only entry. Loads unchanged production main; renderer has no harness API.
// Linux cannot bind TCP22: after production unsupported/security checks, explicit
// mock phase replaces ONLY narrow status/SSH handlers with DI production classes.
const { ipcMain, BrowserWindow } = require('electron');
const { readFileSync } = require('node:fs');
const { pathToFileURL } = require('node:url');
let environment;
const clientPaths={ssh:'C:\\Windows\\System32\\OpenSSH\\ssh.exe',terminal:'C:\\Users\\Alex\\AppData\\Local\\Microsoft\\WindowsApps\\wt.exe',consoleHost:'C:\\Windows\\System32\\conhost.exe'};
globalThis.__nexusSshQa={
 async install({project,file}){
  const load=relative=>import(pathToFileURL(project+'/.test-out/'+relative).href);
  const {ComputerStore}=await load('src/main/services/computerStore.js');
  const {NetworkService}=await load('src/main/services/networkService.js');
  const {CheckCoordinator}=await load('src/main/services/checkCoordinator.js');
  const {SshTerminalService}=await load('src/main/services/sshTerminalService.js');
  const {WindowsSshProvider}=await load('src/main/providers/windows/WindowsSshProvider.js');
  const {createSshRequestHandler}=await load('src/main/ipc/sshRequest.js');
  const {isTrustedIpcSender}=await load('src/main/ipc/trustedSender.js');
  const {SshError}=await load('src/main/services/sshError.js');
  environment={ready:true,fail:false,hold:false,style:'terminal',calls:[],probes:[],release:null};
  const store=new ComputerStore({read:()=>JSON.parse(readFileSync(file,'utf8')).configuration,write:()=>{throw new Error('QA must never normalize/write');}});
  const network=new NetworkService(async(address,service,signal)=>{
   environment.probes.push({address,service});
   if(signal?.aborted)return {status:'unavailable',latencyMs:null,errorCode:'CANCELLED'};
   return (service==='rdp'||environment.ready)&&address==='127.0.0.1'?{status:'ready',latencyMs:1,errorCode:null}:{status:'unavailable',latencyMs:null,errorCode:'ECONNREFUSED'};
  });
  const checks=new CheckCoordinator(store,network);
  const provider=new WindowsSshProvider(async()=>environment.style==='terminal'?{...clientPaths,consoleHost:null}:{...clientPaths,terminal:null},async(executable,args)=>{
   environment.calls.push({executable,args:[...args]});
   if(environment.fail)throw new SshError('SSH_LAUNCH_ERROR','Не удалось открыть SSH-терминал.');
   if(environment.hold)await new Promise(resolve=>environment.release=resolve);
  });
  const service=new SshTerminalService(store,checks,provider);
  const main=BrowserWindow.getAllWindows()[0];const url=main.webContents.getURL();
  const trusted=event=>{if(!isTrustedIpcSender(event,main,url))throw new Error('untrusted sender');};
  const sshHandler=createSshRequestHandler(trusted,service);
  for(const name of ['nexus:ssh:open-terminal','nexus:status:refresh-all','nexus:status:check-computer','nexus:status:cancel'])ipcMain.removeHandler(name);
  ipcMain.handle('nexus:ssh:open-terminal',sshHandler);
  const status=operation=>async(event,id)=>{trusted(event);try{return {ok:true,value:await operation(id)};}catch(error){return {ok:false,error:{code:error.code||'CANCELLED',message:'QA check cancelled'}};}};
  ipcMain.handle('nexus:status:refresh-all',status(()=>checks.refreshAllComputerStatuses()));
  ipcMain.handle('nexus:status:check-computer',status(id=>checks.checkComputerStatus(id)));
  ipcMain.handle('nexus:status:cancel',event=>{trusted(event);checks.cancel();});
  // Cancel in-flight mock launches on mutations/quit in this test-only object.
  main.once('closed',()=>service.cancelPending());
 },
 configure(values){for(const key of ['ready','fail','hold','style'])if(key in values)environment[key]=values[key];},
 snapshot(){return {calls:environment.calls,probes:environment.probes};},
 release(){environment.hold=false;const release=environment.release;environment.release=null;if(release)release();}
};
import('../out/main/main.js').catch(error=>{console.error(error);process.exitCode=1;});
