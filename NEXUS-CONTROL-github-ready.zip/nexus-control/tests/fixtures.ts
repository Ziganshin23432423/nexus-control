import type { ComputerDraft } from '../src/shared/types.js';
export const draft: ComputerDraft = { name: 'PC HOME', operatingSystem: 'windows', hostname: 'HOME-PC', localAddress: '192.168.1.25', remoteAddress: null, macAddress: 'AA-BB-CC-DD-EE-FF', username: 'zigan', rdpEnabled: true, sshEnabled: true, wakeOnLan: { broadcastAddress: '192.168.1.255', port: 9 }, notes: '' };
export const record = { ...draft, macAddress: 'AA:BB:CC:DD:EE:FF', id: '11111111-1111-4111-8111-111111111111', createdAt: '2026-10-01T00:00:00.000Z', updatedAt: '2026-10-01T00:00:00.000Z' };
