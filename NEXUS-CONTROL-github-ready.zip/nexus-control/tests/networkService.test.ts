import { test } from 'node:test';
import assert from 'node:assert/strict';
import { record } from './fixtures.js';
import { CheckCancelledError, NetworkService } from '../src/main/services/networkService.js';
import type { TcpProbe, TcpProbeResult } from '../src/main/services/tcpProbe.js';
import { ComputerStoreError } from '../src/main/services/computerStore.js';
const ready: TcpProbeResult = { status: 'ready', latencyMs: 12, errorCode: null };
const refused: TcpProbeResult = { status: 'unavailable', latencyMs: null, errorCode: 'ECONNREFUSED' };
test('Local success never probes remote, each configured service has its own result', async () => {
  const calls: string[] = [];
  const network = new NetworkService(async (address,service) => { calls.push(service + ':' + address); return ready; });
  const result = await network.check({ ...record, remoteAddress: 'remote.local' });
  assert.equal(result.status,'online'); assert.equal(result.rdp,'ready'); assert.equal(result.ssh,'ready'); assert.equal(result.wakeOnLan,'configured');
  assert.deepEqual(calls,['rdp:'+record.localAddress,'ssh:'+record.localAddress]); assert.ok(result.services?.every((item) => item.addressKind==='local' && item.latencyMs===12 && item.attempts.length===1)); assert.equal(result.configUpdatedAt,record.updatedAt);
});
test('Controlled fallback records remote success after local failure, independently per service', async () => {
  const calls: string[] = []; const probe: TcpProbe = async (address,service) => { calls.push(service + ':' + address); return address==='remote.local' && service==='rdp' ? ready : refused; };
  const result = await new NetworkService(probe).check({ ...record, remoteAddress:'remote.local' });
  assert.equal(result.status,'online'); assert.equal(result.rdp,'ready'); assert.equal(result.ssh,'unavailable');
  assert.equal(result.services?.[0]?.addressUsed,'remote.local'); assert.equal(result.services?.[0]?.addressKind,'remote'); assert.equal(result.services?.[0]?.attempts.length,2); assert.equal(result.services?.[1]?.addressUsed,null); assert.equal(result.services?.[1]?.errorCode,'ECONNREFUSED'); assert.equal(calls.length,4);
});
test('Both addresses unavailable means offline; identical remote is never tried twice', async () => {
  let calls=0; const network = new NetworkService(async()=>{calls++;return refused;});
  const result=await network.check({ ...record, remoteAddress:'remote.local' }); assert.equal(result.status,'offline'); assert.equal(calls,4);
  calls=0; await network.check({ ...record, localAddress:'HOME.local',remoteAddress:'home.LOCAL' }); assert.equal(calls,2);
});
test('RDP-only, SSH-only and no services never probe disabled ports', async () => {
  for (const enabled of ['rdp','ssh','none']) {
    const calls: string[]=[]; const result=await new NetworkService(async(_,service)=>{calls.push(service);return ready;}).check({ ...record, rdpEnabled:enabled==='rdp',sshEnabled:enabled==='ssh' });
    assert.deepEqual(calls,enabled==='none'?[]:[enabled]); assert.equal(result.status,enabled==='none'?'no-services':'online'); assert.equal(result.rdp,enabled==='rdp'?'ready':'disabled'); assert.equal(result.ssh,enabled==='ssh'?'ready':'disabled');
  }
});
test('Invalid stored computer prevents every connection', async () => {
  let calls=0; const network=new NetworkService(async()=>{calls++;return ready;});
  for (const computer of [{ ...record, localAddress:'host;cmd' },{ ...record,id:'demo-pc-home' },{ ...record, password:'secret' },{ ...record,wakeOnLan:{broadcastAddress:'256.1.1.1',port:9} }]) await assert.rejects(network.check(computer), ComputerStoreError);
  assert.equal(calls,0);
});
test('RDP and SSH run in parallel, and cancellation waits for both probes to clean up', async () => {
  const controller=new AbortController(); let active=0; let peak=0;
  const resolves: (()=>void)[]=[];
  const network=new NetworkService(async()=>{active++;peak=Math.max(peak,active);return await new Promise<TcpProbeResult>((resolve)=>resolves.push(()=>{active--;resolve(refused);}));});
  const pending=network.check(record,controller.signal); assert.equal(peak,2); controller.abort(); resolves[0]?.(); let settled=false; void pending.catch(()=>{settled=true;}); await Promise.resolve(); await Promise.resolve(); assert.equal(settled,false); resolves[1]?.(); await assert.rejects(pending,CheckCancelledError); assert.equal(active,0);
});
test('Abort between local and remote never starts fallback', async () => {
  const controller=new AbortController(); let calls=0; const network=new NetworkService(async()=>{calls++;controller.abort();return refused;});
  await assert.rejects(network.check({ ...record,sshEnabled:false,remoteAddress:'remote.local' },controller.signal),CheckCancelledError); assert.equal(calls,1);
});
