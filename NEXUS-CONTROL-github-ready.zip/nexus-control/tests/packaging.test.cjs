const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const config=JSON.parse(fs.readFileSync('electron-builder.json'));
const pkg=JSON.parse(fs.readFileSync('package.json'));
test('RC identity and fixed per-user installer preserve Stage12 data',()=>{
  assert.equal(pkg.version,'1.0.0-rc.1');
  assert.equal(config.appId,'network.onion.nexus-control');
  assert.equal(config.productName,'NEXUS CONTROL');
  assert.equal(config.buildVersion,'1.0.0.1');
  assert.equal(config.buildNumber,'1');
  for(const key of ['perMachine','allowElevation','packElevateHelper','deleteAppDataOnUninstall','createDesktopShortcut'])assert.equal(config.nsis[key],false,key);
  assert.equal(config.nsis.createStartMenuShortcut,true);
  assert.equal(config.win.requestedExecutionLevel,'asInvoker');
  assert.equal(config.win.signAndEditExecutable,true);
  assert.equal(config.win.signExecutable,false);
  assert.equal(config.publish,null);
  assert.equal(config.asar,true);
  assert.deepEqual(config.files,['out/**/*','package.json']);
  assert.equal(config.nsis.include,undefined);
  assert.equal(config.nsis.script,undefined);
  const main=fs.readFileSync('src/main/main.ts','utf8');
  assert.ok(main.includes('app.setName(APP_NAME)'));
  assert.ok(main.includes("createElectronStoreRepository(app.getPath('userData'))"));
  assert.ok(!main.includes("setPath('userData'"));
});
test('Windows ICO contains every intended readable size and original brand source',()=>{
  assert.deepEqual(fs.readFileSync('build/nexus-mark.svg'),fs.readFileSync('src/renderer/public/nexus-mark.svg'));
  const b=fs.readFileSync('build/icon.ico');assert.equal(b.readUInt16LE(2),1);
  const sizes=[];for(let i=0;i<b.readUInt16LE(4);i++){
    const o=6+16*i;const w=b[o]||256;assert.equal(w,b[o+1]||256);
    assert.ok(b.readUInt32LE(o+12)+b.readUInt32LE(o+8)<=b.length);sizes.push(w);
  }
  assert.deepEqual(sizes,[16,20,24,32,40,48,64,128,256]);
});
