import { test } from 'node:test';
import assert from 'node:assert/strict';
import { record } from './fixtures.js';
import { StatusRequests } from '../src/renderer/state/statusRequests.js';
import type { ConnectionCheckResult } from '../src/shared/types.js';
const result: ConnectionCheckResult={computerId:record.id,configUpdatedAt:record.updatedAt,status:'online',rdp:'ready',ssh:'ready',wakeOnLan:'configured',checkedAt:record.updatedAt};
test('Request generation ignores the first slow reply after a second refresh',async()=>{
 const gate=new StatusRequests();const computers=[record];const first=gate.begin();let resolveOld:((value:ConnectionCheckResult[])=>void)|undefined;const old=new Promise<ConnectionCheckResult[]>(resolve=>{resolveOld=resolve;});const latest=gate.begin();let displayed='checking';
 const accept=(id:number,results:ConnectionCheckResult[])=>{if(gate.canApply(id,computers,computers,results))displayed=results[0]?.status??'unknown';};
 accept(latest,[{...result,status:'offline',rdp:'unavailable',ssh:'unavailable'}]);resolveOld?.([result]);accept(first,await old);assert.equal(displayed,'offline');
});
test('Deleted/edited snapshots, cancellation, wrong ID or version cannot update renderer',()=>{
 const gate=new StatusRequests();const computers=[record];const token=gate.begin();assert.ok(gate.canApply(token,computers,computers,[result]));
 assert.equal(gate.canApply(token,computers,[],[result]),false);assert.equal(gate.canApply(token,computers,[{...record,name:'EDITED'}],[result]),false);assert.equal(gate.canApply(token,computers,computers,[{...result,computerId:'other'}]),false);assert.equal(gate.canApply(token,computers,computers,[{...result,configUpdatedAt:'future'}]),false);gate.invalidate();assert.equal(gate.canApply(token,computers,computers,[result]),false);
});

test('Partial, duplicate and false ONLINE results rejected; single explicit target stays valid',()=>{
 const gate=new StatusRequests();const other={...record,id:'22222222-2222-4222-8222-222222222222'};const computers=[record,other];const token=gate.begin();
 assert.equal(gate.canApply(token,computers,computers,[result]),false);
 assert.equal(gate.canApply(token,computers,computers,[result,result]),false);
 assert.equal(gate.canApply(token,computers,computers,[result],[record]),true);
 assert.equal(gate.canApply(token,computers,computers,[{...result,rdp:'unavailable',ssh:'unavailable'}],[record]),false);
});
