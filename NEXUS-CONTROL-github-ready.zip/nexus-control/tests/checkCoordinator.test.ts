import { test } from 'node:test';
import assert from 'node:assert/strict';
import { setImmediate as nextTurn } from 'node:timers/promises';
import { record } from './fixtures.js';
import { CheckCoordinator } from '../src/main/services/checkCoordinator.js';
import { CheckCancelledError, NetworkService } from '../src/main/services/networkService.js';
import { ComputerStore } from '../src/main/services/computerStore.js';
import { COMPUTER_CHECK_CONCURRENCY } from '../src/shared/networkConstants.js';
import type { TcpProbe, TcpProbeResult } from '../src/main/services/tcpProbe.js';
import type { Computer } from '../src/shared/types.js';
const success: TcpProbeResult={ status:'ready',latencyMs:1,errorCode:null };
function records(count: number): Computer[] { return Array.from({length:count},(_,i)=>({ ...record,id:`${i.toString(16).padStart(8,'0')}-1111-4111-8111-111111111111`,localAddress:'localhost',sshEnabled:false })); }
test('Refresh all limits the global number of computers, including overlapping refreshes', async()=>{
  const computers=records(23); let active=0,peak=0; let calls=0; const release: (()=>void)[]=[];
  const probe: TcpProbe=async(_,__,signal)=>{calls++;active++;peak=Math.max(peak,active);return await new Promise<TcpProbeResult>((resolve)=>{
    let done=false; const finish=()=>{if(done)return;done=true;signal?.removeEventListener('abort',abort);active--;resolve(signal?.aborted?{status:'unavailable',latencyMs:null,errorCode:'CANCELLED'}:success);};
    const abort=()=>{void nextTurn().then(finish);};signal?.addEventListener('abort',abort,{once:true});release.push(finish);
  });};
  const coordinator=new CheckCoordinator({get:(id)=>{const value=computers.find(c=>c.id===id);assert.ok(value);return value;},list:()=>computers},new NetworkService(probe));
  const old=coordinator.refreshAllComputerStatuses();const oldRejected=assert.rejects(old,CheckCancelledError);await nextTurn();assert.equal(active,COMPUTER_CHECK_CONCURRENCY);
  const latest=coordinator.refreshAllComputerStatuses();await oldRejected;
  while(calls<COMPUTER_CHECK_CONCURRENCY+computers.length || active>0){release.splice(0).forEach(fn=>fn());await nextTurn();}
  assert.equal((await latest).length,computers.length);assert.equal(peak,COMPUTER_CHECK_CONCURRENCY);assert.equal(active,0);
});
test('ID-only check loads and revalidates storage; invalid input never opens sockets', async()=>{
  let calls=0;let data:unknown={schemaVersion:1,computers:[record]};const store=new ComputerStore({read:()=>data,write:(value)=>{data=value;}});
  const coordinator=new CheckCoordinator(store,new NetworkService(async()=>{calls++;return success;}));
  await assert.rejects(coordinator.checkComputerStatus({host:'localhost',port:80}));await assert.rejects(coordinator.checkComputerStatus('demo-pc-home'));assert.equal(calls,0);
  assert.equal((await coordinator.checkComputerStatus(record.id)).status,'online');assert.equal(calls,2);
  data={schemaVersion:1,computers:[{...record,localAddress:'bad;host'}]};await assert.rejects(coordinator.refreshAllComputerStatuses());assert.equal(calls,2);
});
test('Cancellation and external edit prevent obsolete snapshots from being returned',async()=>{
  let computers=records(1);let release:(()=>void)|undefined;
  const coordinator=new CheckCoordinator({get:()=>{const item=computers[0];assert.ok(item);return item;},list:()=>computers},new NetworkService(async()=>await new Promise<TcpProbeResult>(resolve=>{release=()=>resolve(success);}))); 
  const pending=coordinator.refreshAllComputerStatuses();const rejected=assert.rejects(pending,CheckCancelledError);await nextTurn();computers=computers.map(c=>({...c,name:'EDITED'}));release?.();await rejected;
  const pending2=coordinator.refreshAllComputerStatuses();const rejected2=assert.rejects(pending2,CheckCancelledError);await nextTurn();coordinator.cancel();release?.();await rejected2;
});
