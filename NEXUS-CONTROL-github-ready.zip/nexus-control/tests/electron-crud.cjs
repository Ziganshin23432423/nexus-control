// CRUD regression QA uses only loopback for user records.
// Optional actual Electron QA: requires a separate Playwright installation.
// Uses an isolated temporary profile; never touches the normal user configuration.
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const { _electron } = require(process.env.NEXUS_PLAYWRIGHT_PATH || 'playwright');
const project = path.resolve(__dirname, '..');
const output = process.env.NEXUS_QA_OUTPUT || path.join(require('node:os').tmpdir(), 'nexus-control-stage3-' + Date.now());
const profile = path.join(output,'profile-'+Date.now());
const checks=[]; const errors=[];
let app,page,file;
const draft={name:'PC HOME',operatingSystem:'windows',hostname:'HOME-PC',localAddress:'127.0.0.1',remoteAddress:null,macAddress:'AA-BB-CC-DD-EE-FF',username:'zigan',rdpEnabled:true,sshEnabled:true,wakeOnLan:{broadcastAddress:'127.0.0.15',port:9},notes:''};
async function launch() {
 const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;delete env.ELECTRON_RENDERER_URL;
 app=await _electron.launch({executablePath:path.join(project,'node_modules/electron/dist',process.platform==='win32'?'electron.exe':'electron'),args:[...(process.env.NEXUS_QA_NO_SANDBOX === '1' ? ['--no-sandbox'] : []),`--user-data-dir=${profile}`,'.'],cwd:project,env,timeout:30000});
 page=await app.firstWindow();page.setDefaultTimeout(8000);page.on('pageerror',e=>errors.push(e.message));
 await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setContentSize(1280,720));
 await page.getByRole('combobox',{name:'Источник данных'}).waitFor();
 file=path.join(await app.evaluate(({app})=>app.getPath('userData')),'computers.json');
}
async function close(){
 const current=app; let watchdog;
 try { await Promise.race([current.close(),new Promise((_,reject)=>{watchdog=setTimeout(()=>{current.process().kill('SIGKILL');reject(new Error('Electron close exceeded 20s'));},20000);})]);app=null; }
 finally { clearTimeout(watchdog); }
}
async function test(name,fn){await fn();checks.push({name,result:'passed'});console.log('PASS '+name);}
async function add(name,address){
 await page.getByRole('button',{name:'Добавить компьютер',exact:true}).click();
 const dialog=page.getByRole('dialog');await dialog.getByRole('textbox',{name:'Название',exact:false}).fill(name);await dialog.getByRole('textbox',{name:'Локальный IP / hostname',exact:false}).fill(address);
 await dialog.getByRole('button',{name:'Добавить компьютер',exact:true}).click();await dialog.waitFor({state:'hidden'});
 await page.getByRole('article',{name,exact:true}).waitFor();
}
async function screenshot(name){const buttons=page.getByRole('button',{name:/^Закрыть уведомление:/});if (!await page.locator('dialog[open]').count()) { while(await buttons.count()) await buttons.first().click(); }await page.screenshot({path:path.join(output,name+'.png'),animations:'disabled'});}
async function run(){await fs.mkdir(output,{recursive:true});await launch();
 await test('User data opens empty, never seeds demo fixtures',async()=>{await page.getByRole('heading',{name:'У вас пока нет компьютеров.'}).waitFor();assert.equal(await page.getByRole('article').count(),0);const data=JSON.parse(await fs.readFile(file,'utf8'));assert.deepEqual(data,{configuration:{schemaVersion:1,computers:[]}});});
 await test('Shared form validation keeps invalid input open, then main persists normalized configuration',async()=>{
 await page.getByRole('button',{name:'Добавить компьютер',exact:true}).click();let dialog=page.getByRole('dialog');await dialog.getByRole('textbox',{name:'Название',exact:false}).fill('PC HOME');await dialog.getByRole('textbox',{name:'Локальный IP / hostname',exact:false}).fill('256.1.1.1');await dialog.getByRole('button',{name:'Добавить компьютер',exact:true}).click();await dialog.getByRole('alert').waitFor();assert.equal(JSON.parse(await fs.readFile(file,'utf8')).configuration.computers.length,0);
 await dialog.getByRole('textbox',{name:'Локальный IP / hostname',exact:false}).fill(draft.localAddress);await dialog.getByRole('textbox',{name:'Hostname',exact:true}).fill(draft.hostname);await dialog.getByRole('textbox',{name:'MAC-адрес',exact:false}).fill(draft.macAddress);await dialog.getByRole('textbox',{name:'Имя пользователя',exact:false}).fill(draft.username);await dialog.getByText('SSH',{exact:true}).click();await dialog.getByText('Wake-on-LAN',{exact:true}).click();await dialog.getByRole('textbox',{name:'Broadcast address',exact:false}).fill(draft.wakeOnLan.broadcastAddress);await dialog.getByRole('button',{name:'Добавить компьютер',exact:true}).click();await dialog.waitFor({state:'hidden'});await page.getByRole('article',{name:'PC HOME',exact:true}).waitFor();
 const saved=JSON.parse(await fs.readFile(file,'utf8')).configuration.computers[0];assert.match(saved.id,/^[a-f0-9-]{36}$/);assert.equal(saved.macAddress,'AA:BB:CC:DD:EE:FF');assert.equal(saved.wakeOnLan.port,9);assert.equal(saved.notes,'');assert.equal(saved.createdAt,saved.updatedAt);assert.equal(Object.keys(saved).length,14);await page.waitForFunction(()=>document.querySelectorAll('.status-checking').length===0);assert.equal(await page.locator('.status-unknown').count(),0);await screenshot('stage3-main');
 });
 let original;
 await test('Edit retains main ID and createdAt; user connection actions disabled',async()=>{
 original=JSON.parse(await fs.readFile(file,'utf8')).configuration.computers[0];await page.getByRole('button',{name:'Открыть PC HOME',exact:true}).click({position:{x:120,y:40}});await page.getByRole('heading',{name:'PC HOME',exact:true}).waitFor();assert.ok(await page.getByRole('button',{name:'Удалённый рабочий стол',exact:true}).isDisabled());assert.ok(await page.getByRole('button',{name:'SSH-терминал',exact:true}).isDisabled());await screenshot('stage3-computer');
 await page.getByRole('button',{name:'Редактировать',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.getByRole('textbox',{name:'Название',exact:false}).fill('PC HOME EDITED');await dialog.getByRole('textbox',{name:'Удалённый / VPN IP',exact:false}).fill('127.0.0.2');await dialog.getByRole('button',{name:'Сохранить изменения',exact:true}).click();await dialog.waitFor({state:'hidden'});const edited=JSON.parse(await fs.readFile(file,'utf8')).configuration.computers[0];assert.equal(edited.id,original.id);assert.equal(edited.createdAt,original.createdAt);assert.ok(edited.updatedAt>=original.updatedAt);assert.equal(edited.remoteAddress,'127.0.0.2');
 });
 await test('Full Electron restart restores edited user data',async()=>{await close();await launch();await page.getByRole('article',{name:'PC HOME EDITED',exact:true}).waitFor();assert.equal(await page.getByRole('combobox',{name:'Источник данных'}).inputValue(),'user');});
 await test('Main independently rejects forged metadata, secrets, unsafe strings and demo IDs',async()=>{
 const before=await fs.readFile(file,'utf8');const results=await page.evaluate(async draft=>{
 const invalid=[{...draft,password:'secret'},{...draft,id:'forged'},{...draft,createdAt:new Date().toISOString()},{...draft,localAddress:'host;cmd'},{...draft,rdpEnabled:'true'},{...draft,operatingSystem:'linux'}];const results=[];for(const item of invalid)results.push(await window.nexus.createComputer(item));results.push(await window.nexus.deleteComputer('demo-pc-home'));results.push(await window.nexus.updateComputer('invalid',draft));return results;},draft);
 for(const result of results){assert.equal(result.ok,false);assert.equal(result.error.code,'VALIDATION_ERROR');}assert.equal(await fs.readFile(file,'utf8'),before);
 });
 await test('Main storage failure leaves add form open and does not acknowledge save',async()=>{
 const good=await fs.readFile(file,'utf8');await page.getByRole('button',{name:'Добавить компьютер',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.getByRole('textbox',{name:'Название',exact:false}).fill('RETRY PC');await dialog.getByRole('textbox',{name:'Локальный IP / hostname',exact:false}).fill('127.0.0.1');const bad=JSON.stringify({configuration:{schemaVersion:99,computers:[]}});await fs.writeFile(file,bad);await dialog.getByRole('button',{name:'Добавить компьютер',exact:true}).click();await dialog.getByRole('alert').waitFor();assert.equal(await fs.readFile(file,'utf8'),bad);assert.equal(await dialog.getByRole('textbox',{name:'Название',exact:false}).inputValue(),'RETRY PC');await fs.writeFile(file,good);assert.equal(await fs.readFile(file,'utf8'),good,'QA restoration must complete before demo CRUD');assert.equal((await page.evaluate(()=>window.nexus.listComputers())).ok,true,'Main must read restored configuration');await dialog.getByRole('button',{name:'Отмена',exact:true}).click();assert.equal(await page.getByRole('article').count(),1);
 });
 await test('Demo CRUD and mock actions never change user file',async()=>{
 const before=await fs.readFile(file,'utf8');await page.getByRole('combobox',{name:'Источник данных'}).selectOption('demo-computers');await page.getByRole('article',{name:'MAIN PC',exact:true}).waitFor();assert.equal(await page.getByRole('article').count(),2);
 await page.getByRole('article',{name:'PC HOME',exact:true}).getByRole('button',{name:'Включить',exact:true}).click();await page.getByText('Включаем компьютер…',{exact:true}).waitFor();await page.getByRole('button',{name:'Отмена',exact:true}).click();await add('DEMO ONLY','demo.local');await page.getByRole('button',{name:'Открыть DEMO ONLY',exact:true}).click({position:{x:120,y:40}});await page.getByRole('button',{name:'Редактировать',exact:true}).click();let dialog=page.getByRole('dialog');await dialog.getByRole('textbox',{name:'Название',exact:false}).fill('DEMO EDITED');await dialog.getByRole('button',{name:'Сохранить изменения',exact:true}).click();await dialog.waitFor({state:'hidden'});await page.getByRole('button',{name:'Удалить',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Удалить компьютер',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden'});assert.equal(await fs.readFile(file,'utf8'),before);await page.getByRole('combobox',{name:'Источник данных'}).selectOption('user');await page.getByRole('article',{name:'PC HOME EDITED',exact:true}).waitFor();assert.equal(await page.getByRole('article').count(),1);
 });
 await test('Delete cancellation, confirmation and persistence after restart',async()=>{
 await add('SECOND PC','127.0.0.1');await page.getByRole('button',{name:'Открыть SECOND PC',exact:true}).click({position:{x:120,y:40}});await page.getByRole('button',{name:'Удалить',exact:true}).click();await screenshot('stage3-delete');await page.getByRole('dialog').getByRole('button',{name:'Отмена',exact:true}).click();assert.equal(JSON.parse(await fs.readFile(file,'utf8')).configuration.computers.length,2);await page.getByRole('button',{name:'Удалить',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Удалить компьютер',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden'});await close();await launch();await page.getByRole('article',{name:'PC HOME EDITED',exact:true}).waitFor();assert.equal(await page.getByRole('article').count(),1);
 });
 await test('Secure typed bridge and renderer isolation',async()=>{
 const data=await page.evaluate(()=>({methods:Object.keys(window.nexus).sort(),node:[typeof window.require,typeof window.process,typeof window.Buffer],storage:[localStorage.length,sessionStorage.length]}));assert.deepEqual(data.methods,['cancelComputerStatusChecks','cancelWakeAndConnect','checkComputerStatus','createComputer','deleteComputer','getAppInfo','listComputers','onWakeAndConnectProgress','openRemoteDesktop','openSshTerminal','refreshAllComputerStatuses','updateComputer','wakeAndOpenRemoteDesktop','wakeAndOpenSshTerminal','wakeComputer']);assert.deepEqual(data.node,['undefined','undefined','undefined']);assert.deepEqual(data.storage,[0,0]);const prefs=await app.evaluate(({BrowserWindow})=>{const p=BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences();return {sandbox:p.sandbox,contextIsolation:p.contextIsolation,nodeIntegration:p.nodeIntegration};});assert.deepEqual(prefs,{sandbox:true,contextIsolation:true,nodeIntegration:false});
 });
 await test('CRUD IPC rejects a second window even with the trusted URL and preload',async()=>{
 const other=await app.evaluateHandle(async ({BrowserWindow},preload)=>{const first=BrowserWindow.getAllWindows()[0];const other=new BrowserWindow({show:false,webPreferences:{preload,nodeIntegration:false,contextIsolation:true,sandbox:true}});await other.loadURL(first.webContents.getURL());return other;},path.join(project,'out/preload/preload.cjs'));
 const rejected=await other.evaluate(async win=>win.webContents.executeJavaScript('window.nexus.listComputers().then(() => false, () => true)'));
 assert.equal(rejected,true);await other.evaluate(win=>win.destroy());await other.dispose();
 });
 await test('Corrupt JSON and future schema show recoverable error without overwriting file',async()=>{
 const good=await fs.readFile(file,'utf8');for(const bad of ['{ invalid json','[]','null','{}',JSON.stringify({configuration:{schemaVersion:99,computers:[]}})]){
 await close();await fs.writeFile(file,bad);await launch();await page.getByRole('heading',{name:'Настройки не удалось открыть',exact:true}).waitFor();assert.equal(await page.getByRole('article').count(),0);assert.equal(await fs.readFile(file,'utf8'),bad);const result=await page.evaluate(draft=>window.nexus.createComputer(draft),draft);assert.equal(result.ok,false);assert.equal(result.error.code,'STORAGE_ERROR');assert.equal(await fs.readFile(file,'utf8'),bad);await page.getByRole('combobox',{name:'Источник данных'}).selectOption('demo-computers');await page.getByRole('article',{name:'MAIN PC',exact:true}).waitFor();assert.equal(await fs.readFile(file,'utf8'),bad);await page.getByRole('combobox',{name:'Источник данных'}).selectOption('user');await fs.writeFile(file,good);await page.getByRole('button',{name:'Повторить загрузку',exact:true}).click();await page.getByRole('article',{name:'PC HOME EDITED',exact:true}).waitFor();}
 });
 await test('Deleting last computer restores persistent first-run empty state',async()=>{
 await page.getByRole('button',{name:'Открыть PC HOME EDITED',exact:true}).click({position:{x:120,y:40}});await page.getByRole('button',{name:'Удалить',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Удалить компьютер',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden'});await close();await launch();await page.getByRole('heading',{name:'У вас пока нет компьютеров.'}).waitFor();assert.deepEqual(JSON.parse(await fs.readFile(file,'utf8')).configuration.computers,[]);
 });
 await test('Desktop layouts and keyboard dialog dismissal remain usable',async()=>{
 for(const size of [{width:1280,height:720},{width:760,height:600}]){await app.evaluate(({BrowserWindow},size)=>BrowserWindow.getAllWindows()[0].setContentSize(size.width,size.height),size);await page.getByRole('button',{name:'Добавить компьютер',exact:true}).click();const dialog=page.getByRole('dialog');await dialog.waitFor();const sizes=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth-window.innerWidth,body:document.querySelector('.dialog-body').scrollWidth-document.querySelector('.dialog-body').clientWidth,footer:document.querySelector('.dialog-footer').getBoundingClientRect().bottom,screen:window.innerHeight}));assert.ok(sizes.overflow<=1&&sizes.body<=1&&sizes.footer<=sizes.screen,JSON.stringify(sizes));await page.keyboard.press('Escape');await dialog.waitFor({state:'hidden'});}
 });
 assert.deepEqual(errors,[]);await close();await fs.writeFile(path.join(output,'report.json'),JSON.stringify({checks,rendererErrors:errors,profile,file},null,2));console.log('ALL '+checks.length+' GROUPS PASSED');
}
run().catch(async error=>{console.error(error);if(page)await screenshot('failure').catch(()=>{});if(app)await close().catch(()=>{});process.exitCode=1;});
