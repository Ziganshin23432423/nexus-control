import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getEventListeners } from 'node:events';
import { createTcpProbe } from '../src/main/services/tcpProbe.js';
import type { ProbeSocket } from '../src/main/services/tcpProbe.js';
import { CONNECTION_TIMEOUT_MS } from '../src/shared/networkConstants.js';
class FakeSocket implements ProbeSocket {
  readonly connected = new Set<() => void>(); readonly errors = new Set<(error: unknown) => void>(); readonly closed = new Set<() => void>();
  destroyed = 0; calls: { address: string; port: number }[] = []; deferClose = false;
  action: (() => void) | null = null;
  onConnect(callback: () => void): () => void { this.connected.add(callback); return () => { this.connected.delete(callback); }; }
  onError(callback: (error: unknown) => void): () => void { this.errors.add(callback); return () => { this.errors.delete(callback); }; }
  onClose(callback: () => void): () => void { this.closed.add(callback); return () => { this.closed.delete(callback); }; }
  connect(address: string, port: 3389 | 22): void { this.calls.push({ address, port }); this.action?.(); }
  destroy(): void { this.destroyed++; if (!this.deferClose) this.close(); }
  close(): void { [...this.closed].forEach((fn) => fn()); }
  success(): void { [...this.connected].forEach((fn) => fn()); }
  error(error: unknown): void { [...this.errors].forEach((fn) => fn(error)); }
  get listenerCount(): number { return this.connected.size + this.errors.size + this.closed.size; }
}
function fixture() {
  const socket = new FakeSocket(); let timeout: (() => void) | null = null; let cancellations = 0; let now = 10;
  const probe = createTcpProbe({ socketFactory: () => socket, schedule: (callback, ms) => { assert.equal(ms, CONNECTION_TIMEOUT_MS); timeout = callback; return () => { cancellations++; }; }, now: () => now });
  const signal = new AbortController();
  return { socket, probe, signal, expire: () => { assert.ok(timeout); timeout(); }, advance: () => { now = 33; }, cancellations: () => cancellations };
}
function clean(f: ReturnType<typeof fixture>): void { assert.equal(f.socket.destroyed, 1); assert.equal(f.socket.listenerCount, 0); assert.equal(getEventListeners(f.signal.signal, 'abort').length, 0); assert.ok(f.cancellations() >= 1); }
test('TCP success uses fixed service port, measures latency and cleans socket/listeners/timer', async () => {
  const f = fixture(); const pending = f.probe('localhost', 'rdp', f.signal.signal); f.advance(); f.socket.success();
  assert.deepEqual(await pending, { status: 'ready', latencyMs: 23, errorCode: null }); assert.deepEqual(f.socket.calls, [{ address: 'localhost', port: 3389 }]); clean(f);
});
test('TCP refused, unreachable, DNS and generic socket errors are normal unavailable statuses', async () => {
  for (const code of ['ECONNREFUSED', 'EHOSTUNREACH', 'ENOTFOUND', 'EAI_AGAIN', 'ECONNRESET', 'CUSTOM_PRIVATE_ERROR']) {
    const f = fixture(); const pending = f.probe('localhost', 'ssh', f.signal.signal); f.socket.error({ code, message: 'must not leak raw message' });
    assert.deepEqual(await pending, { status: 'unavailable', latencyMs: null, errorCode: code === 'CUSTOM_PRIVATE_ERROR' ? 'SOCKET_ERROR' : code }); assert.equal(f.socket.calls[0]?.port, 22); clean(f);
  }
});
test('TCP wall deadline destroys unresolved connection, including DNS', async () => {
  const f = fixture(); const pending = f.probe('localhost', 'rdp', f.signal.signal); f.expire(); assert.equal((await pending).errorCode, 'ETIMEDOUT'); clean(f);
});
test('Abort closes an active socket and pre-aborted signals create no socket', async () => {
  const f = fixture(); const pending = f.probe('localhost', 'ssh', f.signal.signal); f.signal.abort(); assert.equal((await pending).errorCode, 'CANCELLED'); clean(f);
  const before = f.socket.calls.length; assert.equal((await f.probe('localhost', 'ssh', f.signal.signal)).errorCode, 'CANCELLED'); assert.equal(f.socket.calls.length, before); assert.equal(f.socket.destroyed, 1);
});
test('Queued error during destroy cannot change a success; listener remains until close', async () => {
  const f = fixture(); f.socket.deferClose = true; const pending = f.probe('localhost', 'rdp', f.signal.signal); f.socket.success();
  assert.equal(f.socket.errors.size, 1); f.socket.error({ code: 'ECONNRESET' }); f.expire(); assert.equal(f.socket.destroyed, 1); f.socket.close(); assert.equal((await pending).status, 'ready'); clean(f);
});
test('Early close and synchronous connect error settle normally and clean up', async () => {
  const f = fixture(); const pending = f.probe('localhost', 'ssh', f.signal.signal); f.socket.close(); assert.equal((await pending).errorCode, 'SOCKET_CLOSED'); assert.equal(f.socket.listenerCount, 0); assert.equal(getEventListeners(f.signal.signal,'abort').length,0);
  const g = fixture(); g.socket.action = () => { throw new Error('connect failed'); }; assert.equal((await g.probe('localhost','ssh',g.signal.signal)).errorCode,'SOCKET_ERROR'); clean(g);
});
