# NEXUS CONTROL — правила разработки

- Основной язык интерфейса и пользовательской документации — русский.
- Windows first, cross-platform architecture, Linux later. Windows 10 / Windows 11 — платформа №1; текущий MVP реально поддерживает только Windows. Проект не Windows-only.
- Не реализовывать и не тестировать Linux-функциональность до отдельного запроса пользователя.
- Windows-specific действия держать в отдельных модулях `main/providers/windows` и `main/platform/windows`, создаваемых в соответствующих этапах.
- Системные действия общая бизнес-логика получает через `RemoteDesktopProvider`, `SshProvider`, `WakeOnLanProvider` и `PlatformService` из `main/providers/contracts.ts`.
- Renderer и общая бизнес-логика не выбирают исполняемые файлы, shell, terminal, native credentials или провайдер по `process.platform`. Выбор провайдера выполняется в composition root / platform service.
- Computer model, UI, статусы, TCP checks, validation, orchestration, storage и генерация Magic Packet остаются общими. Node.js сеть и storage при этом доступны только main process.
- `Computer.operatingSystem` — ОС удалённого компьютера (`windows` / `linux`); `PlatformService.hostPlatform` — ОС самого приложения. Не смешивать эти значения.
- В MVP при создании компьютера использовать `operatingSystem: 'windows'`. Значение `linux` зарезервировано для будущей реализации и само по себе не включает поддержку.
- Наличие контракта, enum или работа окна в development на другой ОС не означает доступность системных функций. Пока нет реализации, provider slot равен `null`.
- Использовать Electron, React, TypeScript, Vite и строгую типизацию. Не добавлять `any` без обоснования.
- Сохранять разделение `main` / `preload` / `renderer` / `shared`.
- Renderer не получает Node.js API, доступ к файлам, сети ОС или запуску процессов.
- `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`; не отключать защиту в коде приложения.
- IPC разрешает только явно перечисленные методы. Проверять отправителя и входные данные в main.
- Запрещены универсальные `executeCommand`, `runShell`, произвольный shell execution и `shell: true`.
- Для будущего запуска системных клиентов использовать `spawn` / `execFile` с массивом проверенных аргументов.
- Никогда не сохранять пароли Windows/SSH в JSON, electron-store, localStorage, `.env`, исходниках или логах.
- Не реализовывать собственные RDP, SSH или VPN; приложение оркестрирует существующие системные клиенты.
- Не расширять scope без запроса пользователя. Делать только текущий согласованный этап.
- Automations / Scripts — только будущее направление в ROADMAP и архитектурных заметках. На этапе 3 не добавлять scripts, arbitrary command execution, script IPC, PowerShell execution, scheduler или remote execution; не проектировать Automation Engine подробно и не создавать искусственных ограничений на его последующее добавление.
- После существенных изменений запускать `npm run typecheck`.
- После каждого этапа запускать `npm run build` и исправлять ошибки до перехода дальше.
- Не переписывать рабочую архитектуру без необходимости.
- Не менять системные настройки Windows, firewall, службы, реестр, BIOS или сетевые адаптеры молча.
- Не удалять файлы пользователя вне проекта.
- Не добавлять сканирование сети, подбор учётных данных, скрытый агент или произвольные удалённые команды.
- На этапе 1 запрещено добавлять RDP, SSH, Wake-on-LAN, карточки компьютеров, demo mode или хранение конфигурации.
- Исторический этап 3: persistent CRUD через electron-store в main, shared validation с повторной проверкой в main, versioned storage и migrations entry point, typed IPC и unit tests критической логики. Дизайн этапа 2 сохранять.
- Networking и системные действия на этапе 2 всегда mock. Запрещено добавлять electron-store, TCP checks, запуск RDP/SSH/Terminal, UDP WoL, credential storage, Linux providers или remoteAddress routing.
- Demo использует общую `Computer` model; конфигурация и вычисляемые статусы хранятся отдельно. Не создавать вторую модель компьютера для UI.
- DEMO DATA и USER DATA разделены: демо только в памяти, пользовательские записи в main storage. По умолчанию открывать пользовательские данные; демо-фикстуры никогда не записывать в пользовательский файл.
- Повреждённую/неизвестную будущую конфигурацию не сбрасывать и не перезаписывать. Ошибки хранения показывать пользователю; ID и timestamps назначает main.
- Исторический этап 4: TCP checks только настроенных RDP (3389) / SSH (22) в main, timeout 2000 ms, local → remote fallback, runtime state, typed ID-only IPC, concurrency 8, stale result protection и tests. Без polling, запуска клиентов, UDP/WoL, PowerShell, Linux providers и Automations.
- После этапа 4: typecheck → tests → build → Electron UI/network QA → docs/STAGE4.md; остановиться. Этап 5 разрешён отдельным запросом пользователя.
- По завершении этапа сообщить, что сделано, результаты проверок и простой способ запуска.

- Исторический этап 5: только Microsoft RDP launch на Windows через WindowsRdpProvider, ID-only typed IPC, fresh TCP 3389 local → remote check с общим NetworkService/pool, shell:false, системный mstsc, duplicate protection. Успех означает открытый клиент, а не авторизацию.
- Demo никогда не вызывает настоящие network/provider/launch capabilities. Во время этапа 5 SSH/Terminal, WoL/UDP, PowerShell, Credentials, Linux providers и Automations оставались вне scope.
- После этапа 5: typecheck → tests → build → Electron RDP QA → Stage3/4 regression → docs/STAGE5.md; остановиться. Настоящий Windows mstsc smoke test не подменять Linux mocks.

- Исторический этап 6: только интерактивный SSH через WindowsSshProvider, ID-only openSshTerminal, fresh TCP22 local → remote через общий NetworkService/pool, системный OpenSSH + Windows Terminal alias, fallback Console Host без shell/PowerShell/cmd. Host key verification и authentication остаются в OpenSSH.
- Не добавлять remote command/script API, команды после SSH destination, управление ключами или passwords. RDP сохранять; один active RDP/SSH launch на computerId. На этапе 6 WoL/UDP оставался вне scope; Automations и Linux providers не реализовывать.
- После этапа 6: typecheck → tests → build → Electron SSH QA → Stage3/4/5 regression → docs/STAGE6.md; остановиться. Настоящий Windows Terminal/OpenSSH smoke test не подменять Linux mocks.

- Исторический этап 7: стандартный Magic Packet в shared, main-only UdpWakeOnLanProvider (UDP4, ephemeral bind, broadcast, ровно три пакета, интервал 100 ms, deadline 2500 ms, гарантированный close). Подключать WoL только на Windows host.
- wakeComputer принимает только UUID сохранённого USER DATA компьютера. Повторно validate в main. Не принимать произвольные MAC/address/port/payload через IPC. Отдельный duplicate guard WoL, без TCP prerequisite.
- Успех означает только «Magic Packet отправлен»: не менять online status, не сохранять runtime state и не запускать polling/wait/connect. DEMO полностью mock.
- После этапа 7: typecheck → tests → build → Electron WoL QA → Stage6/5/4/3 regressions → docs/STAGE7.md; остановиться. Windows/NIC/BIOS smoke не подменять loopback/mocks. Stage8, Guide/redesign/motion и Automations не начинать.

- Исторический этап — 8: ровно два fixed USER DATA flow (WoL → wait RDP → Stage5 launch; WoL → wait SSH → Stage6 launch). Переиспользовать services/providers, без универсального workflow engine.
- Только ID-only wakeAndOpenRemoteDesktop / wakeAndOpenSshTerminal / cancelWakeAndConnect. Progress subscription разрешает только typed события fixed flow, без raw IPC. MAC/host/username/port/timeout/interval не приходят из renderer.
- После одного Stage7 burst sequential selected-service checks + cancellable delay 2000 ms, wall deadline 90000 ms включает checks/pauses и финальную fresh check. Без setInterval/overlap/background monitoring.
- Shared launch slot и main-only ownership защищают ID от direct RDP/SSH conflicts; WoL claims отдельные. Разные IDs независимы; edit/delete отменяют выбранный ID, shutdown — все. Внутренние owned methods не ослабляют public IPC.
- Success — client-opened/terminal-opened, не authentication/booted. DEMO только mock, runtime/timers не persist.
- После Stage8: typecheck → tests → build → orchestration Electron QA → Stage7/6/5/4/3 regressions → docs/STAGE8.md; остановиться. Не начинать Stage9, Guide/redesign/motion/Automations/Linux providers.

- Текущий завершённый этап — 9: только Operational UX Hardening поверх Stage1–8. Сохранены Stage2 visual system и прежние security/network/storage boundaries.
- Error presentation — renderer whitelist по typed code, только safe metadata; explicit retry конкретного действия, без auto-retry. Не хранить runtime states.
- Main публикует informational remainingSeconds раз в секунду; renderer не управляет 90-second deadline. Countdown timers очищать при запуске/завершении/отмене.
- После Stage9 проверять typecheck → tests → build → Electron UX QA → Stage8/7/6/5/4/3 regression. Stage10 NEXUS Guide, Stage11 redesign/motion и installer не начинать без отдельного запроса.

- Текущий завершённый этап — 10: NEXUS GUIDE renderer-only. 59 bundled typed articles, local search/checklist/context/error navigation; без Guide IPC, fetch, execution, secrets или автоматического изменения Windows.
- Guide references проверять unit-тестами. Сохранять draft/focus при помощи поверх формы и offline доступность независимо от DEMO/USER.
- После Stage10 полный цикл: typecheck → tests → build → Guide QA → Stage9/8/7/6/5/4/3 regressions. Остановиться; Stage11 typography/redesign/motion не начинать без отдельного запроса.

- Текущий завершённый этап — 11: renderer-only design/typography/motion/appearance. Сохранены Stage1–10 model/store/migrations/validation/IPC/services/providers и Guide data/search/security.
- Appearance содержит ровно effects full/calm/minimal и density normal/compact; отдельный renderer-only key nexus.appearance.v1, strict validation, default full/normal, reset только этого key. Не добавлять privileged appearance IPC или secrets.
- Background — Canvas 2D, bounded stars/DPR, один owned RAF, plain pointer state, pause hidden, cleanup listeners/RAF/ResizeObserver. Respect prefers-reduced-motion; Minimal без непрерывного RAF.
- Typography: Segoe UI Variable Text → Segoe UI → system-ui/sans-serif. Дополнительная font dependency не нужна.
- После существенного visual change проверять screenshots и все effects/density combinations. Финальный цикл Stage11: typecheck → tests → build → appearance QA → Guide → UX → orchestration → WoL → SSH → RDP → network → CRUD. Stage12/installer не начинать без отдельного запроса.

- Текущий этап — 12: Windows stabilization/RC поверх принятого Stage11C. Не redesign, installer/updater или новые remote capabilities. Windows readiness — отдельная безопасная диагностика без новых IPC; native Windows/hardware checks не подменять Linux/DI.
- После Stage12 typecheck → tests → build → readiness → appearance → Guide → UX → orchestration → WoL → SSH → RDP → network → CRUD. Чистый исходный ZIP без generated files/profiles/dependencies. Stage13 только после отдельного разрешения.

- Текущий этап — 13: electron-builder / NSIS per-user Windows x64, identity/icons/release docs. Stage14 не начинать. Сохранять userData NEXUS CONTROL; uninstall без удаления данных. Native Windows smoke не подменять cross-build.
