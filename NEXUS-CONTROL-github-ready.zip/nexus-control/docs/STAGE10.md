# Stage 10 — NEXUS GUIDE

Дата завершения: 2 октября 2026, Asia/Yekaterinburg.

## Результат

**Stage10 завершён.** В production Electron проверены все обязательные проверки, в указанном порядке. Stage11 не начат.

Guide — локальный информационный раздел NEXUS CONTROL: **59 статей, 6 разделов, Quick Start из 8 шагов**. Он использует прежнюю Stage2 visual system, не меняет глобальную типографику и не добавляет Motion System. Статьи, поиск, помощь и чек-лист bundled с renderer, без сервера/AI/API и регистрации.

| Раздел | Статей |
| --- | ---: |
| Быстрый старт | 6 |
| Подключение | 11 |
| Wake-on-LAN | 10 |
| Диагностика | 11 |
| Безопасность | 7 |
| Термины | 14 |
| Всего | **59** |

Quick Start собирает hostname, локальный IPv4, MAC Ethernet, маску/broadcast, SSH username и необязательный remote/VPN IP. Шаги RDP/SSH/WoL ведут к ручным инструкциям. Карточка данных статическая; паролей/секретов в ней нет. Отметки чек-листа — RAM текущей открытой статьи, не автоматическая верификация; уход из статьи сбрасывает отметки. «5 минут» — ориентир, а не гарантия времени установки компонентов или настройки BIOS.

Поиск deterministic local: title/description/keywords/content, NFKC, русский lower case, ё/е, нормализация разделителей, AND tokens, стабильное ранжирование. Проверены RDP, MAC, «мак адрес», «не включается», SSH, 3389, 22, IP, пароль, BIOS, пустой запрос и отсутствие результатов.

## Contextual integrations

| Место | Интеграция |
| --- | --- |
| Карточка компьютера | RDP/SSH → настройка или «не отвечает» по статусу; WoL → setup |
| Страница компьютера | Те же service help buttons |
| Add / Edit form | Hostname, Local IP / hostname, Remote / VPN IP, MAC, username, broadcast, port |
| Помощь из формы | Read-only Guide dialog поверх формы, без потери draft; Escape восстанавливает фокус |
| Error toast | «Открыть инструкцию» для 13 предусмотренных typed error codes |
| Guide | Back, breadcrumb, category/sidebar, related article IDs |

Error mappings: RDP_UNAVAILABLE, SSH_UNAVAILABLE, WOL_SEND_ERROR, WOL_TIMEOUT, WAKE_CONNECT_TIMEOUT, SSH_CLIENT_MISSING, SSH_HOST_MISSING, RDP_DISABLED, SSH_DISABLED, WOL_DISABLED, RDP_LAUNCH_ERROR, SSH_LAUNCH_ERROR, NETWORK_ERROR. Все IDs проверены against каталог; остальные ошибки не получают выдуманный маршрут. Main error semantics и retry policy неизменны.

## Полный финальный цикл

| Порядок | Проверка | Результат |
| ---: | --- | --- |
| 1 | npm run typecheck | PASS: main/preload/shared, renderer, tests |
| 2 | npm test | **165 passed, 0 failed, 0 skipped** |
| 3 | npm run build | PASS: production main/preload/renderer |
| 4 | Stage10 Guide Electron QA | **14 групп PASS** |
| 5 | Stage9 UX regression | **22 групп PASS** |
| 6 | Stage8 orchestration regression | **13 групп PASS** |
| 7 | Stage7 WoL regression | **11 групп PASS** |
| 8 | Stage6 SSH regression | **10 групп PASS** |
| 9 | Stage5 RDP regression | **10 групп PASS** |
| 10 | Stage4 network regression | **12 групп PASS** |
| 11 | Stage3 CRUD/persistence regression | **13 групп PASS** |
| | Всего Electron QA | **105 групп PASS** |

Результаты: [typecheck](./stage10/typecheck.log), [unit tests](./stage10/tests.log), [build](./stage10/build.log), [Guide](./stage10/guide-checks.json), [UX](./stage10/ux-checks.json), [orchestration](./stage10/orchestration-checks.json), [WoL](./stage10/wol-checks.json), [SSH](./stage10/ssh-checks.json), [RDP](./stage10/rdp-checks.json), [network](./stage10/network-checks.json), [CRUD](./stage10/crud-checks.json).

Это число выполненных групп, включая повторяемую регрессию, а не 105 независимых новых сценариев. Guide добавил 20 unit-тестов к 145 прежним тестам. Проверены уникальность/полнота IDs, ссылки разделов/статей/шагов/источников, error/field mappings, поиск/normalization, static command allowlist, отсутствие privileged/execution/secret access, неизвестные IDs.

## Electron Guide QA

Production Electron действительно открыт через isolated QA profile и виртуальный дисплей. Проверены:

1. Guide доступен с пустым USER DATA, корректный фокус поиска.
2. Quick Start: восемь шагов, шесть data items, ручные отметки, отсутствие password fields.
3. Копирование фиксированной команды через renderer clipboard; безопасный fallback при отказе разрешения.
4. RDP/MAC/«не включается» search и Enter для открытия статьи.
5. No-result/empty, clear, Escape и Tab.
6. Back/breadcrumb/aria-current и открытие **всех 59 статей**.
7. 760×600, collapsed navigation, keyboard category, без горизонтального overflow.
8. Контекст RDP/SSH/WoL в DEMO и RDP unavailable на detail.
9. Помощь поверх формы: unsaved name/address сохранены, Escape возвращает фокус.
10. Подготовка настоящей persistent USER DATA записи через существующий CRUD.
11. WOL_SEND_ERROR → «Открыть инструкцию» → «WoL не работает».
12. USER RDP/SSH/WoL contextual links и поиск при отключённой renderer-сети.
13. Production reload offline → Guide, Quick Start и поиск 3389 работают.
14. Изоляция renderer, точный прежний bridge, console/renderer errors и cleanup.

Snapshots test-only main harness до/после Guide показывают **ноль дополнительных probes, UDP packets, client launches и operational IPC**. Для status handler тоже установлена test-only instrumentation. Файл `computers.json` до/после Guide побайтно одинаков. Внешних HTTP(S) requests от Guide нет. Непредвиденных rendererErrors/consoleErrors нет во всех финальных отчётах. После проверок activeSockets/activeProbes/timers/slots/claims равны нулю.

Guide не останавливает или не перезапускает ранее начатую пользователем системную операцию. Hooks остаются mounted; открытие раздела само не вызывает проверки. Existing initial checks при загрузке USER DATA или reload принадлежат Stage4 и учитываются до baseline измерения.

## Security boundary и архитектура

[Сверка с принятым Stage9](./stage10/security-audit.json): **48 protected files byte-identical** — main, preload, shared model/validation/constants, provider/security modules, package.json/lock, electron-vite config, ROADMAP. Baseline SHA256: `0bc6e868575164a3d2cbf591b76ebc30384284c31d781fc762e411393e65f69f`.

Новых IPC методов нет: прежние 15 explicit methods. nodeIntegration=false, contextIsolation=true, sandbox=true, webSecurity=true, CSP/local protocol, window/frame/URL sender checks и navigation restrictions сохранены. Network/RDP/SSH/WoL services/providers, Windows-first composition и schemaVersion=1 не менялись. Linux providers, PowerShell/shell/arbitrary execution, scheduler и Automations не добавлены.

Guide — typed renderer modules: ids/types/catalog/sections/content, local search, static commands, GuidePage/Article/Checklist, contextual navigation/dialog и error/field maps. Не использует Node, electron-store, window.nexus, fetch, eval, arbitrary HTML или URL opener. Команды hostname/ipconfig/ipconfig /all/whoami — frozen static texts; только показ/renderer clipboard. Никаких execution buttons. Дополнительные HTTPS источники показаны plain text, внешнего handler нет.

В renderer прежние concrete-action hooks теперь проверяют live enabled ref при retry; source switch очищает toast. Это сохраняет обещанную demo isolation, включая старый callback USER DATA. Старые Electron scripts получили уточнение selectors: textbox вместо broad getByLabel там, где рядом с полем появилась отдельная labelled help button. Assertions, сценарии и safety checks не удалялись.

## Восстановление после прерывания

Рабочая среда вернулась к Stage2; потеряны transient изменения Stage3–10. Принятый Stage9 восстановлен из сохранённого архива после сверки SHA256. Незавершённого Stage10 checkpoint не было: восстановлены утраченные renderer Guide, context integrations и тесты по согласованным требованиям. Stage1–9 services/architecture восстановлены без переработки. Результаты предыдущей оборванной проверки не использованы как доказательство: весь указанный финальный цикл выполнен заново.

В процессе исправлены две type mismatch WoL help, тестовая query с отличающимся русским падежом и ambiguous form selectors. После исправлений полный финальный sequence завершён без ошибок.

## Точность инструкций и ограничения

Статьи RDP/OpenSSH и диагностические команды сверены с официальной документацией Microsoft; WoL — с Microsoft и Dell. Десять дополнительных ссылок и дата проверки находятся в `guide/sources.ts`, доступны текстом в соответствующих статьях. Не перенесены registry hacks или model-specific BIOS настройки как универсальные требования.

Отмечены: Windows Home не принимает стандартный RDP; SSH Client и Server устанавливаются на разные роли ПК; NLA/host-key verification не отключаются; PIN не приравнен к паролю; broadcast вычисляется по маске; WoL зависит от оборудования/питания/состояния, а отправка не подтверждает пробуждение. Прямой WoL через интернет не обещается. Настройки BIOS/NIC/RDP/firewall/sshd меняет только пользователь вручную.

Среда QA — Linux Electron, это не Linux functionality. Native Windows launch/UDP/probes combined flows проверены explicit test-only DI с mock resources и virtual clock. Stage7/4 regressions дополнительно используют настоящие собственные loopback UDP/TCP. Контейнер ограничивает TCP22 bind; успешный SSH probe проверяется через injection. **Физический Windows PC, login и BIOS/NIC wake здесь не проверялись.** Root QA использует `--no-sandbox` только launch flag; production настройки не ослаблены. Windows installer пока не собран.

Перед распространением выполните Windows smoke: открыть Guide без интернета; search/context/copy/keyboard в реальном sandbox; проверить ручные инструкции на целевой модели Windows 10/11. Native clients/physical wake smoke сохраняются из Stage5–9.

## Screenshots

- [Guide home · 1280×720](./stage10/guide-home.png)
- [Quick Start](./stage10/quick-start.png)
- [Search RDP](./stage10/search-rdp.png)
- [Search MAC](./stage10/search-mac.png)
- [Search WoL](./stage10/search-wol.png)
- [Guide article · 760×600](./stage10/guide-small.png)
- [Error → instruction](./stage10/error-guide.png)

## Как проверить на Windows

В папке проекта: `npm.cmd ci` → `npm.cmd run dev`. Production: `npm.cmd run typecheck` → `npm.cmd test` → `npm.cmd run build` → `npm.cmd start`.

Откройте NEXUS GUIDE, Quick Start и поиск. Проверьте помощь в карточке/форме; Escape из инструкции возвращает прежний draft. Отключите интернет — статьи и поиск продолжат работать. Guide не отправляет WoL и не запускает клиенты. В USER DATA настоящие системные действия остаются отдельными кнопками Stage5–8.

TODO Stage11: **Guide opening animation / article transitions / search animation will be polished with the global NEXUS Motion System.** Новой global typography/motion системы на Stage10 нет. **Остановлено после Stage10.**


## Повторная финальная верификация после восстановления

Полный цикл повторно завершён 1 октября 2026 (UTC): typecheck → 165/165 unit tests → production build → Guide 14 → UX 22 → orchestration 13 → WoL 11 → SSH 10 → RDP 10 → network 12 → CRUD/persistence 13. Всего 105/105 групп Electron QA. Приложение действительно запускалось в Electron; свежие screenshots, JSON reports и console logs находятся в `docs/stage10`. Guide/UX и остальные instrumented отчёты не содержат неожиданных renderer/console errors; CRUD renderer errors пусты.

В первом повторном цикле CRUD остановился после проверки намеренно повреждённого test profile: следующая форма получила STORAGE_ERROR. В test setup добавлены две проверки восстановления fixture — побайтная сверка файла и успешное чтение через существующий listComputers в main — до следующего сценария. Затем изолированный CRUD и весь обязательный финальный цикл прошли успешно. Assertions не удалены; production code не менялся.

За основу взят сохранённый Stage10 ZIP с SHA256 `7fd754b2e7ecb22e7fb5cb39f65ead43b52785cc4774a9bbbe9b5c44bc0c3c38`. Main/preload/shared/package files побайтно совпадают с этим checkpoint. Более поздние изменения оформления сохранены отдельно и не включены в Stage10. Сохранены 59 статей, Quick Start из восьми шагов, прежние contextual integrations и security boundaries. Stage11 не начинался в рамках этой задачи.
