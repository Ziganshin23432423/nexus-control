# Этап 8 — Wake → Wait → Connect

NEXUS CONTROL by **network.onion**. Реализованы два fixed USER DATA сценария: WoL → ждать RDP → открыть RDP и WoL → ждать SSH → открыть терминал. Stage 9 не начат.

## Изменённые архитектурные части

| Часть | Изменение |
| --- | --- |
| Main orchestration | `WakeAndConnectService`: два явных flow, original snapshot, ownership и bounded sequential wait |
| Clock / delay | `workflowClock.ts`, shared `wakeAndConnectConstants.ts`: monotonic now, injected scheduler, cancellable delay |
| Ownership | Main-only `LaunchOwnership`: controller + validated Computer snapshot; используется прежняя shared launch map |
| Launch services | `RemoteDesktopService` / `SshTerminalService`: внутренний `openOwned`, все прежние validation/fresh checks сохранены |
| WoL service | `wakeOwned` с parent controller; отдельные workflow claims блокируют повторный direct wake; transport не продублирован |
| Main / CRUD | Composition и typed mutation ID; edit/delete отменяют выбранную операцию, shutdown — все |
| IPC/preload | Три explicit start/cancel метода и read-only typed progress subscription |
| Renderer | `useWakeAndConnect`, progress на карточке/странице, две combined кнопки, Отменить; DEMO маршрутизируется первым |
| Tests/docs | 34 новых unit test, отдельный orchestration Electron harness, текущая архитектура и README |

Computer model, storage schemaVersion **1**, migrations, dependencies, Stage4 probing/fallback/pool, Stage5/6 Windows providers и Stage7 Magic Packet/UDP transport не переписаны. ROADMAP не изменён. Визуальная система Stage2 сохранена; новые кнопки используют её существующие SVG/button/progress компоненты и полный ряд, без сжатия текста.

## Два flow

1. Проверить UUID → ComputerStore.get → повторная shared validation сохранённой записи → Windows target/config и наличие host WoL + соответствующего client provider.
2. Для RDP требуется rdpEnabled; для SSH — sshEnabled и valid username. MAC/WoL/broadcast/port проверяются существующей validation и повторно WoL service/provider. Невалидный файл не перезаписывается.
3. Синхронно занять shared launch slot выбранного ID до первого await; добавить WoL workflow claim.
4. Вызвать существующий `WakeOnLanService.wakeOwned` **один раз**. Он отправляет Stage7 fixed burst: три стандартных пакета, тот же UDP4 lifecycle/deadline. Ошибка WoL прекращает flow без TCP checks.
5. После send ACK начать **90-second wall deadline**. Это не подтверждение физического включения.
6. Последовательно вызывать только `CheckCoordinator.checkRdp` либо `checkSsh`. Existing NetworkService выбирает local → отличный remote fallback. Общий pool сохраняется, full refresh не вызывается.
7. При unavailable — cancellable delay **2000 ms**, затем следующая проверка. Async checks не перекрываются; нет setInterval. Реальная частота учитывает длительность checks: пауза идёт после завершения попытки, а не строго каждые 2 секунды от предыдущего старта.
8. При READY → существующий launch service через main-only `openOwned`. **Stage5/6 заново читает и валидирует запись, сравнивает original snapshot и выполняет ещё одну fresh TCP check.** WAIT endpoint не передаётся напрямую provider.
9. Если порт исчез перед финальным запуском — controlled RDP_UNAVAILABLE / SSH_UNAVAILABLE; сценарий завершается, пользователь может повторить его. Скрытого продолжения ожидания или второго burst нет.
10. Success — прежний client-opened / terminal-opened ACK + wakeSent true и waitedMs. Авторизацию выполняет стандартный client.

Deadline включает время service attempts, ожидание pool, паузы и финальный fresh check/discovery до запуска. Он начинает отсчёт **после WoL ACK**; UDP отправка имеет собственный Stage7 timeout. Используется отдельный deadline timer + monotonic elapsed проверки, а не суммирование 45 пауз. На deadline текущий controller aborts; TCP sockets освобождаются существующим probe lifecycle. Timers/claims/slots очищаются finally.

## Coordination и cancellation

Flow резервирует тот же `Map<computerId, AbortController>`, который Stage5/6 уже использовали для direct RDP/SSH. Новый flow для занятого ID получает WAKE_CONNECT_BUSY. Direct RDP/SSH получают свой BUSY и не создают duplicate client. `openOwned` допускает только controller, уже находящийся в map; проверяет original config. Launch service не освобождает чужой slot — его owner завершает cleanup. Разные IDs могут работать независимо.

Set workflowClaims в main блокирует direct WoL для этого ID во время flow (WOL_BUSY), сохраняя прежнюю отдельную короткую direct WoL операцию вне flow. Уже выполняющийся direct wake не создаёт второй burst: существующий Stage7 guard возвращает BUSY, flow освобождает свою reservation.

`cancelWakeAndConnect(id)` проверяет только UUID, aborts active controller и возвращает `{computerId,cancelled}`. Неactive ID — безопасный no-op. UI остаётся busy до окончания cleanup и ответа исходного start. Cancel прерывает pending UDP, текущий TCP probe/очередь и delay; дальнейшие checks/native launch исключены. Отправленный пакет физически отменить нельзя. Уже успешно opened client не закрывается: session kill API отсутствует.

CRUD update/delete callback передаёт validated выбранный ID и отменяет его pending launch/wake/flow. Другие IDs не отменяются. Create отменяет только устаревший UI status refresh. Shutdown/закрытие окна aborts все active operations. Snapshot comparison до/после checks и внутри final service дополнительно защищает от external file edits/deletes. Таймеры или runtime не сохраняются.

## Typed IPC и progress

Renderer передаёт только ID:

- `wakeAndOpenRemoteDesktop(id)`;
- `wakeAndOpenSshTerminal(id)`;
- `cancelWakeAndConnect(id)`.

Все три handlers используют trusted main window/frame/exact URL guard и отвергают дополнительные arguments. UUID/record/config проверяются в main. Нет host/MAC/address/port/username/timeout/interval/executable/command/protocol/action payload.

`onWakeAndConnectProgress(listener)` — узкая read-only подписка на один fixed main→renderer channel. Payload: computerId, service (`rdp`/`ssh`), phase (`sending`/`waiting`/`launching`). Callback не получает raw Electron event; unsubscribe удаляет listener. Отправка только в текущее главное окно с разрешённым URL. Приложение не предоставляет произвольный subscribe/IPC invoke.

Success types расширяют Stage5/6 результаты:

```ts
{ computerId, state: 'client-opened', wakeSent: true, waitedMs, rdp }
{ computerId, state: 'terminal-opened', wakeSent: true, waitedMs, ssh }
```

Нет state online/booted/connected/authenticated. Возможные ошибки остаются controlled typed IpcResult, включая WAKE_CONNECT_BUSY/TIMEOUT/UNSUPPORTED, предыдущие WoL/RDP/SSH/storage ошибки и CANCELLED. Unexpected exception не раскрывает raw данные/секреты.

## UI и DEMO

USER DATA показывает дополнительные кнопки при соответствующих saved capabilities: **Включить и подключиться**, **Включить и открыть терминал**. Direct Включить / Рабочий стол / Терминал сохранены. Во время flow — Отправка сигнала… → Ожидание RDP…/SSH… → Подключение…, кнопка **Отменить**, пояснение о 90 секундах и ограничении отправки. Собственные конфликтующие действия и source switch защищены pending UI; main guard остаётся независимым.

Success toast сообщает об открытом client/terminal и передаёт authentication стандартному приложению. Timeout/error/cancel очищает UI и позволяет повторить действие. CANCELLED имеет обычное информационное уведомление. Runtime online автоматически не устанавливается; текущие сетевые статусы остаются прежними до ручного refresh. Это допустимое отсутствие дополнительной синхронизации runtime UI, а не сохранение false online в файл.

DEMO поддерживает оба combined действия только in-memory timers. Demo ветка диспетчера выполняется до user callbacks; нет user workflow IPC, TCP, UDP, process launch или persistence. Прежнее mock ожидание/Отмена сохранено. Guide/typography/motion redesign не добавлены.

## Результаты проверок

Финальная последовательность:

**typecheck → unit tests → production build → Stage8 orchestration Electron QA → Stage7 WoL → Stage6 SSH → Stage5 RDP → Stage4 network → Stage3 CRUD/persistence**.

| Проверка | Результат |
| --- | --- |
| Typecheck main/preload/shared, renderer, tests | Passed |
| Unit tests | **127/127** (93 предыдущих + 34 Stage8), no fail/skip/cancel |
| Production build | Passed |
| Stage8 orchestration Electron | **13/13** групп |
| Stage7 WoL regression | **11/11** групп |
| Stage6 SSH regression | **10/10** групп |
| Stage5 RDP regression | **10/10** групп |
| Stage4 network regression | **12/12** групп |
| Stage3 CRUD/persistence regression | **13/13** групп |
| Итого Electron | **69/69** групп |

Stage8 unit tests проверяют оба flow: UUID/missing/corrupt/non-Windows/WoL/service/provider validation, SSH usernames; wake failure без checks; unavailable/repeated unavailable/eventual READY, only-selected-service/no overlap/2000 ms delay; local/remote fallback и дополнительную финальную fresh check; launch error и port disappearance; global 90000 ms включая attempts/delays/final probe; cancel в UDP/check/delay/final check, shutdown, external edit/delete; same-ID RDP/SSH/direct conflicts; independent IDs; retry после success/error/timeout/cancel; cleanup/no callbacks; owned token и stale snapshot; ID-only start/cancel/extra args/sender/frame/window/URL; DEMO routing. Время детерминированное: реального 90-секундного ожидания нет.

Stage8 Electron QA сначала проверяет настоящий production unsupported/security path на Linux, затем **explicit test-only DI** подменяет только narrow flow/direct handlers. Переиспользует production ComputerStore, NetworkService, CheckCoordinator, WoL service/UDP provider, launch services, Windows providers и orchestration. Injected UDP socket facade/check outcomes/native host spawn являются mock; workflow clock virtual. Production app не содержит QA flags/provider overrides/backdoor.

Проверены card/detail sending→wait→ready→final ACK для RDP/SSH, fallback и safe Windows args; duplicate/direct conflicts; cancel during delay/active probe; virtual timeout; retry; wake/launch errors; external edit и shutdown; DEMO isolation; 760×600, keyboard Enter и безопасный bridge. Card navigation проверяется нажатием верхней области карточки, отдельно от action buttons. **Cleanup: active sockets/probes/timers/slots/claims = 0** после сценариев. Renderer и console errors = 0.

Stage7 regression отдельно использует настоящий UDP4 исключительно в собственном loopback receiver: 5 sender sockets созданы и закрыты, active=0; четыре успешных burst получили 12 exact packets, одна injected send error. Stage4/5 real TCP3389 loopback probes отправляют 0 bytes payload и закрывают sockets; SSH success в контейнере использует DI. CRUD regression реально перезапускает Electron и проверяет сохранение/edit/delete/corrupt/future schemas.

Результаты: [orchestration](./stage8/orchestration-checks.json), [WoL](./stage8/wol-checks.json), [SSH](./stage8/ssh-checks.json), [RDP](./stage8/rdp-checks.json), [network](./stage8/network-checks.json), [CRUD](./stage8/crud-checks.json).

## Скриншоты

Скриншоты Stage8 explicit DI QA. 127.0.0.x — только test target, Windows Desktop header — существующая Windows-first стилизация, не доказательство Windows launch. Test entry может показывать v0.0; обычный entry использует package version.

![Главный экран](./stage8/main.png)

![Ожидание RDP](./stage8/waiting.png)

![Страница компьютера](./stage8/computer.png)

## Ограничения Linux environment

- Физический Windows ПК **не пробуждался и не загружался**. Authentication/session lifetime/BIOS/NIC не проверены.
- Windows mstsc/OpenSSH/Terminal/Console Host не запускались: launch mocked. Production Linux providers по-прежнему null; Linux-функциональность не реализована.
- Stage8 lifecycle/progress/timeouts проверяются injected mocks и virtual clock, не wall-clock 90 секунд. Stage7/4 regressions отдельно покрывают реальные собственные loopback UDP/TCP resources.
- TCP22 bind запрещён контейнером: SSH ready/fallback использует injected probes, настоящий unavailable путь проверен сетевой регрессией.
- Root Electron QA использует Xvfb и технический --no-sandbox. Production nodeIntegration:false, contextIsolation:true, sandbox:true и webSecurity:true сохранены; Windows OS sandbox smoke нужен отдельно.
- Внешние компьютеры/публичные destinations, Windows/BIOS/NIC/firewall/registry настройки не использовались и не менялись.

## Windows smoke checklist — позже

1. На Windows 10/11 распаковать проект, `npm.cmd ci`, `npm.cmd run typecheck`, `npm.cmd test`, `npm.cmd run build`, `npm.cmd start` обычным пользователем без QA flags. Проверить user persistence и прежние direct RDP/SSH/WoL.
2. На собственном target вручную по инструкции производителя подготовить WoL BIOS/NIC; при необходимости вручную настроить RDP/OpenSSH Server. Это изменения системных настроек пользователя, NEXUS их не выполняет. Сохранить правильный MAC, broadcast своей подсети/port9, local/remote адрес и SSH username.
3. При выключенном/спящем target нажать **Включить и подключиться**: один burst, отправка→ожидание RDP→final fresh check→mstsc с правильным адресом. После ACK выполнить authentication в Windows client.
4. Аналогично проверить **Включить и открыть терминал**: только SSH22 checks, Windows Terminal/OpenSSH safe username args, password/host-key prompts и пользовательские keys; при отсутствии alias проверить Console Host fallback.
5. Проверить local refusal→remote fallback, disappearance сервиса между WAIT READY и final fresh check, неготовый target→90-second controlled timeout без клиента, повторный сценарий после ошибки/timeout.
6. Cancel в отправке/check/delay и edit/delete выбранной записи должны исключать последующий launch; другие ID продолжают свои flows. Double click/direct RDP/SSH во время flow не создают duplicate clients.
7. После уже открытого client Cancel/выход NEXUS не закрывают сессию. Проверить shutdown во время ожидания, cleanup UDP/TCP/timers, отсутствие background polling после flow и runtime fields в computers.json.
8. Проверить DEMO combined RDP/SSH: только mock, без реального packet/probe/client и без user file changes; keyboard/small desktop UX.

Пакет может быть отправлен, но не принят аппаратурой. Internet relay/router API/VPN/Tailscale и BIOS/NIC automation отсутствуют; пробуждение через интернет напрямую не обещается.

## Воспроизведение QA

Unit/type/build — стандартные npm scripts. В подготовленном Linux QA окружении с Electron runtime, Xvfb и Playwright после test compilation/build последовательно запустить:

```sh
node tests/electron-orchestration.cjs
node tests/electron-wol.cjs
node tests/electron-ssh.cjs
node tests/electron-rdp.cjs
node tests/electron-network.cjs
node tests/electron-crud.cjs
```

QA tooling использует DISPLAY, NEXUS_PLAYWRIGHT_PATH, NEXUS_QA_OUTPUT; root-only test flag NEXUS_QA_NO_SANDBOX=1. Harness — отдельный test entry, не production main.

README/ARCHITECTURE описывают CURRENT STATE Stage8 и исторические этапы отдельно. Не добавлены arbitrary workflows, Automation Engine/editor/scripts/PowerShell/Bash/remote commands, scheduler/task queue/recurring jobs/background device monitoring, Internet relay/router/Tailscale/VPN/smart plug, secrets/credentials/key manager, Linux providers, Guide/redesign/motion, Agent/Game.

**После Stage8 остановиться. Stage9 требует отдельного подтверждения пользователя.**
