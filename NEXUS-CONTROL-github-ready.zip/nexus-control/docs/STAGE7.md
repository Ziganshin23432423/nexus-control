# Этап 7 — настоящий Wake-on-LAN для USER DATA

NEXUS CONTROL by **network.onion**. Stage 7 завершён: отправка стандартного Magic Packet через main-only UDP4 provider. Stage 8 не начат.

## Что изменилось

| Часть | Реализация |
| --- | --- |
| Pure packet | `src/shared/magicPacket.ts`: Uint8Array 102 bytes, FF × 6 + MAC × 16, существующая normalization |
| Provider | `src/main/providers/UdpWakeOnLanProvider.ts`: Node.js dgram UDP4, injectable socket/timers, fixed burst |
| Service | `src/main/services/wakeOnLanService.ts`: saved ID → store → validation → provider, отдельный pending guard |
| Ошибки | `wakeOnLanError.ts`: WOL_UNSUPPORTED / DISABLED / BUSY / SEND_ERROR / TIMEOUT и CANCELLED |
| IPC | `wakeRequest.ts`, `registerWakeHandlers.ts`, explicit preload `wakeComputer(id)` |
| Composition | `createPlatformService('win32')` подключает UDP provider; Linux/unsupported slots остаются null |
| UI | `useWakeComputer`, ID-only dispatcher, busy/успех/error toast, кнопка карточки и страницы |
| Tests | `tests/wol.test.ts`, отдельные `electron-wol.cjs` / `electron-wol-harness.cjs` |

SchemaVersion остаётся **1**. Модель Computer, поля macAddress/wakeOnLan.broadcastAddress/wakeOnLan.port, electron-store repository и migrations не менялись. Новых зависимостей и secret/password fields нет. Дизайн Stage 2 сохранён; только необходимая компоновка новой кнопки переносит её на отдельный ряд, чтобы не сжимать RDP/SSH.

## Main service и IPC

`wakeComputer(computerId)` принимает единственный UUID. Preload не предоставляет sendUdp/sendPacket/wakeHost/raw IPC/command execution. Renderer не выбирает MAC, адрес, порт или bytes. Main handler проверяет trusted main window, основной frame и exact URL; extra arguments отвергаются до service.

Service проверяет ID, читает ComputerStore (который проверяет весь envelope), повторяет shared validation сохранённой записи, проверяет Windows MVP target, MAC и наличие WoL config, IPv4/port и provider availability. Linux target получает controlled unsupported error; неизвестные/повреждённые записи не отправляются. Некорректный файл не сбрасывается и не перезаписывается.

Packet строится общим генератором в service. Internal provider request содержит проверенные MAC/broadcast/port, стандартный packet и AbortSignal; это **не renderer API**. Provider повторно проверяет destination/port и полное соответствие packet стандартному MAC payload. Его единственный payload — заново построенный стандартный Magic Packet. Значения и bytes фиксируются до асинхронного bind; изменение request object не может поменять отправку.

На один ID допускается один active burst. Другие ID независимы. Pending guard очищается finally после success/error/cancel. Guard WoL отдельный от общей launch map RDP/SSH. На уровне клиентских кнопок WoL не блокирует существующие RDP/SSH операции; source switch временно заблокирован во время отправки. Редактирование/удаление через production main mutation hook и закрытие NEXUS отменяют pending burst. Пользовательского ожидания загрузки или countdown нет.

**NetworkService не входит в зависимости WakeOnLanService.** Перед WoL нет TCP prerequisite: выключенный ПК может не отвечать. Нет remoteAddress routing для WoL — отправка использует только сохранённый broadcast.

## UDP lifecycle

1. Один `dgram.createSocket('udp4')`.
2. `bind(0)` — ephemeral local port.
3. После bind callback — `setBroadcast(true)`.
4. Три одинаковых 102-byte Magic Packet на saved IPv4/port.
5. Следующая отправка планируется после успешного send callback через **100 ms**. Только два interval timers, без повторяющегося polling.
6. Общий deadline — **2500 ms**, включая bind и sends.
7. После третьего send callback — close socket. Success Promise разрешается после close event.

Error listener остаётся до close, чтобы queued socket error не стал unhandled event. Success, bind error/throw, setBroadcast throw, send error/throw, socket error, timeout и abort идут через общий finish/close. Deadline и interval очищаются; late callbacks не запускают новые sends. При bind failure Node может бросить при close из-за отсутствия работающего handle — этот случай возвращает controlled failure. Socket factory exception также безопасно преобразуется, без оставленного socket.

Provider не использует shell, PowerShell, cmd, netsh, сторонние executable/downloads или отдельную WoL библиотеку. UDP adapter platform-neutral, но production capability сейчас доступна только Windows host. Это не Linux-функциональность.

## Значение результата и UX

Typed result: `{ computerId, state: 'packet-sent', packetsSent: 3 }`.

Кнопка **Включить** видна при сохранённых WoL/MAC и не требует online/ready status. При отправке — **Отправка…**, loader, disabled own button и aria-busy. Success toast — **Magic Packet отправлен**; пояснение: **Отправка не подтверждает включение компьютера. Статус можно проверить вручную.** Error даёт понятную причину и позволяет повторить попытку.

Успешные send callbacks подтверждают локальную UDP отправку, не доставку, принятие NIC/BIOS или загрузку Windows. UI не устанавливает online и не запускает refresh/polling после wake. Все текущие статусы остаются runtime; в storage ничего не пишется. После физического включения можно вручную обновить статусы.

DEMO ветка обрабатывается до USER DATA. Её прежние wake/wake-rdp, ожидание/отмена — только renderer timers/mock. Демо не вызывает wake IPC или UDP provider и не меняет user file. Кнопки wake → wait → RDP/SSH для USER DATA не добавлены.

## Проверки

Выполнена последовательность:

**typecheck → unit tests → production build → Electron WoL QA → Stage6 SSH → Stage5 RDP → Stage4 network → Stage3 CRUD/persistence**.

| Проверка | Результат |
| --- | --- |
| Typecheck main/preload/shared, renderer и tests | Passed |
| Unit tests | **93/93** (71 предыдущий + 22 WoL), fail/skip/cancel = 0 |
| Production build | Passed: main, preload, renderer |
| Electron WoL | **11/11** групп |
| Stage6 SSH regression | **10/10** групп |
| Stage5 RDP regression | **10/10** групп |
| Stage4 network regression | **12/12** групп |
| Stage3 CRUD/persistence regression | **13/13** групп |
| Итого Electron | **56/56** групп |

Unit tests проверяют точные packet bytes/порядок/102 length/16 повторений/normalization/invalid MAC; bind/broadcast/3 sends/saved destination/port/identical packet; snapshot до bind; отсутствие arbitrary payload; create/bind/broadcast/send/close throw, socket error, timeout, unexpected close, cancellation, late callbacks и timers cleanup. Service: invalid/missing ID, corrupted record, target/host unsupported, missing MAC/config, invalid broadcast/port, success, same ID duplicate, different IDs, retry после success/error, shutdown abort. IPC: trusted sender и forged frame/window/URL, extra arguments, ID object с forged payload, безопасные ошибки. Dispatcher: DEMO isolation и отсутствие USER wake-rdp orchestration.

Electron WoL проверяет production unsupported/Linux branch, invalid IDs и second-window guard, затем отдельную test-only DI фазу. В ней используются реальные ComputerStore, WakeOnLanService, UdpWakeOnLanProvider и реальный UDP4 socket, привязанные исключительно к собственному **127.0.0.1 ephemeral-port receiver**. Socket factory instrumentation считает созданные/закрытые handles, может удержать bind callback для busy check и инъектировать send error. Adapter запрещает любой иной адрес/порт. Production source не содержит test flags или provider override.

В полном сценарии: **5 sender sockets создано, 5 закрыто, active = 0**. Четыре успешных burst доставили собственному loopback receiver **12 пакетов**; один injected error оборвал отправку до реального send. 13 записей attempted send в instrumentation включают эту ошибочную попытку. Каждый successful burst содержит ровно три точных пакета. Отдельный test receiver закрывается при завершении Electron QA. Storage bytes до/после wake одинаковы; UI не становится online, повторный клик даёт WOL_BUSY, retry/error/demo/detail/keyboard/760×600 проверены.

Regressions сохраняют предыдущие реальные собственные TCP3389 checks, local→remote fallback, cancellation/concurrency/cleanup, RDP/SSH свежие проверки и mocked safe spawn, CRUD/edit/delete/full restart/corrupt/future schema. Только ожидаемый набор explicit bridge methods дополнен `wakeComputer`; интерфейс сохраняет изоляцию от Node. Renderer/console error arrays пусты в WoL/SSH/RDP/network; CRUD renderer errors пусты. Сеть не передаёт TCP authentication payload.

Машиночитаемые результаты: [wol](./stage7/wol-checks.json), [ssh](./stage7/ssh-checks.json), [rdp](./stage7/rdp-checks.json), [network](./stage7/network-checks.json), [crud](./stage7/crud-checks.json).

## Скриншоты

WoL USER DATA в явном локальном QA окружении. Адрес 127.0.0.1 и ephemeral port — test target, не инструкция настройки реального ПК. Header Windows Desktop — сохранённая Windows-first стилизация; это не свидетельство запуска на Windows. Test entry показывает v0.0 в footer, обычный entry использует package version.

![Главный экран WoL QA](./stage7/main.png)

![Страница компьютера](./stage7/computer.png)

Регрессия обычных пользовательских карточек с реальными локальными TCP checks:

![Главный экран сетевой регрессии](./stage7/network-main.png)

## Ограничения Linux QA

- **Физический Windows ПК не пробуждался.** Loopback доказывает отправку и lifecycle, не broadcast на реальном LAN, BIOS/NIC, сетевую маршрутизацию или boot.
- Production Linux WoL provider равен null. Реальные локальные пакеты доступны только test harness с explicit DI; Linux provider не реализован.
- Terminal/OpenSSH/Console Host/mstsc реально не запускались. SSH/RDP launch success проверен mock Windows provider. Windows interactivity/auth/host key/lifetime smoke ещё нужен.
- Контейнер запрещает TCP22 bind: SSH ready/selection использует injected probes, unavailable — настоящий TCP probe. TCP3389 проверяется собственным loopback listener.
- Root Electron QA использует технический `--no-sandbox` и Xvfb. Production BrowserWindow по-прежнему sandbox true; QA не доказывает Windows OS sandbox.
- Настройки Windows, firewall, registry, службы, BIOS и NIC не менялись. Внешние устройства и публичные UDP destinations не использовались.

## Windows smoke checklist — выполнить позже

1. Распаковать архив; `npm.cmd ci`, `npm.cmd run build`, `npm.cmd start` на Windows 10/11 обычным пользователем, без QA flags. Проверить прежние записи и persistent edit/restart.
2. На собственном target PC по инструкции производителя **вручную** разрешить WoL в BIOS/UEFI и драйвере проводного NIC. Эти действия меняют системные настройки; NEXUS их не выполняет. Убедиться в поддержке выбранного режима сна/выключения и питании NIC.
3. В USER DATA сохранить правильный MAC целевого NIC, broadcast своей подсети (например 192.168.1.255 только для 192.168.1.0/24), port 9. Не использовать loopback из QA скриншотов.
4. При уже выключенном/спящем target нажать **Включить**. Проверить Отправка…, один burst при двойном клике и Magic Packet отправлен с корректным пояснением. Не ожидать автоматического online или открытия клиента.
5. На собственном разрешённом LAN при необходимости проверить исходящие три packets и отсутствие оставленных UDP sender sockets. Затем отдельно подтвердить физическое пробуждение и вручную обновить RDP/SSH статусы.
6. Проверить controlled network error, повторную отправку, missing config hidden, закрытие NEXUS во время pending send, отсутствие изменений computers.json runtime status.
7. Проверить DEMO wake: только mock, user file не меняется и UDP не отправляется.
8. Повторить RDP/SSH Windows smoke: mstsc с правильным адресом; Terminal/OpenSSH и fallback Console Host, prompts/host key verification и настроенные пользователем keys; сессии живут после закрытия NEXUS.

Успешная отправка при неверном MAC/broadcast может не разбудить компьютер — это нормальная граница UDP acknowledgement. Internet WoL не обещается: обычный broadcast и маршрутизация/VPN зависят от сети. Remote relay/router integration отсутствуют.

## Воспроизведение проверок

На Windows общие проверки:

```powershell
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
npm.cmd start
```

В подготовленном Linux QA окружении нужны Electron runtime, Xvfb TCP display и Playwright (внешний runtime tooling, не новая dependency приложения). Сначала собрать tests/build в том же окружении, затем последовательно:

```sh
node tests/electron-wol.cjs
node tests/electron-ssh.cjs
node tests/electron-rdp.cjs
node tests/electron-network.cjs
node tests/electron-crud.cjs
```

QA scripts используют `NEXUS_PLAYWRIGHT_PATH`, `NEXUS_QA_OUTPUT`, `DISPLAY`; root-only test flag задаётся `NEXUS_QA_NO_SANDBOX=1`. Harness files — исключительно testing entries, не production entry.

## Документация и границы

README обновлён до Stage 7, содержит MAC/broadcast/port9, send ≠ power-on, BIOS/NIC и Internet ограничения. ARCHITECTURE теперь начинает с CURRENT STATE Stage7 и явно отделяет исторические Stage1–3, исправляет provider slots и SSH fallback. ROADMAP и будущий Automations модуль не расширены.

Справочные первичные материалы: [Node.js dgram](https://nodejs.org/api/dgram.html), [Intel remote wake basics](https://www.intel.com/content/www/us/en/support/articles/000005793/ethernet-products.html), [Intel настройки Wake-on-LAN](https://www.intel.com/content/www/us/en/support/articles/000059062/ethernet-products/intel-killer-ethernet-products.html). Инструкции конкретного производителя имеют значение для физического ПК.

**Остановиться после Stage 7.** Не реализованы wake→wait→RDP/SSH, polling/countdown/Internet relay/router/VPN/Tailscale, Guide/redesign/motion, Automations, scheduler, scripts/PowerShell/remote commands, credentials/Agent/Game или Linux providers.
