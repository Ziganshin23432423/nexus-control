# Настройки страницы GitHub

Repository name: `nexus-control`

Description:

> Windows desktop control center for RDP, SSH and Wake-on-LAN: saved computers, availability checks, wake-to-connect workflows and offline help.

Topics:

`windows`, `electron`, `react`, `typescript`, `rdp`, `ssh`, `wake-on-lan`, `desktop-app`, `remote-access`

Публичная версия: `1.0.0-rc.1`.

README содержит описание продукта, сценарии использования, screenshot, запуск готовой сборки, подготовку target, инструкции разработки и сборки, ссылки на документацию и фактические ограничения RC.

В репозиторий публикуются исходники, configs, assets, tests и docs. Готовый Windows ZIP предназначен для release asset; его не следует добавлять в git history. Installer asset появится только после успешной сборки на Windows.
