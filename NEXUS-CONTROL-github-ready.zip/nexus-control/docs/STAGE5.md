# Этап 5 — Microsoft RDP client launch

NEXUS CONTROL — by **network.onion**. Windows first. Cross-platform architecture. Linux later.

Этап завершён: пользовательский RDP запускается через Windows provider после свежей проверки. Этапы 1–4 и существующий дизайн сохранены. SSH/Windows Terminal, WoL/UDP, PowerShell, remote execution, Credential Manager, Linux providers и автоматизации не реализованы.

## Поведение пользователя

В **Мои компьютеры** RDP-кнопка доступна, когда RDP настроен и последняя runtime-проверка показывает «Готов». Проверка, неизвестное состояние и недоступность блокируют кнопку. Если RDP отключён в конфигурации, действия нет.

Нажатие показывает **Подключение…** и блокирует повторное действие на карточке и странице того же компьютера. После открытия процесса показывается **RDP-клиент открыт**. UI сразу разблокируется, продолжительность RDP-сессии не влияет на работу NEXUS. Это не сообщение «Подключено»: приложение не знает, прошёл ли пользователь авторизацию.

При недоступном свежем RDP клиент не открывается. Ошибки отсутствующего клиента, системного запуска, неподдерживаемой host OS, некорректных данных и повторного вызова возвращаются контролируемо. Ошибка показывается уведомлением. После отказа можно обновить статусы и повторить попытку.

Дизайн и переходы этапа 2, add/edit/delete и persistence этапа 3, начальная/ручная проверка, отмена refresh, отсутствие polling и защита устаревших результатов этапа 4 сохранены. SSH остаётся disabled в USER DATA; питание пользователя не запускается.

## Main orchestration и безопасность

`window.nexus.openRemoteDesktop(computerId)` — единственная добавленная IPC capability. Результат — `IpcResult<RemoteDesktopLaunchResult>`; успешное значение содержит `state: 'client-opened'`, ID и результат отдельной свежей RDP-проверки. Renderer не передаёт адрес, порт, executable или launch args. Дополнительные IPC arguments отвергаются.

1. `registerRdpHandlers` проверяет отправителя через тот же guard, что существующие handlers: identity главного webContents, identity основного frame, точный разрешённый URL и незакрытое окно. Проверка URL без identity недостаточна.
2. `RemoteDesktopService` валидирует UUID, загружает запись через ComputerStore и повторно проверяет её полной shared validation. Требуются Windows remote computer и `rdpEnabled`.
3. На неподдерживаемой host OS slot `remoteDesktop` равен `null`; возвращается **RDP-клиент доступен только в Windows**. Fresh TCP и процесс в этом случае не запускаются.
4. На Windows выполняется fresh RDP check через существующие `CheckCoordinator.checkRdp` и `NetworkService.checkRdp`. Используются прежние TcpProbe, timeout **2000 мс** и local → remote fallback. SSH при launch не проверяется.
5. Сначала проверяется localAddress. Только после неудачи проверяется отличный remoteAddress. В provider передаётся реальный успешный адрес этого результата. Старый UI статус не заменяет новую проверку.
6. Проверка занимает слот того же глобального pool с лимитом **8 компьютеров**. Она не отменяет UI refresh и не создаёт независимый TCP implementation. Cancel refresh отменяет status checks; CRUD/выход отменяет незавершённые RDP операции.
7. Перед передачей в provider сохранённая конфигурация перечитывается и сравнивается со snapshot. Изменение/удаление или abort не позволяют запустить клиент по устаревшим данным. Успешный адрес дополнительно сверяется с адресами snapshot, службой RDP и фиксированным портом 3389.
8. Main хранит pending operation по ID до окончания fresh check/launch. Второй запрос для этого ID получает `RDP_BUSY`; после успеха/ошибки guard очищается.

Fresh result не записывается в electron-store. Конфигурация остаётся schemaVersion 1; ни status, ни процесс, ни credentials в неё не добавлены. Схема storage и migrations не изменены.

Pure `trustedSender.ts` выделяет существующие identity checks для unit-тестов; требования guard не ослаблены. `rdpRequest.ts` отделяет авторизацию и controlled results от Electron registration. Main/preload/renderer boundaries сохраняются: `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`, `webSecurity: true`. Renderer не получает Node.js, ipcRenderer или provider.

## WindowsRdpProvider

Файл: `src/main/providers/windows/WindowsRdpProvider.ts`. Реализует существующий `RemoteDesktopProvider`; composition root создаёт его только при Windows host. Remote target допускает optional AbortSignal для отмены до запуска после асинхронного discovery.

Discovery использует process environment `SystemRoot`, проверяет абсолютный путь с буквой диска без traversal и ищет только `System32/mstsc.exe` внутри него. Проверяется обычный файл. Это стандартный системный клиент; PATH, пользовательский executable, shell и загрузка стороннего ПО не используются. Не найденный/недоступный файл вызывает `RDP_CLIENT_MISSING`.

Provider повторно проверяет host общей address validation и требует порт 3389. Запуск:

```ts
spawn(executable, [`/v:${validatedHost}`], {
  shell: false,
  detached: true,
  stdio: 'ignore',
  windowsHide: false,
});
```

Это executable и массив аргументов, а не shell-команда. Нет `exec`, cmd, PowerShell, ручной интерполяции shell или аргументов пользователя. Node выполняет штатное Windows quoting. Host допускает только валидированный IPv4/DNS hostname; protocol, port suffix, whitespace/command symbols и дополнительные flags исключены.

Promise разрешается по событию **spawn**, не по завершению RDP-сессии. Ошибка spawn и синхронное исключение возвращают `RDP_LAUNCH_ERROR`. После spawn вызывается `unref`; stdio не связывает lifetime клиента с NEXUS. Error listener остаётся для безопасной обработки позднего события. Процесс не убивается при закрытии приложения, а Node ведёт штатный process lifecycle/reaping.

Проверка не реализует RDP handshake или authentication. Успешный TCP показывает только доступность порта; spawn показывает создание процесса; успешный вход знает стандартный клиент Windows. Клиент может позже показать собственную ошибку — NEXUS её не перехватывает.

Паролей в форме, конфигурации, env приложения и логах нет. NEXUS не вводит пароль автоматически и не передаёт username как RDP argument. Windows использует собственный вход и стандартные возможности клиента. Windows Credential Manager не подключён.

## Demo boundary

`performComputerAction` сначала маршрутизирует DEMO DATA в прежние RAM callbacks. Демо-кнопка RDP показывает **Рабочий стол · демо** и не вызывает `openRemoteDesktop`, сеть или native provider. Для USER DATA доступна только RDP ветка; пользовательские SSH/wake действия не запускают системные capabilities.

`useRemoteDesktop` получает ID, защищает быстрое двойное нажатие синхронным pending Set и показывает busy state во всех представлениях компьютера. Переключение источника данных заблокировано до завершения пользовательского launch, чтобы операция не выглядела как действие демо. Storage остаётся отделённым от демо.

## Проверки

| Проверка | Результат |
| --- | --- |
| `npm run typecheck` | Main/preload/shared, React и tests: успешно |
| `npm test` | **50/50** unit-тестов: 33 прежних + 17 RDP |
| `npm run build` | Production main, sandbox preload, renderer: успешно |
| Electron RDP QA | **10/10** групп |
| Stage4 network regression | **12/12** групп |
| Stage3 CRUD/persistence regression | **13/13** групп |
| Renderer/console errors | 0 в RDP/network QA; renderer 0 в CRUD |
| TCP authentication payload | 0 байт; все проверочные Socket закрыты |

Новые unit-тесты проверяют:

- system discovery без PATH и отсутствие клиента; argument construction;
- `shell:false`, detached/stdio/unref, spawn/error и безопасную обработку позднего error;
- hostile `&`, `|`, `;`, `"`, `'`, `$`, newline, flags, protocol/port suffix;
- RDP disabled, non-Windows remote, invalid ID/config, unsupported host;
- local ready, remote fallback, обе попытки unavailable, fresh отказ после предыдущего ready;
- success/failure/retry, duplicate invocation во время check и launch;
- изменение snapshot, abort и отмену во время async discovery;
- общий concurrency pool без отмены Stage4 refresh;
- sender/window/frame/URL guard, extra args и forged target object;
- demo isolation и отсутствие user SSH/WoL launch.

Сетевые/process зависимости инъецируются. Unit-тесты никогда не запускают настоящий mstsc. Моки используют существующие контракты, а не отдельную модель компьютера.

### Настоящий Electron QA

`tests/electron-rdp.cjs` открывает Electron на виртуальном дисплее с отдельным тестовым профилем. Только собственные listener/адреса `127.0.0.1` / `127.0.0.2`, без внешних компьютеров.

Для проверки successful orchestration внутри настоящего Electron main используется отдельный **test-only entry** `tests/electron-rdp-harness.cjs`. Он загружает неизменённый production main и предоставляет Node-only test object, импортирующий compiled unit modules: настоящий ComputerStore, CheckCoordinator/NetworkService и WindowsRdpProvider с mock discovery/launch. Production IPC при этом не заменяется; renderer не получает тестового API. Код приложения не содержит test flags/backdoor.

Harness выполняет настоящие fresh TCP checks, проверяет local/fallback, отказ после изменения доступности, mock spawn failure и duplicate guard. **Процесс mstsc не создаётся**. Отдельно через настоящий production IPC и кнопки проверены unsupported Linux result, ID-only validation, чужое окно, enabled/disabled RDP, уведомления и demo isolation.

Stage3/4 regression scripts запускают обычный production entry, проверяя persistence после полных Electron restart, corrupt/future storage без overwrite, CRUD/демо, статус после рестарта, refresh/cancel, отсутствие polling, fallback, безопасность bridge, keyboard dialog и 1280×720 / 760×600 layout.

Один начальный CRUD-прогон завис в Playwright `app.close`; он был остановлен. QA close получил ограничение 20 секунд, с явной ошибкой и очисткой тестового процесса при timeout. Повторный полный CRUD-прогон прошёл **штатные закрытия и все 13 групп**, без срабатывания watchdog. Изменения shutdown-кода приложения ради этого не делались.

Машиночитаемые результаты: [RDP](./stage5/rdp-checks.json), [сеть](./stage5/network-checks.json), [CRUD](./stage5/crud-checks.json).

![Production главный экран этапа 5](./stage5/main.png)

![Production страница компьютера этапа 5](./stage5/computer.png)

Эти скриншоты сняты при Stage4 regression на production-сборке **этапа 5** с обычным entry, настоящим loopback TCP listener и доступной RDP-кнопкой. Это не доказательство запуска Windows клиента.

### Повторение QA

Обычные обязательные проверки не требуют Playwright:

```powershell
npm.cmd ci
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
```

Отдельные Electron QA scripts требуют установленного Playwright (или `NEXUS_PLAYWRIGHT_PATH` с абсолютным путём к нему), свободного TCP 3389, writable temporary directory и дисплея. После `npm test` и `npm run build`:

```sh
node tests/electron-rdp.cjs
node tests/electron-network.cjs
node tests/electron-crud.cjs
```

RDP QA script предназначен для текущего **Linux QA environment** и mock/unsupported path, не для Windows smoke. Network/CRUD scripts выбирают штатный Electron executable для host OS; RDP/network QA поднимают свой loopback listener и закрывают его. `NEXUS_QA_OUTPUT` задаёт папку screenshot/report/profile.

В текущем контейнере используются TCP Xvfb display и `NEXUS_QA_NO_SANDBOX=1` только для запуска тестов от root. В production-коде и обычных npm командах такого флага нет. Поэтому OS-level sandbox на Windows ещё требует smoke test. Контейнер запрещает слушать TCP 22: real SSH unavailable проверен, success остаётся unit mock. Никакие Windows настройки, firewall, службы, registry или BIOS не менялись.

## Что проверить на Windows позже

Реальный mstsc.exe не запускался в Linux. Windows smoke test остаётся обязательным:

1. На своём целевом Windows PC подготовить RDP самостоятельно по [инструкции Microsoft](https://learn.microsoft.com/en-us/windows-server/remote/remote-desktop-services/remotepc/remote-desktop-allow-access). Нужен выпуск с RDP host; Windows Home может быть клиентом, но не стандартным RDP host. Включение допуска и разрешённых пользователей — ваши системные изменения, NEXUS их не делает.
2. На Windows host NEXUS выполнить build/start обычными командами без QA `--no-sandbox`, добавить свой компьютер и дождаться RDP «Готов».
3. Нажать «Рабочий стол»: должен открыться стандартный клиент с правильным local IP/hostname. Вход должен выполняться в окне Windows, без NEXUS password field.
4. Указать намеренно недоступный **свой** local endpoint и доступный свой remote/VPN endpoint: клиент должен получить remote address. Для двух недоступных адресов клиент не открывается.
5. Между status ready и кликом сделать свой RDP endpoint недоступным: fresh check должен вернуть ошибку без launch. Обновить сеть/статус и повторить.
6. Быстрый повторный клик во время check/launch не должен создавать несколько клиентов. После завершения кнопка снова работает.
7. Закрыть NEXUS после открытия RDP: уже открытая сессия должна остаться. После restart сохранённая карточка должна восстановиться.
8. Проверить стандартный системный discovery, spawn и OS sandbox на настоящих Windows 10/11. Отсутствие клиента/spawn error покрыты mocks; не удалять и не переименовывать Windows system files ради теста.
9. Переключиться на DEMO DATA: RDP показывает только demo toast, SSH/WoL пользователя остаются без настоящего launch/packet.

Официальные основы реализации: [Microsoft mstsc `/v`](https://learn.microsoft.com/windows-server/administration/windows-commands/mstsc), [Node.js child_process: spawn/error/detached/unref](https://nodejs.org/api/child_process.html).

**После этапа 5 работа остановлена. SSH и следующий этап — только после подтверждения пользователя.**
