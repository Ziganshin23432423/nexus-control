# Stage12 — Windows Stabilization / Release Candidate

Baseline — принятый Stage11C. Визуальное направление, Guide (59 статей), providers/actions, motion и appearance architecture сохранены. Версия package **0.1.0**; installer/updater/signing и Stage13 не реализованы.

## Реальные изменения

- Общая strict validation доверенного Windows directory для RDP/SSH discovery. RDP раньше слабее SSH проверял SystemRoot и допускал slash/traversal-варианты; теперь они отвергаются до file access. Unicode и пробелы внутри абсолютного drive path поддерживаются. Нет PATH fallback, shell, cmd/PowerShell или пользовательского executable.
- Отдельный safe `npm.cmd run smoke:windows`: host/arch/version, build/source, реальные userData write permissions, изолированный Electron/localStorage, системные клиенты, optional UDP4 bind/close. PASS/WARN/FAIL зависят от выбранного сценария. Target OpenSSH Server не локальный prerequisite.
- Exclusive probe удаляет только собственный успешно созданный файл, включая тест collision с существующим файлом. Smoke не читает computers/settings, не отправляет пакеты и не запускает remote clients. Temporary diagnostic BrowserWindow: nodeIntegration=false, contextIsolation=true, sandbox=true, webSecurity=true, без preload/IPC.
- Source audit проверяет case-insensitive filenames/directories, неоднозначные module stems, relative imports, HTML/SVG и CSS asset spelling. Archive audit отсекает generated folders, profiles, stale `starfield.ts`, secrets files и вложенные ZIP. Старый Starfield regression сохранён.
- 10 новых meaningful unit tests Windows readiness; отдельная Electron readiness QA. Чистая установка проверяется отдельно от давно установленного workspace.

## Границы изменений

Сравнение с принятым `NEXUS-CONTROL-stage11.zip`: **115 из 117 существовавших src/public файлов byte-identical**. Только `WindowsRdpProvider.ts` и `windowsSshDiscovery.ts` изменены для общего path validator; добавлены main-only readiness modules и trusted path helper. **15 Guide data/metadata .ts файлов неизменны**. Renderer, main lifecycle/security/protocol, preload/15-method IPC, shared model/validation, storage/migrations/schemaVersion 1, services/network/orchestration и UDP provider не изменены. Package dependencies/lock/version прежние; добавлены scripts/typecheck config, tests и docs. ROADMAP не менялся.

## Повторный аудит Stage1–11

- RDP: absolute mstsc, validated destination/fixed3389, separate args, shell:false/detached/unref, duplicate guard. ACK означает открытый клиент, не login.
- SSH: System32 OpenSSH, WindowsApps Terminal alias, Console Host fallback; separate username (Unicode, DOMAIN и UPN), fixed22, `--`, host последний, remote command отсутствует. Host-key verification не отключается. Native sessions не принадлежат lifecycle NEXUS и не убиваются при shutdown; это подтверждено boundary tests, а не реальным Windows login.
- WoL: unchanged UDP4 lifecycle, saved broadcast/port, три 102-byte standard packets, bounded deadline/cleanup и duplicate guard. Реальная loopback QA не доказывает физическое пробуждение/NIC/BIOS.
- Orchestration: unchanged 90-second bounded wait, sequential checks/cancel, no background polling, fresh selected-service check и local→remote fallback, stale-config protection, cleanup/ownership.
- Store: CRUD/ID/schema1 после полного restart, corrupt/future data без overwrite; appearance persistence отдельно, reset не меняет computers.json.
- Security: nodeIntegration=false, contextIsolation=true, sandbox=true, webSecurity=true; sender/frame/window/url guards, local protocol/CSP, ID-only privileged actions. Нет universal execution, arbitrary UDP/process targets или новых secret fields. Guide offline/context/search/static-copy остаётся inert.
- Error Boundary и controlled launch/network/storage errors сохранены; пользователю не выводятся raw stacks. Существующая development/main error диагностика сохранена, большой logger не добавлялся. Smoke не печатает environment, machine paths или native stderr.
- Appearance/starfield: single owned RAF, cap DPR 1.5 и stars 220, Full/Calm rates и Minimal0continuousRAF, pointer cleanup, reduced-motion, pause/resume, six-card/Guide/resize performance checks сохранены. CSS zoom не добавлен.

## Результаты финального цикла

Финальный цикл и отчёты заполняются только после фактического завершения: typecheck → unit tests → production build → readiness → appearance → Guide → UX → orchestration → WoL → SSH → RDP → network → CRUD.

**Финальная верификация пройдена, 2026-10-02, Linux x64 / настоящий Electron + изолированные DI harness.**

| Проверка | Результат |
| --- | --- |
| Typecheck main/web/tests/smoke | PASS |
| Unit tests | **197/197**, fail/skip/cancel 0 |
| Production build | PASS |
| Stage12 readiness Electron | **6/6** групп |
| Stage11 appearance Electron | **17/17** групп |
| Stage10 Guide Electron | **14/14** групп |
| Stage9 UX Electron | **22/22** групп |
| Stage8 orchestration Electron | **13/13** групп |
| Stage7 WoL Electron | **11/11** групп |
| Stage6 SSH Electron | **10/10** групп |
| Stage5 RDP Electron | **10/10** групп |
| Stage4 network Electron | **12/12** групп |
| Stage3 CRUD/persistence Electron | **13/13** групп |
| Всего финальный Electron cycle | **128/128** групп |
| Effects × density × size × views | **120/120** |
| Свежий npm ci → typecheck → tests → build | PASS, 197 tests |
| Свежие dependencies: production Electron readiness | **6/6** групп |
| Свежие dependencies: dev --watch / Guide / isolation | PASS |
| Native Windows hardware / DPI / remote login | **Не выполнялся** |

Непредвиденных renderer/console ошибок в финальных suites нет. Полный [machine-readable summary](./stage12/final-results.json), отдельные `*-checks.json` и [source/security audit](./stage12/security-audit.json) включены в архив. Неуспешные промежуточные попытки QA исправлены в harness: dynamic import вынесен из Playwright evaluate, для Xvfb выбран свободный display. Production код из-за этих ограничений не менялся; полный цикл после исправлений повторён успешно.

Свежий production запуск использовал новый npm-ci Electron, а dev — фактический electron-vite dev --watch, изолированный userData и test-only Linux --noSandbox. Windows dev/production не объявляются проверенными на основании этого.

### Captures без redesign

![Main six — Stage12 regression](./stage12/main-six.png)

![Guide — unchanged](./stage12/guide-home.png)

![760×600 — readiness](./stage12/small.png)


## Clean installation и npm warning

В отдельной пустой dependency directory обычный `npm ci` (без ignore-scripts/blanket approvals) установил 108 packages и выполнил штатный project postinstall install-electron за 29 секунд. Node24.19.0/npm11.9.0, Linux x64. `allow-scripts/esbuild postinstall not yet covered` здесь **не воспроизвёлся**; наблюдался только environment warning npm об http-proxy. Clean typecheck/tests/build, отдельные production readiness (6 групп) и реальный dev --watch/Guide startup прошли.

По официальной документации npm install policy может пропускать неразрешённые dependency scripts; postinstall esbuild проверяет binary version и оптимизирует CLI. Не утверждаем, что warning безопасен при любой npm/Windows конфигурации: считать его non-blocking можно лишь после успешных clean install/build/startup на конкретной машине. Blanket approval не добавлен, security policy npm не изменена. Ссылки: [npm](https://docs.npmjs.com/cli/v11/commands/npm-install-scripts/), [esbuild](https://esbuild.github.io/getting-started/).

## Windows manual gate — не подменяется Linux QA

**Настоящий Windows hardware smoke НЕ выполнялся.** На Windows остаются: clean npm ci/dev/production, native discovery/activation mstsc/Terminal/conhost, настоящая RDP/SSH authentication и session lifetime, физический WoL, VPN routing, Windows minimize/visibility/font rendering и DPI100/125/150% (Bahnschrift/Segoe/Cyrillic/DPR/monitor transfer). Optional local SSH — только уже настроенный server, без установки/служб/firewall.

[WINDOWS-SMOKE.md](./WINDOWS-SMOKE.md) — практический checklist A (один ПК) / B (разрешённый target). На Linux/Xvfb используются CLI no-sandbox **только в test harness**, production sandbox preference сохранён. Linux AF_UNIX restriction требует TCP Xvfb; native minimize не является Windows document visibility доказательством, appearance QA фиксирует explicit visibility seam. TCP22 bind запрещён средой: SSH success проверяется DI, real probe проверяет unavailable; TCP3389/UDP loopback проходят. Ни одна из этих проверок не названа Windows hardware smoke.

## Доставка

ZIP — source release candidate, не installer. Распаковывать в новую пустую директорию, не поверх старой. UserData вне проекта не удалять. Архив не содержит node_modules/out/.test-out/.smoke-out/cache/profiles/old engine/вложенных ZIP; historical documentation screenshots сохранены как reference, не executable artifacts. Stage13 не начат.
