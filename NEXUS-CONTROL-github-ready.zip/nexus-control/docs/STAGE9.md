# Stage 9 — Operational UX Hardening

Stage9 завершён. Это функциональная UX-доработка существующих операций, **не новая remote-management capability**. Stage2 visual system, шрифты/масштаб/spacing, Windows-first abstractions и сетевые технологии Stage1–8 сохранены. Stage10 NEXUS Guide не начат; ROADMAP не изменён.

## Что изменилось

| Область | Поведение |
| --- | --- |
| Operation UX | Общая терминология фаз; formatter прогресса и lifecycle cleanup, без универсального execution API |
| Error presentation | Все 27 typed error codes → короткий заголовок, понятная помощь, retry policy. Raw exception не показывается |
| Retry | Явное «Повторить» в временной ошибке/timeout; конкретный прежний ID-only метод. Новая отправка WoL только по нажатию |
| Countdown | Main сообщает remainingSeconds около 1 Hz, 90→0 после send ACK; тот же monotonic deadline и отмена Stage8 |
| Network | Duplicate refresh блокируется; partial/duplicate/contradictory результаты отвергаются; Cancel восстанавливает baseline или unknown и поясняет это |
| Conflicts | Состояние конкретного PC блокирует конфликтующие действия; Cancel доступен. Другая карточка независима |
| Toasts | success/info/warning/error, максимум три, подавление duplicate/spam. Success/info 4,5 s; error/warning до закрытия/вытеснения |
| Error Boundary | Фирменный fallback вместо пустого окна, без stack. «Перезапустить интерфейс» remounts React App и перечитывает данные |
| Storage | Ошибка чтения, «Файл не очищен», повторная загрузка и demo; corrupt/future файл не reset/overwrite |
| Details | Whitelist code/service/address type (если известен)/timestamp/AppInfo version. Нет secrets, config dump, objects или raw paths |
| Accessibility | Keyboard retry/Cancel/Enter/Space/Esc, visible focus, aria-live/status/busy; reduced-motion сохранён |

Повторяет операцию пользователь, а не фон: automatic retries нет. Missing component/unsupported/disabled/BUSY предлагает исправить причину или завершить другую операцию; retry не обещает успеха. Один action даёт максимум один итоговый toast. Direct launch/wake guards в main по-прежнему authoritative.

**Только корректные утверждения:** RDP-клиент открыт; SSH-терминал открыт; Magic Packet отправлен. Ни одно из них не подтверждает авторизацию, доставку пакета или включение ПК. Combined flow не выставляет ONLINE автоматически.

## Countdown и cleanup

Необязательное `remainingSeconds` расширяет прежний read-only progress payload. Main вычисляет его из monotonic clock/deadline; renderer форматирует, округляет вверх и ограничивает 0–90. Нет нового IPC метода, renderer timeout input, фоновой сети или дополнительного TCP polling.

Timer публикует только waiting около раза в секунду, прекращается перед launching и очищается finally вместе с прежним deadline/delay lifecycle. В sending времени ещё нет: deadline начинается после WoL ACK. Cancel/error/success снимают renderer job; поздние progress events вне pending ID игнорируются. Countdown не влияет на checks, fixed pauses, slot ownership или выбранный endpoint.

Error Boundary снимает child tree при сбое. Unmount workflow hook отменяет pending combined operations и subscription; toast/network hooks очищают timers и проверки. «Перезапустить интерфейс» создаёт App заново без ослабления will-navigate/will-frame-navigate запретов и без privileged reload IPC. Уже открытые native sessions не закрываются. Повтор splash metadata запроса также работает без навигации.

## Изменённые файлы

- Renderer: `state/operationUx.ts`, `state/notifyError.ts`, toast/direct-action/workflow/network hooks, Error Boundary, формы и компоненты действий.
- Main: только progress metadata и countdown lifecycle в существующем `WakeAndConnectService`.
- Shared: только дополнительное информационное поле progress. Computer model/storage schemaVersion **1** без изменений.
- Tests: `operationUx.test.ts`, status/coherence и main countdown lifecycle; `electron-ux.cjs` / отдельный test-only harness. Исторические Electron scripts обновляют только UI ожидания новых сообщений/countdown.

Сравнение со Stage8 ZIP подтвердило byte-identical ROADMAP, package.json/lock, validation, Magic Packet, storage schema/store/repository, network/check coordinator, UDP и Windows providers, security и preload. Версии зависимостей и allowlist IPC сохранены. Новых arbitrary command/shell/remote execution возможностей нет. Automations, Linux providers, Guide, redesign, installer не добавлены.

## Проверки

Последовательность завершилась успешно:

1. `npm run typecheck` — main, preload, shared, renderer, tests.
2. `npm test` — **145 passed**, 0 fail/skip/cancel. Было 127, добавлены 18 групп Stage9.
3. `npm run build` — production main/preload/renderer.
4. Stage9 Electron UX QA — **22 passed**.
5. Stage8 orchestration — **13 passed**.
6. Stage7 WoL — **11 passed**.
7. Stage6 SSH — **10 passed**.
8. Stage5 RDP — **10 passed**.
9. Stage4 network — **12 passed**.
10. Stage3 CRUD/persistence — **13 passed**.

Итого **91 выполненная группа Electron QA**, включая повторяемые проверки регрессии, а не 91 уникальный сценарий.

Unit охватывает mapping, honest success titles, retry policy, countdown формат и lifecycle, очистку progress, toast dedup, семь capability combinations, фактический fallback component, whitelist технических сведений и partial/stale/coherence status guard.

Electron открывает production UI. Stage9 QA покрывает direct RDP/SSH success/error/retry, Wake success/error/retry, обе combined операции, sending/waiting/countdown/launching/success, timeout, keyboard cancel/retry, network refresh/cancel, corruption recovery/demo, независимый другой ID, семь capabilities, безопасный fallback и восстановление, 760×600 и zero renderer/console errors штатных flows. Имитированный runtime ErrorEvent — отдельная контролируемая проверка fallback, без вывода сообщения исключения.

QA отчёты рядом: [UX](./stage9/ux-checks.json), [Orchestration](./stage9/flow-checks.json), [WoL](./stage9/wol-checks.json), [SSH](./stage9/ssh-checks.json), [RDP](./stage9/rdp-checks.json), [Network](./stage9/network-checks.json), [CRUD](./stage9/crud-checks.json).

Final flow/UX snapshots: active sockets/probes/timers/slots/claims **0**. WoL regression — реальные собственные loopback packets и closed sender sockets. TCP regression — **0 authentication/payload bytes**, remaining clients **0**. Runtime/progress/diagnostic поля не persist; corrupt/future storage сохранён; demo не обращается к USER DATA capabilities.

## Screenshots

![Главный экран production UI; network/native operations test-only DI](./stage9/main.png)

![Countdown 73 секунды и keyboard-accessible Cancel, 760×600](./stage9/countdown.png)

![Страница компьютера](./stage9/computer.png)

![Безопасный fallback](./stage9/fallback.png)

Скриншоты тестового entry: footer version 0.0.0 может отличаться от обычного запуска 0.1.0. Header «Windows Desktop» — сохранённый UI label, не доказательство native Windows host.

## Ограничения Linux-окружения

Настоящие mstsc.exe, Windows Terminal, OpenSSH console/host key/password prompts и физический wake не проверялись. QA сначала проверяет production unsupported/security path, затем explicit test-only DI использует реальные services/providers с mock probes/native launch/UDP socket facade и virtual clock. Production source не содержит QA bypass. Stage7/4 regressions отдельно используют собственные настоящие loopback UDP/TCP resources. Bind TCP22 запрещён окружением (EACCES); SSH success — injected probe.

Electron QA от root использует тестовый --no-sandbox с виртуальным дисплеем; это не проверка OS sandbox Windows. В production настройках sandbox/contextIsolation/webSecurity остаются true, nodeIntegration false. Linux providers/функциональность не реализованы.

## Windows smoke checklist — выполнить на собственных ПК

Без автоматического изменения system/firewall/BIOS/NIC настроек:

- `npm.cmd ci`, typecheck, tests, build, start; проверить обычный запуск Windows без тестового --no-sandbox.
- USER DATA add/edit/delete, закрытие всего приложения и повторный запуск; записи и ID сохраняются.
- Ручная проверка и Cancel: различать неизвестное состояние и недоступность; повторное Обновить блокируется, поздний ответ не меняет отменённое состояние.
- RDP/SSH launch: увидеть ровно одно уведомление об открытии; реальные вход и проверка host key выполняются стандартным клиентом.
- Изменить доступность службы между READY и launch: ошибка с подсказкой/retry, без ложного «подключено».
- Direct WoL: один burst по нажатию, «Magic Packet отправлен», status не становится online автоматически. Физическая поддержка зависит от отдельно настроенных BIOS/NIC/сети.
- Combined RDP/SSH: sending → waiting с убывающим временем → открытие клиента; Cancel доступен с клавиатуры и снимает ожидание.
- Timeout на выключенном/недоступном собственном ПК: controlled error, **Повторить** отправляет один новый burst. Другие карточки независимы.
- Проверить popup/details, focus, Tab/Shift+Tab/Esc, 760×600 и reduced-motion.
- Для проверки corruption использовать отдельный тестовый профиль/копию файла; убедиться, что приложение не очищает его и demo доступно.

Эти Windows/NIC/BIOS проверки ещё не выполнены здесь. Stage9 завершён; **Stage10 NEXUS Guide требует отдельного подтверждения**.
