# Этап 4 — реальные TCP-проверки

NEXUS CONTROL — by **network.onion**. Этап завершён 1 октября 2026 года. Дизайн этапа 2, persistent storage этапа 3 и platform/provider abstraction сохранены. Реальные проверки выполняются только для USER DATA, DEMO DATA остаётся mock.

## NetworkService и алгоритм

В `main/services` добавлены:

| Модуль | Ответственность |
| --- | --- |
| `tcpProbe.ts` | Node.js Socket, таймаут, latency, cleanup, нормализация errorCode; injected socket/timer/clock для tests |
| `networkService.ts` | Повторная shared validation записи, включённые службы, local → remote fallback, итоговый runtime status |
| `checkCoordinator.ts` | Загрузка из ComputerStore, cancellation, общий pool, проверка актуальности конфигурации перед публикацией |

`shared/networkConstants.ts` задаёт TCP 3389 для RDP, TCP 22 для SSH, timeout **2000 мс** и concurrency **8 компьютеров**. Renderer не выбирает порт или произвольную цель; сеть недоступна ему напрямую.

Для каждой включённой службы выполняется connect к сохранённому localAddress. При успехе сохраняются addressUsed, addressKind = local и latencyMs. При неудаче, если remoteAddress задан и отличается без учёта регистра, выполняется одна попытка к нему на том же порту. Успех сохраняет addressKind = remote. При неудаче обоих адресов служба unavailable. RDP и SSH проверяются независимо и параллельно; у них могут быть разные успешные адреса.

Отключённая служба получает disabled без соединений. Ping/ICMP, внешние программы, handshake, аутентификация и сетевое сканирование не используются.

## Timeout, cleanup и отмена

У каждой попытки wall-clock deadline от начала соединения, включая ожидание DNS. Не используется один только socket idle timeout: он сам не закрывает соединение. При connect, error, timeout или abort вызывается destroy. Таймер и abort listener снимаются; error listener сохраняется до close для безопасной обработки уже поставленной в очередь ошибки. После close снимаются socket listeners, завершается Promise и освобождается слот. Результат фиксируется один раз: поздняя ошибка не меняет ready.

Отмена до старта не создаёт Socket. При отмене между local и remote второй адрес не проверяется. NetworkService ждёт завершения обеих параллельных служб через allSettled, прежде чем вернуть или отклонить результат и освободить computer slot.

Обычные ECONNREFUSED, ETIMEDOUT, недоступность маршрута и ошибки разрешения имени становятся unavailable, без огромной application error. Диагностические коды ограничены whitelist; raw message из Node не передаётся UI. Неожиданные внутренние ошибки имеют контролируемый NETWORK_ERROR, отмена — CANCELLED. Ошибки конфигурации/хранилища сохраняют безопасные результаты Stage 3.

2 секунды — на адрес одной службы. При fallback компьютер может проверяться примерно 4 секунды, плюс очередь. Большой список занимает несколько волн, но не блокирует renderer; постоянного background monitoring нет.

## Runtime result и интерфейс

`Computer` и schemaVersion 1 не менялись. `ConnectionCheckResult` расширен service details и configUpdatedAt. Каждая деталь содержит service, status, addressUsed/addressKind, фиксированный port, latencyMs, errorCode и список попыток. Disabled имеет пустые attempts. Эти данные не записываются в electron-store.

| Computer status | Русский текст и смысл |
| --- | --- |
| unknown | Не проверен — результата пока нет |
| checking | Проверка… |
| online | Онлайн — хотя бы одна настроенная служба отвечает |
| offline | Недоступен — есть настроенные службы, но ни одна не ответила |
| no-services | Нет проверяемых служб — RDP и SSH выключены в карточке, запросов нет |

Отдельные RDP/SSH statuses: Не настроен / Не проверен / Проверка… / Готов / Не отвечает. WoL: Настроен означает только сохранённую конфигурацию; его доступность и отправка пакета не проверяются.

После загрузки пользовательского списка выполняется initial refresh. Изменение CRUD или возврат из демо запускает свежую проверку текущего списка. Далее главная кнопка **Обновить** запускает настоящий refresh, кнопка на странице устройства — проверку выбранного ID. На главной доступна **Отмена проверки**. Периодического polling нет.

Карточки и страница сохраняют прежний дизайн. В **Подробнее о проверке** доступны порты, успешный адрес, local/remote attempts, latency и время проверки. Доступность по TCP не означает успешный RDP/SSH handshake или аутентификацию. Кнопки настоящего рабочего стола/терминала остаются отключёнными даже при ready.

## Typed IPC и validation

Добавлены три конкретных метода preload:

- `checkComputerStatus(computerId)` → `IpcResult<ConnectionCheckResult>`.
- `refreshAllComputerStatuses()` → `IpcResult<ConnectionCheckResult[]>`.
- `cancelComputerStatusChecks()` → завершение текущей проверки; без target/port аргументов.

Сохранены metadata и четыре CRUD capabilities. Мост не предоставляет net, dns, fs, child_process, ipcRenderer или electron-store. BrowserWindow сохраняет nodeIntegration false, contextIsolation true, sandbox true и webSecurity true. CSP renderer не расширялась ради networking.

Каждый handler проверяет sender, основной frame и точный разрешённый URL. ID проверяется в ComputerStore; запись загружается только из сохранённой конфигурации, которая целиком проходит существующую shared validation. NetworkService ещё раз валидирует выбранный Computer непосредственно перед connect. Повреждённая конфигурация блокирует соединение и не сбрасывается.

## Concurrency и stale results

Один общий pool допускает **8 компьютеров**, RDP/SSH внутри каждого параллельны — максимум 16 объектов Socket. Pool общий для разных IPC requests: старый слот освобождается только после завершения его сетевых операций. Восемь workers выбирают следующие компьютеры из списка, не создавая тысячи одновременных подключений.

Новый refresh или checkComputerStatus отменяет предыдущий запрос. Cancel, успешный CRUD, закрытие окна и завершение приложения также отменяют активную проверку. Перед публикацией coordinator ещё раз читает конфигурацию и сравнивает проверенные записи с исходным snapshot. Edit/delete из другого источника не позволяют вернуть устаревший результат.

Renderer использует `StatusRequests` с request generation. Завершение старого запроса не меняет данные, loading или error нового. Дополнительно проверяются identity snapshot, ID и configUpdatedAt. Кэш завершённых статусов привязан к объектам текущей конфигурации: даже edit с совпавшим timestamp не переиспользует результат другой записи. Переключение в демо и изменение списка инвалидируют поколение. Runtime state не переживает restart.

## Финальная последовательность

Выполнено: **typecheck → tests → production build → Electron UI/network QA → CRUD regression QA**. Ошибки исправлены до завершения этапа.

| Проверка | Результат |
| --- | --- |
| `npm run typecheck` | Пройдено: main/preload/shared, renderer и unit tests |
| `npm test` | 33/33, ошибок и skipped нет |
| `npm run build` | Пройдено: main ESM, preload CJS, renderer |
| `tests/electron-network.cjs` | 12/12 групп на настоящем Electron |
| `tests/electron-crud.cjs` | 13/13 групп регрессии storage/CRUD |
| Renderer JavaScript и console errors сетевого QA | 0 |
| Оставшиеся подключения к тестовым серверам | 0 |
| Переданные TCP payload bytes | 0 — без authentication или commands |

15 прежних unit-тестов сохранены. Добавлено 18 тестов: TCP success/refused/unreachable/DNS/generic error, deadline, cancel, ранний close, synchronous error, cleanup, поздняя ошибка, local success, local fail → remote success/fail, отсутствие повторного идентичного адреса, RDP-only/SSH-only/both/no-services, invalid stored config, parallel cleanup, stale result protection, concurrency при пересекающихся refresh и snapshot invalidation.

Unit-тесты используют injected probes/socket/timer/clock и memory repository, не зависят от внешнего интернета. Fake timers проверяют deadline без реального ожидания 2 секунд. Число unit-тестов — именованные test cases, внутри некоторых проверяются несколько сценариев.

## Настоящий Electron / network QA

Скрипт поднимает собственный TCP listener на **127.0.0.1:3389** и использует только **127.0.0.1 / 127.0.0.2**. Второй loopback-адрес намеренно не слушает: так проверяется refusal и fallback. MAIN PC, PC HOME, OFFLINE PC и CONFIG ONLY — тестовые записи в отдельном временном профиле, а не демо-фикстуры, записанные в пользовательский файл.

Проверено:

1. UI create → настоящий initial RDP ready, SSH unavailable; launch buttons отключены.
2. Local refusal → remote ready; offline и no-services показываются раздельно.
3. Структурированные результаты и раскрытые diagnostics с адресами, попытками, портами и latency.
4. Отсутствие polling в контрольном интервале; файл остаётся побайтово неизменным после проверок.
5. Остановка и повторный запуск listener → изменение статусов по manual refresh.
6. Повторные refresh/cancel → UI остаётся работоспособным; deterministic stale/cancel проверены unit-тестами.
7. Demo checks, mock wake/cancel и demo add → ноль новых контактов с listener и неизменный user file.
8. ID-only API отвергает forged target/port; другое окно с тем же URL/preload не проходит sender guard. Проверены узкий bridge, отсутствие Node/browser storage и защитные preferences.
9. Полные Electron restarts восстанавливают CRUD и пересчитывают runtime statuses при изменившейся сети; edit/delete тоже переживают restart.
10. Invalid saved address блокирует все проверки и оставляет файл неизменным.
11. Desktop layout 1280×720 / 760×600 и Esc формы.
12. Закрытие server-side sockets, отсутствие payload и ошибок renderer.

Машиночитаемые результаты: [network-checks.json](./stage4/network-checks.json), [crud-checks.json](./stage4/crud-checks.json).

Окружение: Electron 44.5.1, Node.js 24.19.0, Ubuntu container, виртуальный Xvfb TCP display. **Контейнер запрещает bind к TCP 22 с EACCES**. Реальный положительный SSH listener поэтому не поднят: его success и fallback проверены unit mocks, реальная недоступность 22 — Socket в Electron. Это ограничение явно сохранено в network report; системные настройки ради обхода не изменялись. В среде, где порт 22 разрешён и свободен, QA script дополнительно проверяет настоящий SSH-port success.

Из-за root test environment использован только тестовый `NEXUS_QA_NO_SANDBOX=1`. Он добавляет --no-sandbox тестовому процессу, не меняя настройки приложения или обычные dev/start scripts. Windows 10/11 networking и OS sandbox ещё требуют настоящего Windows smoke test. Проверка общего сервиса в контейнере не является реализацией Linux providers.

## Как проверить на Windows

```powershell
npm.cmd ci
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
npm.cmd start
```

На своих разрешённых устройствах с уже настроенными службами проверьте:

- RDP включён в карточке, 3389 доступен → RDP Готов и компьютер Онлайн.
- Только SSH, 22 доступен → SSH Готов и компьютер Онлайн.
- Одна служба доступна, другая нет → отдельные статусы, общий Онлайн.
- Верный remoteAddress при недоступном localAddress → remote в diagnostics. Это должен быть адрес того же разрешённого компьютера через вашу существующую сеть/VPN.
- Обе службы не отвечают → Недоступен, без большой ошибки. Это может быть firewall, адрес, маршрут или выключенное устройство.
- RDP и SSH выключены в карточке → Нет проверяемых служб, без сетевых запросов.
- Повторный refresh, отмена, edit/delete во время проверки, переключение в демо → старые результаты не возвращаются.
- Полное закрытие и restart → записи сохранены, статусы определяются заново; демо остаётся mock.

Приложение не включает RDP/SSH Server, не меняет firewall, службы или сетевые адаптеры. Такие настройки выполняются пользователем отдельно. Сейчас проверяется порт, клиент подключения не запускается.

Для дополнительного Electron QA нужен отдельно доступный Playwright: `node tests/electron-network.cjs` и `node tests/electron-crud.cjs` после build. `NEXUS_PLAYWRIGHT_PATH` позволяет использовать внешний установленный модуль, `NEXUS_QA_OUTPUT` — выбрать каталог отчёта. Скрипты создают отдельные временные профили; network QA требует свободного 3389 и опционально свободного/разрешённого 22. На машине с уже занятыми портами лучше использовать ручной smoke test, а не останавливать системные службы ради QA.

## Скриншоты

![Реальные TCP-статусы на loopback test targets](./stage4/main.png)

![Remote fallback и технические результаты](./stage4/computer.png)

## Граница этапа

Не реализованы запуск mstsc/ssh/Windows Terminal, RDP authentication, UDP или Magic Packet sending, PowerShell/remote execution, shutdown/restart, Credential Manager, Tailscale/VPN, scanning, scheduler или Linux providers. Новых системных провайдеров и зависимостей не добавлено. ROADMAP и разделы будущих модулей не менялись.

README обновлён, правила текущего этапа закреплены в AGENTS.md. Этап 4 завершён; этап 5 не начинается без запроса пользователя.
