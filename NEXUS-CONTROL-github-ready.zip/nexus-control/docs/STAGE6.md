# Этап 6 — интерактивный SSH

NEXUS CONTROL — by **network.onion**. Windows first. Cross-platform architecture. Linux later.

Реализован запуск стандартного Windows OpenSSH для сохранённого Windows-компьютера. Основное окно сессии — Windows Terminal; запасное — системный Windows Console Host. Реализации SSH protocol, передачи команд, паролей или терминального renderer нет.

## Что видит пользователь

В USER DATA настроенный SSH со статусом «Готов» включает кнопку **Терминал** на карточке и **SSH-терминал** на странице компьютера. Unknown/checking/unavailable блокируют действие; при отключённом SSH кнопки нет.

Нажатие показывает **Подключение…**. Пока идёт fresh check/launch, повторные действия этого компьютера заблокированы в обоих представлениях. RDP-кнопка тоже блокируется; переключение источника данных недоступно до окончания пользовательской launch operation.

После spawn консольного хоста показывается **SSH-терминал открыт**; интерфейс сразу разблокируется, не ожидая завершения сессии. Этот результат не означает «Подключено», успешный host key check или авторизацию. OpenSSH может затем показать свою ошибку в консоли.

Если fresh SSH больше не отвечает, консоль не запускается и показывается **SSH сейчас недоступен**. Missing OpenSSH, отсутствие доступного консольного хоста, ошибка spawn, некорректный ID/config и неподдерживаемая платформа возвращаются понятными controlled results. После успеха/ошибки pending guard очищается.

Дизайн этапа 2 сохранён. Persistent CRUD, storage schema/migrations, начальные/ручные проверки, refresh/cancel, отсутствие polling, local → remote fallback и RDP этапа 5 сохранены. WoL пользователя остаётся без отправки пакетов.

## Узкие контракты и main orchestration

Добавлен один API:

```ts
openSshTerminal(computerId: string): Promise<IpcResult<SshTerminalLaunchResult>>;
```

Success: `{ computerId, state: 'terminal-opened', ssh: ServiceCheckResult }`. Это информация о запуске хоста и свежей TCP-проверке, без credentials и содержимого сессии.

Renderer передаёт только UUID. Host, username, port, executable, arguments и command не входят в этот IPC. Дополнительные arguments отвергаются. Нет `runCommand`, `launchProcess`, `sshCommand` или универсального execution API.

`registerSshHandlers` использует существующий sender guard: identity главного webContents, identity mainFrame, точный разрешённый URL и незакрытое окно. `sshRequest.ts` отделяет pure typed result mapping от Electron registration, аналогично RDP.

`SshTerminalService.open` выполняет:

1. UUID validation и защиту от уже активной launch operation этого компьютера.
2. ComputerStore.get: загрузку и повторную проверку сохранённого файла. Затем отдельную полную shared validation записи.
3. Проверку Windows remote OS, `sshEnabled` и обязательного username. Допустимы согласованные `user`, `DOMAIN\user`, `user@domain`; реальную возможность входа определяет сервер.
4. Проверку наличия host provider. На Linux/unsupported host возвращается **SSH-терминал доступен только в Windows**, без fresh network/process launch. Linux provider не реализован.
5. Fresh SSH TCP22 через существующие `CheckCoordinator.checkSsh` и `NetworkService.checkSsh`. Это тот же TcpProbe, timeout **2000 мс на попытку**, fixed service port и fallback, что этап 4; отдельной TCP implementation нет.
6. Выбор localAddress при успешной первой попытке. При неудаче — проверку отличного сохранённого remoteAddress. При обеих неудачах native provider не вызывается. RDP при SSH launch не проверяется.
7. Повторное чтение и сравнение конфигурации со snapshot после проверки. Изменение/удаление/abort запрещают запуск по устаревшим данным. Result service/port/address дополнительно сверяются с SSH/22/валидированным snapshot.
8. Повторную username validation перед передачей target в provider. Windows provider также валидирует host/username/port.
9. Вызов `SshProvider.open` с validated host, сохранённым username, фиксированным портом и AbortSignal.

Fresh checks используют общий global pool **8 компьютеров**. Launch не отменяет UI refresh; cancel refresh отменяет status checks. CRUD и закрытие приложения отменяют незавершённые launch checks. После успешного spawn уже открытая сессия самостоятельна.

Composition root передаёт RDP и SSH одну pending Map по computerId: одна активная клиентская launch operation на ID, включая одновременные обращения к разным IPC. Существующий RDP guard сохранён; добавлена общая зависимость без переписывания RDP orchestration. UI и main защищают double click независимо.

## Windows provider и discovery

Новые Windows-only файлы:

- `main/providers/windows/WindowsSshProvider.ts` — interactive target → host arguments → safe spawn.
- `main/providers/windows/windowsSshDiscovery.ts` — доверенные фиксированные места поиска.

Composition root создаёт `WindowsSshProvider` только при Windows host. RDP provider остаётся подключённым; WoL slot равен null. UI/shared не импортируют Windows launch/path logic, child_process или native providers.

Provider фиксирует host, username, port и signal до асинхронного discovery: изменение переданного объекта во время ожидания не меняет проверенную цель запуска.

### OpenSSH Client

Используется только `%SystemRoot%\System32\OpenSSH\ssh.exe`. Root должен быть абсолютным Windows directory с буквой диска, без traversal/недопустимых символов; `/` запрещён, разделитель — `\`. `%` и `;` также исключены, поскольку conhost выполняет environment expansion, а wt использует semicolon delimiter. Проверяется обычный файл; missing/inaccessible client даёт **OpenSSH Client не найден**.

Нет поиска по произвольному PATH, загрузки PuTTY, custom executable field или скрытой установки. Нештатный OpenSSH из другой папки на этом этапе не поддерживается; установите стандартный Windows компонент вручную.

### Windows Terminal

Проверяется штатный App Execution Alias `%LOCALAPPDATA%\Microsoft\WindowsApps\wt.exe`. LOCALAPPDATA валидируется как абсолютный directory; alias проверяется `lstat`, без разрешения reparse target через PATH. Alias может быть недоступен при отсутствующем Terminal или отключённом execution alias.

Используется отдельное окно через `-w -1 new-tab`, с переданным абсолютным SSH executable. Профильный shell не подставляется, `--appendCommandLine` не используется. Node передаёт executable/arguments отдельно, Windows/Terminal выполняют штатное quoting.

```text
wt.exe
  -w -1 new-tab --
  <absolute-system-ssh.exe>
  -l <validated-username> -p 22 -- <validated-host>
```

Это запись структуры arguments для документации, не shell string в коде.

### Fallback: системный Console Host

Если Terminal alias отсутствует, проверяется `%SystemRoot%\System32\conhost.exe` и запускается напрямую:

```text
conhost.exe
  -- <absolute-system-ssh.exe>
  -l <validated-username> -p 22 -- <validated-host>
```

Console Host выбран вместо PowerShell/cmd: здесь не нужен shell, скрипт или `-Command`/`/c`. Conhost создаёт собственные input/output/error console handles для дочернего SSH. Поэтому игнорирование stdio **родительского console host** в Node не превращает SSH в скрытую сессию с output в NUL: client I/O подключается к консоли хостом. Этот путь требует настоящего Windows smoke test на целевых версиях.

Если нет ни Terminal alias, ни Console Host — controlled `SSH_HOST_MISSING`. Если найденный host не может быть spawned, возвращается `SSH_LAUNCH_ERROR`; приложение не запускает второе окно после неопределённой ошибки. Broken alias можно исправить вручную или отключить, чтобы использовать fallback; NEXUS системные настройки не меняет.

## Safe launch и lifetime

Оба варианта вызывают только `spawn(executable, args, { shell:false, detached:true, stdio:'ignore', windowsHide:false })`. Нет exec, cmd, PowerShell, пользовательской shell string, unsafe Windows quoting или `windowsVerbatimArguments:true`.

SSH args всегда:

```ts
['-l', validatedUsername, '-p', '22', '--', validatedHost]
```

Username передаётся отдельным аргументом: UPN `user@domain` не смешивается с separator `user@host`. `--` заканчивает SSH options. Host — последний аргумент; remote command после него отсутствует. User values не могут создать WT command separator, SSH option или shell token.

Provider проверяет cancellation до/после discovery. Launch Promise разрешается на **spawn**, вызывает child.unref и не ждёт session exit. Error event и синхронный spawn throw дают controlled SSH error; поздний error обработан listener и не падает как unhandled event. Нет pipes, чтения output, ожидания всей сессии, session kill при выходе NEXUS или собственного process manager.

Успех подтверждает только запуск консольного хоста. NEXUS не проверяет дальнейший запуск SSH внутри WT/conhost, authentication или удалённую shell readiness. Это стандартная сессия, открытая пользователем, а не automation.

## Authentication, ключи и пароли

OpenSSH самостоятельно показывает fingerprint/host-key confirmation, password prompt и remote shell. Приложение не подтверждает host key автоматически и не передаёт `StrictHostKeyChecking=no` или другие обходы.

Уже настроенные SSH keys, known_hosts, agent и user SSH config используются стандартным клиентом штатно. NEXUS не читает key files, не управляет keys/known_hosts, не очищает предупреждения и не хранит пароль.

Нет password field, credentials JSON, secret env, автоматического ввода или содержимого SSH-сессии в журнале приложения. NEXUS не перехватывает terminal input/output и не логирует команды. При закрытии консоли сессия управляется обычным OpenSSH/Windows host.

## Demo и UI

`performComputerAction` сначала выбирает demo ветку, затем только для USER DATA маршрутизирует RDP/SSH по ID. Демо SSH остаётся прежним toast **SSH-терминал · демо**; user IPC, provider и TCP не вызываются. User wake ветка не запускает ничего.

`useSshTerminal` следит за pending IDs и notify results. Карточка/страница показывают одинаковый busy state; пока открыт один launch, оба клиентских действия этого компьютера disabled. После ACK success/error блокировка снимается. Общие модели Computer/ConnectionCheckResult не дублировались.

Config schemaVersion остаётся **1**. Нет новых полей в Computer, миграции/CRUD не изменены. Runtime статусы и launch data не записываются в electron-store; demo не записывается в user file.

## Проверки этапа

| Проверка | Результат |
| --- | --- |
| Typecheck | main/preload/shared, renderer и tests: успешно |
| Unit tests | **71/71**: 50 прежних и 21 SSH |
| Production build | main, sandbox preload, renderer: успешно |
| Electron SSH QA | **10/10** групп |
| Stage5 RDP regression | **10/10** групп |
| Stage4 network regression | **12/12** групп |
| Stage3 CRUD/persistence regression | **13/13** групп |
| Итого Electron QA | **45/45** групп |
| Renderer/console | 0 ошибок в SSH/RDP/network QA; renderer 0 в CRUD |
| TCP regression payload / remaining sockets | 0 байт / 0 Socket |

Unit coverage:

- SSH disabled, missing username, invalid record, non-Windows remote, unsupported host;
- fresh SSH local ready, remote fallback, обе попытки unavailable и отказ после старого READY;
- system OpenSSH discovery, missing/denied client, alias discovery без PATH, missing Terminal → Console Host, missing hosts;
- правильные отдельные arguments для user/domain/UPN/Unicode username, WT и fallback;
- spawn success/error, detached/shell:false/stdio/unref, late error и lifetime;
- hostile `& | ; " ' $`, newline, spaces, flags, protocol/port suffix;
- duplicate во время check/launch, retry после ошибки, общий RDP/SSH guard;
- edit/delete/abort, cancellation во время discovery, global pool без отмены refresh;
- sender/window/frame/URL, ID-only, forged targets/extra arguments;
- demo isolation и отсутствие remote command API.

Процессы и сеть в unit tests инъецируются; внешнего SSH host, настоящих ssh.exe/Terminal/mstsc в этих тестах нет. Прежние RDP/TCP/storage/validation tests продолжают проходить.

## Electron QA и ограничения Linux

`tests/electron-ssh.cjs` открывает настоящий Electron UI с отдельным test profile через test-only entry `electron-ssh-harness.cjs`, который загружает неизменённый production main. Первый этап QA использует настоящий production IPC/NetworkService: real unavailable SSH, unsupported Linux, validation и rejection второго окна.

Затем harness явно включает **mock phase**: только narrow status/SSH handlers заменяются test-only DI objects, использующими настоящие compiled ComputerStore, CheckCoordinator, NetworkService, SshTerminalService и WindowsSshProvider, с injected TCP outcomes и mock native host launch. Same trusted sender/frame/URL guard сохранён. Renderer не получает harness API; production source не содержит test flag/backdoor или provider override.

Это необходимо для SSH READY/busy/fallback UI, потому что sandbox контейнера запрещает слушать порт 22. Tests наблюдают только собственные loopback записи `127.0.0.1`/`127.0.0.2`, без внешних устройств. Это не успешное подключение к Windows OpenSSH и не proof настоящей интерактивности.

В Electron проверены enabled/disabled SSH, busy и запрет обоих клиентских действий, duplicate IPC, fresh local/fallback, mock WT/conhost arguments, fresh unavailable, spawn error/retry, corrupt storage без writes, demo без user calls/probes, detail page, 1280×720 и 760×600, keyboard dialogs и secure bridge. Список bridge содержит ровно 10 разрешённых методов, без Node/IPCRenderer/command execution.

Stage3/4 regression scripts запускают обычный production entry. Проверены full restart persistence, edit/delete и empty state, corrupt/future storage без overwrite, initial/manual/cancel networking, runtime statuses, отсутствие polling, fallback, сохранение demo isolation и sender guard. RDP QA сохраняет Stage5 harness: настоящие loopback TCP3389 проверки и mock mstsc provider; production RDP unsupported path остаётся реальным.

Windows Terminal, Windows OpenSSH, Console Host и mstsc **реально не запускались** в Linux. Wine, Linux SSH замена и Linux provider не добавлялись. Полноценный Windows smoke ещё требуется.

Для root Electron в контейнере использованы виртуальный TCP Xvfb display и QA-only `--no-sandbox`. В обычных npm scripts и source webPreferences защитные настройки остаются прежними: nodeIntegration false, contextIsolation true, sandbox true, webSecurity true. Проверка реального OS sandbox — часть Windows smoke. Windows компоненты, firewall, services, registry, BIOS и адаптеры не менялись.

Машиночитаемые отчёты: [SSH](./stage6/ssh-checks.json), [RDP](./stage6/rdp-checks.json), [network](./stage6/network-checks.json), [CRUD](./stage6/crud-checks.json).

### Скриншоты

Следующие изображения показывают **USER DATA UI в explicit mock phase SSH QA**: сохранённые реальные test records и injected READY statuses/native launch. Они не доказывают настоящий Windows SSH launch. Test-only entry может показывать default Electron app version вместо package version в footer.

![Главный экран с SSH READY: QA mocks](./stage6/main.png)

![Страница компьютера с SSH READY: QA mocks](./stage6/computer.png)

Обычный production entry и real TCP network regression: [главная](./stage6/network-main.png), [страница компьютера](./stage6/network-computer.png). Здесь реальная недоступность SSH в контейнере честно показывается в интерфейсе.

## Повторение проверок

```powershell
npm.cmd ci
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
npm.cmd start
```

Unit runner — стандартный Node.js, дополнительные test deps не нужны. Отдельные Electron QA scripts требуют Playwright или `NEXUS_PLAYWRIGHT_PATH`, доступного display и writable temporary directory. После `npm test` (compiled test modules) и build:

```sh
node tests/electron-ssh.cjs
node tests/electron-rdp.cjs
node tests/electron-network.cjs
node tests/electron-crud.cjs
```

`NEXUS_QA_OUTPUT` задаёт место screenshots/report/test profile. SSH/RDP orchestration QA scripts предназначены для текущего Linux mock/unsupported environment; это не Windows smoke. Network regression поднимает собственный loopback TCP3389 listener и закрывает его; не должен работать одновременно с реальным RDP listener на том же тестовом host. QA profiles не входят в исходный архив.

## Windows smoke — что проверить позже

Перед системными изменениями: установка OpenSSH Client/Server, запуск службы sshd и настройка её startup/firewall — **ваши ручные действия с правами администратора на собственных ПК**. NEXUS их не выполняет. Пошаговая подготовка дана в README и [инструкции Microsoft](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse).

1. На Windows host NEXUS проверить штатный OpenSSH Client; на своём target PC подготовить Server/службу TCP22. Запустить NEXUS обычным build/start без QA sandbox flag.
2. Добавить Windows-компьютер, username, SSH и дождаться READY. Нажать «Терминал»: Windows Terminal должен открыть отдельное окно с SSH к правильному local endpoint.
3. Проверить настоящий интерактивный first host-key confirmation, password prompt, configured SSH keys и remote shell. NEXUS ничего не вводит, не подтверждает и не читает. При изменившемся host key должно сохраняться штатное предупреждение OpenSSH.
4. Проверить подходящую для вашего сервера форму username: user/domain/UPN. Также quoting системных путей, включая путь профиля с пробелами. Сервер может отклонить имя; NEXUS передаёт его без преобразования/обхода authentication.
5. Проверить local недоступен → свой remote/VPN endpoint доступен: SSH должен получить именно remote address. Для обеих недоступных попыток host не открывается.
6. Между READY и кликом сделать свой SSH endpoint недоступным: fresh check должен остановить launch. После восстановления обновить и повторить.
7. Для fallback проверить Windows без Terminal или с alias, отключённым вручную: должна открыться обычная интерактивная консоль с видимыми input/output/password/host-key prompts. Проверить Windows 10/11 отдельно. Не удалять системные executable ради теста.
8. Быстрые клики во время launch не создают несколько окон; RDP/SSH этого же ID блокируются до завершения. После success/error снова доступны.
9. После открытия сессии закрыть NEXUS: терминал/SSH должен остаться. После restart карточка и USER DATA восстанавливаются, runtime checks пересчитываются.
10. Проверить RDP как прежде; DEMO RDP/SSH даёт только demo notification; user WoL не отправляет пакеты. Проверить real OS sandbox и отсутствие startup errors на Windows.

Проверенные первичные основы: [Windows Terminal CLI и alias](https://learn.microsoft.com/en-us/windows/terminal/command-line-arguments), [Windows OpenSSH](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse), Microsoft Console Host source [arguments](https://github.com/microsoft/terminal/blob/main/src/host/ConsoleArguments.cpp) и [console client handles](https://github.com/microsoft/Terminal/blob/main/src/server/Entrypoints.cpp), [Node child_process](https://nodejs.org/api/child_process.html).

**После этапа 6 работа остановлена. Wake-on-LAN — только после отдельного подтверждения пользователя.**
