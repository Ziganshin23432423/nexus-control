# Этап 1 — состояние проекта

Дата проверки: 1 октября 2026 года.

## Реализовано

- Electron + React + TypeScript + Vite через electron-vite.
- Разделение main, preload, renderer и shared.
- Окно с названием NEXUS CONTROL, русским слоганом и индикатором готовности.
- Типизированный метод `getAppInfo` в contextBridge; проверка отправителя в main.
- Изоляция renderer, sandbox в BrowserWindow, строгая CSP для production.
- Локальный production-протокол с проверкой адреса и пути к файлам.
- Запрет внешних переходов, новых окон, webview и разрешений.
- Development с HMR React и перезапуском main/preload.
- Отдельные TypeScript-конфигурации для Node/Electron и renderer.
- Автоматическая установка бинарника Electron после `npm ci`, необходимая для совместимости Electron 44 с electron-vite 5.
- Закреплённые версии зависимостей, package-lock.json, README.md и AGENTS.md.

## Проверено

| Проверка | Результат |
| --- | --- |
| Чистая установка `npm ci` | Успешно, включая бинарник Electron |
| `npm run typecheck` | Без ошибок в обеих частях проекта |
| `npm run build` | Собраны main, preload и renderer |
| Реальный Electron с production-кодом | Окно открылось по `nexus://app/index.html` |
| Development через `npm run dev` | Окно открылось через локальный Vite |
| `getAppInfo` из реального renderer | Вернул NEXUS CONTROL, версию 0.1.0 и правильный режим |
| Список методов моста | Только `getAppInfo` |
| `require`, `process`, `Buffer`, raw IPC в renderer | Недоступны |
| Настройки окна | Node integration отключён; context isolation, sandbox и web security включены |
| JavaScript-ошибки production renderer | Отсутствуют |
| Внешний вид production-окна | Проверен по реальному скриншоту |

## Граница проверки

Окружение: Ubuntu 24.04, Node.js 24.19.0, npm 11.9.0. Windows 10/11 здесь отсутствуют, поэтому запуск именно на Windows ещё не проверен.

Для проверки окна использован виртуальный X-дисплей через TCP. В тестовом Linux-контейнере от root использован флаг `--no-sandbox`; проверка OS sandbox на целевой Windows-платформе остаётся открытой. Флаг не включён в исходники или обычные npm-команды проекта.

Интеграционные проверки выполнялись внешним тестовым скриптом через Playwright. Unit tests и lint запланированы на отдельные согласованные этапы; команд `test` / `lint` пока нет.

## Продолжение

После этапа 1 внесено уточнение платформ: Windows-first с общей архитектурой и будущей поддержкой Linux. Добавлены модель `Computer` с `operatingSystem`, контракты провайдеров и platform service для текущих метаданных. Конкретные Windows/Linux-провайдеры не реализованы; этап 2 не начат.

После уточнения typecheck и production build прошли успешно. Записанные выше проверки окна и скриншот относятся к первоначальному фундаменту этапа 1. Повторная проверка запуска и Linux-функциональности в это уточнение не входит.

Следующий этап после запроса пользователя — **этап 2**: главная страница, карточки, empty state и demo-компьютеры без реальных сетевых действий.

RDP, SSH, Wake-on-LAN, хранение конфигурации и Windows installer ещё не реализованы. Не переходить к ним раньше соответствующих этапов.

Для проверки на Windows: открыть папку проекта, выполнить `npm.cmd ci`, `npm.cmd run dev`, затем `npm.cmd run build` и `npm.cmd start`. После загрузки окна внизу должна появиться надпись «Приложение готово».
