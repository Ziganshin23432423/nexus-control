# Этап 3 — постоянные компьютеры и CRUD

Этап завершён 1 октября 2026 года. Сохранены дизайн этапа 2 и Windows-first / cross-platform границы этапов 1–2. Реальное networking всё ещё не реализовано; имитация остаётся только в отдельном демо-режиме.

## Что изменилось

- По умолчанию открывается **Мои компьютеры**, при первом запуске — empty state. Демо выбирается явно в нижней панели.
- Добавление и редактирование проходят общую проверку renderer/main. Main назначает UUID и ISO timestamps; update сохраняет ID и createdAt.
- Удаление требует подтверждения с именем выбранного компьютера. Удаляется локальная запись, без воздействия на удалённое устройство.
- UI меняет пользовательский список после успешной записи main. Сохранение блокирует повторные действия; ошибка оставляет форму и введённые значения открытыми.
- electron-store 11.0.2 подключён только в main. Паролей, computed statuses и demo fixtures в файле нет.
- Пользовательский компьютер имеет статус **Не проверен**, настроенный WoL — **Настроен**. Эти состояния не означают готовность сети. RDP/SSH и питание не выполняются.
- Демо использует тот же `Computer`, но отдельный in-memory controller. Создание, редактирование, удаление, таймеры и mock actions не обращаются к storage IPC. Переключение источника сбрасывает демо, полный restart снова открывает user data.

## Хранение и миграции

`src/main/services/computerStore.ts` содержит общий сервис CRUD с injected `ConfigurationRepository`. Production adapter `electronStoreRepository.ts` лениво открывает `computers.json` в `app.getPath('userData')`. Все операции выполняются синхронно в main; запись electron-store атомарная. Лимит — 1000 записей.

```json
{
  "configuration": {
    "schemaVersion": 1,
    "computers": []
  }
}
```

`storageSchema.ts` проверяет сырой JSON root до преобразований библиотеки, envelope, каждую запись, ID, даты и уникальность ID. `migrateConfiguration` — явная точка входа последовательных миграций; registry пока пуст, поскольку схема 1 — первый постоянный формат. Формат этапа 2 мигрировать не требуется: он не сохранялся. Будущие transforms добавляются по номерам схем, без привязки к версии приложения.

`clearInvalidConfig: false`. Повреждённый JSON, массив/null вместо root, отсутствующий envelope, некорректная запись или будущая schemaVersion вызывают понятную ошибку. Исходные байты не очищаются и не заменяются пустым списком. Экран ошибки позволяет повторить загрузку после исправления файла или перейти в демо. Это не автоматическое восстановление или backup.

## IPC и validation

Мост предоставляет пять методов: `getAppInfo`, `listComputers`, `createComputer`, `updateComputer`, `deleteComputer`. CRUD использует discriminated `IpcResult`: данные либо код и понятное сообщение об ошибке; ошибки полей возвращаются как `ValidationErrors`.

Каждый handler проверяет главное окно, основной frame и точный renderer URL, затем входные значения типа `unknown`. Проверка TypeScript не заменяет runtime validation. Renderer не получает `ipcRenderer`, fs, electron-store, Node.js API или системные providers.

`shared/validation.ts` проверяет IPv4, DNS hostname, адрес, MAC, username, port и полную конфигурацию. Неоднозначные IPv4 с ведущими нулями и некорректные числовые адреса отвергаются. Поддерживаются MAC с двоеточиями/дефисами, local username, DOMAIN\user и user@domain. SSH требует username; WoL требует MAC, broadcast IPv4 и порт 1–65535. Название ограничено 64 символами, notes — 2000. Linux в форме остаётся недоступным.

Неизвестные поля, включая password, ID и timestamps в draft, отвергаются. Saved records тоже проходят строгую проверку. Статусы не сохраняются. Не добавлены универсальные команды или command execution.

## Последовательность и результаты

Выполнено: **typecheck → tests → production build → реальные Electron CRUD/persistence checks → этот документ**.

| Проверка | Результат |
| --- | --- |
| `npm run typecheck` — main/preload/shared, renderer, tests | Пройдено |
| `npm test` — Node.js test runner | 15/15, ошибок нет |
| `npm run build` — main ESM, sandbox-compatible preload CJS, renderer | Пройдено |
| `tests/electron-crud.cjs` — настоящий Electron, отдельный профиль | 13/13 групп |
| Ошибки JavaScript renderer | 0 |
| Layout 1280×720 и 760×600, Escape для формы | Пройдено |

Unit-тесты покрывают адреса и command characters, MAC normalization/validation, port/username, draft/stored validation, неизвестные поля и metadata, envelope/version/duplicates, migrations entry point, CRUD с новым экземпляром сервиса, отсутствие записи при invalid input и corrupt storage, write failure, независимость возвращённых объектов, clock reversal и лимит записей. Tests используют memory repository; реальные файловые roundtrips проверяются отдельно в Electron.

В Electron проверены:

1. Первый user launch без демо-фикстур в файле.
2. Ошибка формы при неверном IP и успешная нормализованная запись.
3. Edit с сохранением ID/createdAt; отключённые кнопки user connections.
4. Полное закрытие и запуск нового Electron с восстановлением записей.
5. Прямой вызов preload с forged metadata, password, unsafe address и demo ID: отказ main, файл без изменений.
6. Ошибка storage при сохранении: форма остаётся открытой, успех не показан.
7. Demo add/edit/delete и отмена mock wake: пользовательский файл неизменен.
8. Delete cancel/confirm и сохранение результата после полного restart.
9. Узкий мост, отсутствие Node API и browser storage, защитные BrowserWindow preferences.
10. Запрос CRUD из другого окна с тем же URL/preload: отказ проверки отправителя.
11. Corrupt JSON, `[]`, `null`, `{}` и future version: ошибка без перезаписи; восстановление через retry.
12. Удаление последнего компьютера и пустой список после restart.
13. Размеры desktop-окна и keyboard dismissal.

Машиночитаемый отчёт: [stage3/checks.json](./stage3/checks.json). Проверки используют только выделенный тестовый профиль, не пользовательскую конфигурацию.

## Как повторить

Обычные проверки и запуск на Windows:

```powershell
npm.cmd ci
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
npm.cmd start
```

В **Мои компьютеры** добавьте PC HOME с адресом 192.168.1.25, закройте окно и снова выполните `npm.cmd start`. Откройте карточку, отредактируйте, проверьте повторный запуск и удаление. Для проверки демо выберите его в нижней панели, измените записи и вернитесь в пользовательский список.

Дополнительный `tests/electron-crud.cjs` требует отдельной установки Playwright; он не нужен для обычного development, unit tests или build. Если Playwright доступен для Node, запуск: `node tests/electron-crud.cjs`. Для установки вне проекта можно задать `NEXUS_PLAYWRIGHT_PATH` абсолютным путём к модулю. Скрипт создаёт временный профиль и сохраняет отчёт/скриншоты в временную папку; `NEXUS_QA_OUTPUT` позволяет выбрать место. Production build нужно выполнить непосредственно перед проверкой. Ни настоящий mstsc, ни SSH, ни сетевые пакеты не тестируются.

Фактический QA выполнен в Ubuntu-контейнере с виртуальным Xvfb display, Electron 44.5.1 и Node.js 24.19.0. Из-за запуска от root использован test-only `NEXUS_QA_NO_SANDBOX=1`, добавляющий `--no-sandbox` исключительно тестовому процессу. Код приложения сохраняет `sandbox: true`, `nodeIntegration: false`, `contextIsolation: true`; обычные команды проекта sandbox не отключают. Реальный Windows 10/11 smoke test и OS sandbox на Windows здесь не проверены. Работа общего CRUD на тестовом хосте не является реализацией Linux providers.

## Скриншоты

![Пользовательские компьютеры](./stage3/main.png)

![Страница сохранённого компьютера](./stage3/computer.png)

![Подтверждение удаления](./stage3/delete.png)

## Граница этапа

Не реализованы TCP checks, RDP/SSH, Windows Terminal execution, WoL networking, remoteAddress routing, Credential Manager, PowerShell/remote execution, scheduler и Linux providers. README обновлён; сведения этапов 1–2 сохранены как история.

Этап 3 завершён. Этап 4 требует отдельного подтверждения пользователя.
