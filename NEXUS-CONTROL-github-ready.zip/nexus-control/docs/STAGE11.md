# Stage 11 — Final Visual / Typography / Motion Polish

Технический Stage11 и дополнительный Visual Direction Correction проверены 2 октября 2026. Визуальная версия подготовлена для оценки пользователя. Stage12 не начат.

## Результат

NEXUS сохраняет Windows-first архитектуру и все Stage1–10 возможности. Stage11 меняет renderer: единые tokens и typography, cards/forms/dialogs/toasts/header/footer, компактный professional Guide, Canvas 2D starfield, NEXUS Motion System и Appearance dialog. Новых remote-management действий, privileged IPC, password fields, dependencies или installer нет.

Рабочий checkpoint предыдущей попытки найден: сохранились appearance modules, tokens и 19 unit-тестов. App wiring и часть CSS откатились к Stage10; восстановлена только эта недостающая часть. Реализованные appearance/preferences/engine не заменены новой архитектурой. Принятый Stage10 использован для сверки; конечный deliverable — **NEXUS-CONTROL-stage11.zip**.

## Восемь passes

| Pass | Выполненная работа / доказательство |
| --- | --- |
| 1 · Audit | Просмотрены реальные Stage10 screenshots main/detail/delete/Guide. Найдены мелкие labels/captions, лишний letter spacing, отдельная строка help icons, большой marketing headline Guide и случайные размеры controls. [Main до](./stage11/before-main-stage10.png), [Guide до](./stage11/before-guide-stage10.png). |
| 2 · System | `tokens.css`: palette, surfaces, borders, text/accent/status, font/weight/leading, spacing, radii/shadows, density и durations/easing. Обновлены type hierarchy и controls. |
| 3 · Motion | Восстановлены Canvas driver/App integration для сохранённого pure StarfieldEngine; effects, settings, local validation/persistence и reduced-motion. |
| 4 · Screens | Main/empty/detail, all existing action states, form/delete/context Guide dialog, search/reference/checklist, toast/fallback, header/footer. |
| 5 · Review | Electron действительно открыт, выполнены screenshots всех required families и первая matrix. Images просмотрены вручную; составлен issue list ниже. |
| 6 · Second polish | Исправлены form/footer collision, порядок service help, избыточный card whitespace, длинные actions в маленьком окне, alignment/footer, notice/error palette, toast spacing и denied-storage wording. Выполнены повторные screenshots и review refinements. |
| 7 · Combinations | Все **6 combinations × 4 sizes × 5 views = 120** layouts. Modes/density, pointer, RAF/listeners/observer, reduced-motion, persistence/restart, keyboard и ошибки хранения проверены. |
| 8 · Regression | Полная последовательность typecheck → tests → build → appearance → Guide → UX → orchestration → WoL → SSH → RDP → network → CRUD. Все успешно. |

Это несколько последовательных screenshot/review/fix passes, а не только первая визуальная версия. Baseline screenshots имеют другие fixtures/viewport; они нужны для оценки hierarchy/style, не pixel-perfect сравнения.

## Найденные и исправленные visual issues

| Issue после первого screenshot pass | Исправление и повторная проверка |
| --- | --- |
| Form capabilities рисовались поверх footer | Disabled native fieldset сохранён внутри отдельной scroll surface; header/footer вне scroll geometry. Добавлен assert `body.bottom ≤ footer.top`. Validation/add/edit/contextual help и small window перепроверены. |
| Help icon выглядел как отдельная строка/стоял перед названием службы | Explicit grid coordinates: service label + inline help, status на второй строке. Pointer access и contextual navigation сохранены. |
| MAIN PC имел большой пустой промежуток между службами и primary actions | Actions следуют за services; footer baseline выровнен. Offline combined actions grouped в две колонки; сохранены все исходные buttons/capabilities. |
| Длинные wake/SSH labels при 760×600 занимали три строки | Более широкая правая action column; direct actions — компактная пара, combined — полная ширина. Все controls остаются видимыми через штатный scroll. |
| Разные action counts делали footer alignment случайным | Rows stretch, footer margin распределяет остаток; нет искусственного fixed min-height для каждой action area. |
| Отмена проверки выглядела как красная ошибка | Informational `role=status` notice нейтральный; настоящие error/danger остаются красными. |
| Toast retry и guide link стояли вплотную | Добавлен единый spacing; retry/navigation semantics и лимит три не менялись. |
| При denied appearance storage caption обещал сохранение | Caption честно сообщает действие preview до перезапуска. Проверено реальным renderer storage exception в test-only instrumentation. |
| Marketing Guide header доминировал над reference/search | «Справочник и диагностика», полноширинный search, компактный Quick Start и reference tiles. 59 articles/search/data model не изменены. |

## Design system и typography

Сохранены graphite/deep navy, холодный blue accent, тонкие borders и SVG system. Primary accent используется для действий/focus/active nav; green — ready, amber — checking/waiting, red — настоящая ошибка. Surfaces достаточно непрозрачны, чтобы background не мешал тексту. Нет фотографий, planets, RGB/glow, fake code или gaming HUD.

Основной stack: **Segoe UI Variable Text → Segoe UI → system-ui → sans-serif**. Сохранено принятое решение без Inter/npm font installation. Technical IP/MAC/hostname/commands используют Cascadia Mono / Consolas / monospace. Обычный UI не mono.

Scale: captions 11–12, labels/buttons 12–13, body 14, section 16–18, card 18–22, modal 22, page 26–30 px по context. Weights 400/500/600/700, UI leading 1.45, body 1.65. Основной heading sentence case; uppercase остаётся в коротких micro-labels. Normal controls 40 px, Compact 34 px; compact меняет gaps/padding/layout, **без CSS zoom**. Вторичные OS-future notes могут быть 10 px, основной текст не уменьшается до 9 px.

Motion tokens: Full micro/control/surface/page **120/160/210/260 ms**, Calm **110/150/180/220 ms**, Minimal **70/90/100/100 ms**. Page shift 10/5/0 px; ease-out без spring/bounce. Guide opening — fade + небольшое движение content; keyed article/category/search state transitions. Native dialog/backdrop, hover/press/focus, toast и loading indicators используют общую систему. Минимальные modal transitions — fade. При системном reduced-motion CSS animations/transitions отключены.

## Background architecture

`renderer/appearance` отделён от model/store/providers:

- `preferences.ts` — typed modes, strict validation/storage adapter и motion profiles.
- `AppearanceProvider.tsx` — user preferences + effective mode + system media query, DOM tokens.
- `AppearanceDialog.tsx` — компактный native dialog: 3 effects, 2 density, reset. Без themes/scale/sliders.
- `starfieldEngine.ts` — deterministic stars и pure lifecycle engine с injected host/surface.
- `Starfield.tsx` — Canvas 2D driver, passive pointer, visibility, ResizeObserver/resize cleanup.

Stars: **70–220 по площади**, far/mid/near примерно 66/27/7%; radius <1.1 CSS px. DPR ограничен **1.5**. Palette/grid берутся из tokens. Нет WebGL/Three.js, image assets, сотен React nodes или runtime network.

| Mode | Parallax far / mid / near | Drift / twinkle | Rendering |
| --- | --- | --- | --- |
| Полные | 4 / 11 / 22 px | очень медленный / ±10% | Один owned RAF, paint ceiling 30 FPS |
| Спокойные | 0.6 / 1.5 / 2.5 px | 22% от Full / ±2.5% | Один owned RAF, paint ceiling 20 FPS |
| Минимальные | 0 / 0 / 0 | отсутствуют | Static draw при mount/resize; **0 continuous RAF**, нет pointer listener |

Normalized pointer ограничен [-1,1], интерполяция ~180 ms; positive offset двигает слой **в сторону курсора**. Drift/twinkle медленные, без flashes/streaks. Background внутри app, декоративный `aria-hidden`, без hit testing. UI всегда впереди.

Engine использует plain fields, не React state на pointer/frame. Hidden отменяет RAF и останавливает накопление active time; resume не даёт большого time jump. Stop отменяет frame, pointer/visibility/resize listeners и observer; queued resize/frame callbacks после stop игнорируются. Mode changes используют тот же effect cleanup, который применяется при unmount. Unit harness непосредственно проверяет stop/queued callbacks и отсутствие post-stop draws.

## Settings / persistence / reduced-motion

Шестерёнка в header → «Внешний вид». Preview немедленный; native keyboard radios, Tab/Shift+Tab, Escape, возврат фокуса; три modes и две densities. Reset удаляет только appearance key и возвращает Full/Normal.

Renderer-only localStorage key **`nexus.appearance.v1`** хранит ровно `{ effects, density }`. Дефолт Full/Normal, lazy read без записи. Unknown/missing/extra/non-string/malformed values → defaults; ошибки read/write/reset не роняют app. Write denial оставляет preview и показывает честную inline ошибку. Reload и **полный Electron restart** подтвердили persistence. `computers.json` побайтно неизменен при appearance действиях; schemaVersion остаётся 1.

System `prefers-reduced-motion: reduce` всегда даёт effective Minimal, даже при выбранном Full. User preference не переписывается; после выключения системного reduce восстанавливается выбранный режим. В settings есть system note. Windows settings приложение не меняет.

## Финальные результаты

| Проверка в обязательном порядке | Результат |
| --- | --- |
| npm run typecheck | PASS |
| npm test | **187/187 PASS**, 19 appearance/engine + 3 Windows filename regression tests сверх 165 Stage10 |
| npm run build | PASS |
| Stage11 appearance Electron QA | **17 групп PASS**, **120 matrix views PASS** |
| Stage10 Guide regression | 14 PASS |
| Stage9 UX regression | 22 PASS |
| Stage8 orchestration regression | 13 PASS |
| Stage7 WoL regression | 11 PASS |
| Stage6 SSH regression | 10 PASS |
| Stage5 RDP regression | 10 PASS |
| Stage4 network regression | 12 PASS |
| Stage3 CRUD/persistence regression | 13 PASS |
| Всего Electron QA groups | **122 PASS** |

120 layouts — отдельные проверки внутри appearance matrix group; они не прибавлены к числу 122 групп. JSON содержит каждую combination/view/size и layout metrics, а не brittle pixel-perfect assertions.

[Typecheck](./stage11/typecheck.log), [unit tests](./stage11/tests.log), [build](./stage11/build.log), [appearance](./stage11/appearance-checks.json), [Guide](./stage11/guide-checks.json), [UX](./stage11/ux-checks.json), [orchestration](./stage11/orchestration-checks.json), [WoL](./stage11/wol-checks.json), [SSH](./stage11/ssh-checks.json), [RDP](./stage11/rdp-checks.json), [network](./stage11/network-checks.json), [CRUD](./stage11/crud-checks.json).

RendererErrors пусты во всех reports; consoleErrors пусты в appearance/Guide/UX и instrumented network/provider suites. CRUD отдельно фиксирует rendererErrors. Activity/resources checks подтверждают отсутствие оставшихся active probes/sockets/timers/slots/claims. Appearance instrumentation находится только в tests; production не имеет QA overrides.

### Performance smoke

Из финального Electron report, во время 12 pointer moves и idle pause:

| Mode | Sample duration | Canvas draws | RAF callbacks | UI DOM mutations от pointer |
| --- | --- | --- | --- | --- |
| Full | 949 ms | 21 | 57 | 0 |
| Calm | 941 ms | 18 | 57 | 0 |
| Minimal | 936 ms | 0 | 0 | 0 |

Один pending RAF максимум; Full/Calm по одному pointer/visibility listener и observer. После mode churn → Minimal: RAF 0, pointer 0, observer 1 для resize. Reduced-motion также RAF 0, no continuous draws. Это bounded smoke measurement на данном renderer, **не CPU/GPU benchmark и не обещание одинакового FPS на любой машине**. UI clicks/search/scroll/keyboard оставались responsive в matrix/regression QA. Отсутствие DOM mutations дополняет source/unit доказательство отсутствия React setState в pointer path; это не React Profiler measurement.

### Visibility limitation

В Linux/Xvfb без window manager `BrowserWindow.hide()` действительно скрывает native window, но не публикует renderer `document.hidden`. Поэтому QA явно записал fallback **test-only `document.hidden` override + visibilitychange**. Он проверяет production listener/engine pause/resume без изменения production source. Pure engine unit-тест отдельно проверяет hidden/stop/queued callbacks. Native Windows minimize/hide lifecycle остаётся пунктом smoke-check, а не объявляется проверенным физически.

## Security и scope

[Audit](./stage11/security-audit.json): **48 protected files byte-identical** принятому Stage10 — main, preload, shared, package/lock, electron-vite config и ROADMAP. **15 Guide data/catalog/search/metadata files** unchanged. Новых bridge methods нет: прежние 15, ID-only actions и sender guard сохранены.

nodeIntegration=false, contextIsolation=true, sandbox=true, webSecurity=true, CSP/local protocol, navigation/permission restrictions не менялись. Appearance не импортирует Node/window.nexus/providers. Computer/schema/migrations/validation/NetworkService/CheckCoordinator/native providers/fixed workflows сохраняются. Linux providers, arbitrary execution/shell/PowerShell, scheduler, Automations, secrets, installer/updater не добавлены.

Состав исходных actions, explicit retry, no auto retry, three-toast limit, main countdown/90-second deadline и truthful client-opened/Magic Packet sent ACK не менялись. Form refactor сохраняет native disabled fieldset и прежнюю validation. Guide копирует только прежний static text; новых execution buttons нет. Guide QA подтвердил отсутствие дополнительных probes/UDP/native launches/operational IPC от информационной навигации.

## Screenshot matrix

Все **Full/Calm/Minimal × Normal/Compact × 1440×900 / 1280×720 / 1024×700 / 760×600** проверены на main/detail/Guide/settings/form. Все 120 views реально проверены и captured. В архив включены 26 representative matrix screenshots: main для 12 combinations в 1280×720 и 760×600, settings/form при 760×600 для всех 6 combinations, плюс Calm/Minimal settings в 1280×720. Полный перечень 120 layouts и metrics находится в appearance-checks.json. Profiles/cache не включены.

Представительные финальные captures:

- Main: [empty USER DATA](./stage11/main-empty.png), [2 demo computers](./stage11/main-two.png), [6 USER records](./stage11/main-six.png), [compact](./stage11/main-compact.png), [checking](./stage11/main-checking.png), [waiting/countdown](./stage11/main-waiting.png).
- Detail: [online demo](./stage11/detail-online.png), [offline demo](./stage11/detail-offline.png), [active workflow](./stage11/detail-workflow.png), [launching](./stage11/detail-launching.png).
- Forms/dialogs: [add](./stage11/form-add.png), [edit](./stage11/form-edit.png), [validation](./stage11/form-validation.png), [context Guide](./stage11/form-context-guide.png), [delete](./stage11/dialog-delete.png), [small Compact](./stage11/matrix-minimal-compact-760x600-form.png).
- Guide: [home](./stage11/guide-home.png), [search](./stage11/guide-search.png), [article](./stage11/guide-article.png), [Quick Start](./stage11/guide-quick-start.png), [760×600](./stage11/guide-small.png).
- Appearance: [Full](./stage11/settings-full.png), [Calm](./stage11/matrix-calm-normal-1280x720-settings.png), [Minimal](./stage11/matrix-minimal-normal-1280x720-settings.png), [Compact 760×600](./stage11/matrix-minimal-compact-760x600-settings.png), [system reduced-motion](./stage11/settings-reduced-motion.png), [write denied](./stage11/settings-storage-denied.png).
- Feedback: [success toast](./stage11/feedback-success.png), [error/details](./stage11/feedback-error.png), [storage error](./stage11/feedback-storage.png), [ErrorBoundary fallback](./stage11/feedback-fallback.png).

Прокручиваемая часть длинной страницы/формы может находиться ниже fold; это штатный vertical scroll, не clipping control/footer. No horizontal overflow, modal bounds, footer bounds и body/footer collision проверены структурно. Screenshots и после второго pass, и финальные representative images действительно просмотрены.

## Windows visual smoke checklist

После `npm.cmd ci` → `npm.cmd run typecheck` → `npm.cmd test` → `npm.cmd run build` → `npm.cmd start`:

1. На Windows 10 и 11 проверить Segoe UI fallback/Variable Text, веса, Cyrillic wrapping и SVG alignment. Проверить DPI 100/125/150% и второй монитор; Canvas backing size должен оставаться capped.
2. Открыть четыре desktop sizes, обе densities; radio/Tab/Shift+Tab/Escape/focus restoration, add/edit/context Guide/validation/delete/toasts. Все действия доступны через штатный scroll.
3. Full: мягкий parallax к курсору и медленный фон; Calm: заметно меньше движения; Minimal: статичный фон. Никаких flashes/сильного glow/сильного drift; редкий halo stars остаётся сдержанным.
4. Включить системное reduce motion: Full preference сохранён, effective visuals static, системная note видна. Вернуть системную настройку вручную и убедиться, что выбранный mode восстановился.
5. Minimize/hide/show: проверить native visibility pause/resume и отсутствие лишних RAF/listeners в DevTools. Длительный idle, scroll, resize и pointer должны оставаться responsive; проверить на реальном GPU.
6. Appearance после полного restart сохраняется; reset не меняет USER computers. Guide без интернета: все статьи/search/context/Quick Start, без системного действия от ссылки инструкции.
7. Сохранить Stage5–9 hardware smoke: настоящий mstsc/OpenSSH/Windows Terminal login, BIOS/NIC/UDP wake и wake→wait→connect на собственном разрешённом компьютере. Здесь физический PC boot/authentication не проверялся.

Stage11 correction прошёл environment gates и подготовлен для визуальной оценки пользователя. Нативные Windows rendering/visibility/hardware ограничения указаны явно. **Остановлено после Stage11; Stage12 не начат.**


## Visual Direction Correction

### Почему потребовался дополнительный проход

Техническая база Stage11 была принята, визуальное направление — нет. Исходные captures показывали одинаковые плоские navy panels, тяжёлые ряды кнопок, почти исчезающий starfield и Guide с характером документационного web-dashboard. Этот проход исправляет presentation, сохраняя функциональность Stage1–11.

### Изменения

- Фон: Canvas остаётся процедурным. Плотность адаптируется по площади /4400 вместо /6500; cap 220 stars сохранён. В 760×600 — 104 вместо 70. Far/mid/near — примерно 66/27/7%; диапазоны alpha 0.20–0.37 / 0.34–0.51 / 0.53–0.70. Несколько редких near stars имеют слабый halo; radius основных точек по-прежнему <1.1 CSS px. CSS radial haze добавляет пространственную глубину без картинок, nebula или планет.
- Full parallax: amplitudes 4/11/22 CSS px, направление к курсору. Calm и Minimal не изменены. Один RAF, FPS cap, pause/cleanup и reduced-motion сохранены.
- Surfaces: почти чёрный фон, более нейтральный graphite base, raised верхние грани, сдержанные inner highlights/shadows, световой край карточки, более высокий modal layer. Blur применяется к backdrop диалога, не ко всем поверхностям.
- Computer cards: сильнее identity/header, точный компактный status, restrained mono metadata; services спокойнее. Direct RDP/SSH имеют свой ряд, Wake и combined flows облегчены. Возможности, callbacks, порядок и доступность действий не изменены.
- Controls: primary с контролируемым голубым accent, secondary с subtle surface, Wake/tertiary менее тяжёлые; combined flows не конкурируют с подключением. Focus/disabled/keyboard сохраняются.
- Appearance: те же три Effects, две Density и reset. CSS previews показывают глубину и miniature layout, декоративные и aria-hidden; новых settings, images или IPC нет.
- Guide: более короткий search instrument, плотный sidebar/active marker, reference surfaces вместо boxed category cards, Quick Start как справочная строка, mono metadata. Все 59 статей, local search, contextual/error integrations и offline behavior сохранены.
- Header: прежняя высота, NEXUS CONTROL / by network.onion, контролируемый active edge indicator. Segoe UI stack сохранён; optical hierarchy усилена весом, контрастом и rhythm, без новой font dependency.

### Captures: before / after

До изменения сохранены 11 Stage11 captures в before-correction. После изменения выполнены новые captures всех обязательных состояний:

| Экран | До | После |
| --- | --- | --- |
| Main · 6 PCs | [before](./stage11/before-correction/main-six.png) | [after](./stage11/main-six.png) |
| Main · 2 PCs | [before](./stage11/before-correction/main-two.png) | [after](./stage11/main-two.png) |
| Compact | [before](./stage11/before-correction/main-compact.png) | [after](./stage11/main-compact.png) |
| Detail | [before](./stage11/before-correction/detail-online.png) | [after](./stage11/detail-online.png) |
| Guide home | [before](./stage11/before-correction/guide-home.png) | [after](./stage11/guide-home.png) |
| Guide article | [before](./stage11/before-correction/guide-article.png) | [after](./stage11/guide-article.png) |
| Appearance | [before](./stage11/before-correction/settings-full.png) | [after](./stage11/settings-full.png) |
| Add | [before](./stage11/before-correction/form-add.png) | [after](./stage11/form-add.png) |
| Edit | [before](./stage11/before-correction/form-edit.png) | [after](./stage11/form-edit.png) |
| Waiting workflow | [before](./stage11/before-correction/main-waiting.png) | [after](./stage11/main-waiting.png) |
| Error / toast | [before](./stage11/before-correction/feedback-error.png) | [after](./stage11/feedback-error.png) |

### Второй polish pass и итоговый review

После первого capture review обнаружены ещё слишком тяжёлые combined actions в DEMO. Второй pass снизил их вес, уточнил reference rhythm статьи, detail identity и toast actions. Финальные screenshots повторно просмотрены: main 2/6, compact, detail, Guide home/article, settings включая 760×600, add/edit, waiting и error/toast.

Итоговая оценка: композиция узнаваема по глубине цифрового фона, сильному device identity, restrained edge light и справочному rhythm. Фон заметен, основные тексты читаются. Иерархия identity → status/services → direct connection → orchestration видна без изучения каждого параметра. Guide перестал быть набором одинаковых web cards. Нет игровых HUD, RGB, неоновых рамок, artwork или декоративных logo animations. Большой список и маленькие диалоги используют штатный scroll; fixed footer не перекрывает dialog body. Это review разработчика; визуальное принятие остаётся за пользователем.

### Реальное движение и QA

Electron Canvas instrumentation измерила обычное движение мыши (150,200) → (1100,500), settle 650 ms: median far shift **5.69 px**, near shift **31.33 px**. Это фактические Canvas arc positions, не screenshot-only оценка. Near следует курсору и сдвигается существенно сильнее far. Проверка добавлена к существующему QA; все прежние assertions сохранены.

Первый QA attempt остановился на load timeout при restart окна. QA launch теперь ждёт завершения первоначальной navigation и использует 30-second navigation timeout перед reload; assertions функциональности не ослаблены. После прерванного процесса обнаружен stale Xvfb display lock; следующий запуск использовал новый test display. Production launch/security не изменены. Затем appearance QA был повторён успешно и после второго polish заново выполнен весь финальный sequence.

**Финальный sequence:** typecheck → 184/184 unit tests → production build → appearance 17 → Guide 14 → UX 22 → orchestration 13 → WoL 11 → SSH 10 → RDP 10 → network 12 → CRUD 13. Все PASS: **122 Electron groups**, **120 matrix views**. Unexpected renderer/console errors отсутствуют в проверяющих их suites. Все прежние Stage11 unit tests сохранены; изменены только ожидаемая плотность stars и новый допустимый alpha range. Security audit повторён: protected main/preload/shared/package/build/ROADMAP files byte-identical baseline. Guide .ts data/metadata также byte-identical.

Среда Linux/Xvfb не заменяет Windows Segoe UI/GPU/native minimize smoke. Физический Windows RDP/SSH/WoL login/boot не выдаётся за проверенный — QA использует прежние DI/loopback seams. На TCP22 среда запрещает listener bind, что network report явно отмечает; SSH success покрыт injected-probe unit/DI QA. **Stage12 не начат.**


## Brand / Typography / Windows correction

### Stage11C scope

После реального Windows запуска потребовались отдельные brand/typography correction и fix filename resolution. Stage11B starfield, appearance/motion/density architecture не переработаны. Это renderer presentation + однозначное имя engine module; Stage12 не начат.

### Brand, font hierarchy и header

Создан `BrandWordmark`: NEXUS — основной SemiBold/Bold display акцент, CONTROL — спокойнее и меньше, `by network.onion` — тихий body caption. Умеренный tracking 0.15–0.25 px вместо разреженного pseudo sci-fi wordmark. Logo и text lockup объединены alignment/gaps, без увеличения header (68 Normal / 60 Compact).

`NexusMark` теперь открытая геометрия N: две rails, connection и три nodes. Rounded-square container отсутствует. SVG component reusable; отдельный small app mark — `src/renderer/public/nexus-mark.svg`, локальный renderer favicon, bundled production asset. Это не installer/taskbar icon Stage12. [Scale review 16 / 24 / 32 / 48 px](./stage11/logo-scales.png) показывает читаемость минимальной формы. Анимация logo не добавлена.

Font system:

| Роль | Stack / применение |
| --- | --- |
| Brand / display | Bahnschrift → Segoe UI Variable Display → Segoe UI → system-ui → sans-serif. Wordmark, top navigation, page/detail/modal titles. |
| Body | Segoe UI Variable Text → Segoe UI → system-ui → sans-serif. Cards, service labels, forms, Guide/sidebar, secondary texts. |
| Technical values | Cascadia Mono → Consolas → monospace. Hostname/IP/MAC и technical diagnostics. |

Bahnschrift не применяется ко всему body. Typography hierarchy строится на fonts/weights/contrast/spacing; tracking micro-labels уменьшен до 0–0.15 px. Удалены повторяющиеся «NEXUS · УСТРОЙСТВА», «СПРАВОЧНИК · ЛОКАЛЬНО», «Ваши устройства» и брендовые labels empty state. Empty теперь содержит один ясный title, короткое пояснение и Add action. Service labels/status стали читаемее; card identity сохраняет body sans.

Navigation — небольшие display tabs с тихим fading active underline, без стандартной rounded web button surface. Settings и platform имеют согласованные gaps/alignment. Hover/focus сохранены, strong glow не добавлен. Guide layout и 59 статей не изменены; fonts sidebar/search/article/Quick Start приведены к общему языку NEXUS.

### Divider system

Длинные solid header/section lines заменены низкоконтрастными cold-blue gradients с fade по краям. Article divider ограничен длиной; panel borders тише; separation поддерживают luminance/spacing. Native dialog header/footer остаются структурно отделены, scroll geometry и action availability сохранены. Цветовая/фоновая архитектура Stage11B не увеличена эффектами.

### Windows filename bug

`Starfield.tsx` и `starfield.ts` имеют разные расширения, однако один case-insensitive module stem. При extensionless import `Starfield` Windows Vite/esbuild мог выбрать `.ts` engine раньше `.tsx` component и получить `No matching export ... Starfield`.

Engine переименован в **`starfieldEngine.ts`**, React component остаётся **`Starfield.tsx`**. Все imports component/unit tests обновлены. Pure engine contents byte-identical предыдущему Stage11B module; Canvas driver отличается только import path. `preferences.ts` и `AppearanceProvider.tsx` также byte-identical Stage11B. Motion/effects/density/storage semantics не менялись.

Три unit regression checks:

1. Все project paths уникальны при case folding, включая directories; generated/dependency folders исключены.
2. Source module stems уникальны без учёта регистра и `.ts/.tsx/.js/.jsx` extension. Отдельная negative fixture воспроизводит именно исходную пару, а не только literal filename collision.
3. Component и tests явно используют renamed engine; legacy imports не допускаются.

Typecheck/tests/production build проходят с новой структурой. На Linux нельзя воспроизвести native Windows filesystem/esbuild поведение напрямую; regression проверяет case-insensitive resolution keys и устраняет неоднозначность исходного module stem. Этот fix подготовлен для Windows dev запуска.

### Screenshots и второй optical pass

| State | Stage11B before | Stage11C after |
| --- | --- | --- |
| Empty | [before](./stage11/before-brand-correction/main-empty.png) | [after](./stage11/main-empty.png) |
| Main · 2 | [before](./stage11/before-brand-correction/main-two.png) | [after](./stage11/main-two.png) |
| Main · 6 | [before](./stage11/before-brand-correction/main-six.png) | [after](./stage11/main-six.png) |
| Detail | [before](./stage11/before-brand-correction/detail-online.png) | [after](./stage11/detail-online.png) |
| Guide | [before](./stage11/before-brand-correction/guide-home.png) | [after](./stage11/guide-home.png) |
| Appearance | [before](./stage11/before-brand-correction/settings-full.png) | [after](./stage11/settings-full.png) |

[Header crop](./stage11/header-brand.png), [small app mark scales](./stage11/logo-scales.png), [760×600 full app](./stage11/matrix-full-normal-760x600-main.png).

После первого screenshots review выполнен второй optical pass: убрана ещё одна redundant inventory caption, уточнены quiet metadata/Guide captions, проверены logo scales. Затем повторён весь финальный regression sequence. Просмотрены реальные финальные captures empty, main 2/6, detail, Guide, Appearance, header, logo scales и small window. Wordmark имеет явную hierarchy, открытый logo читается, tabs имеют собственный active state, excessive tracking отсутствует. Body и technical values различимы; header выглядит единым блоком. Gaming/cyberclub styling не добавлен. Визуальное принятие остаётся за пользователем.

### Final Stage11C QA

**typecheck → 187/187 unit tests → production build → appearance 17 → Guide 14 → UX 22 → orchestration 13 → WoL 11 → SSH 10 → RDP 10 → network 12 → CRUD 13: все PASS.** Итого 122 Electron QA groups, 120 matrix views. Все старые appearance/engine checks сохранены. Дополнительно QA проверяет mark без rect/с тремя nodes, brand display stack отдельно от body, умеренный computed tracking, отсутствие empty micro-label и header capture.

Unexpected renderer/console errors отсутствуют в suites, которые их фиксируют. Security audit повторён: 48 защищённых main/preload/shared/package/build/ROADMAP files и 15 Guide .ts data/metadata files неизменны. Renderer не получил Node/IPC/execution capability. Password/secret fields не добавлены. Motion/appearance unchanged evidence сохранено в audit.

Скриншоты получены в Linux/Electron/Xvfb с system font fallback: кириллица, wrapping и layouts проверены, но фактический Bahnschrift/Segoe UI Display glyph rendering, Windows DPI и native minimize требуют Windows visual smoke. На Windows из папки проекта:

```powershell
npm.cmd ci
npm.cmd run dev
```

Для production проверки: `npm.cmd run typecheck`, `npm.cmd test`, `npm.cmd run build`, `npm.cmd start`. Проверить fonts/Cyrillic, 16px logo, 760×600 и DPI 100/125/150%. Native Windows hardware/client limitations предыдущих этапов остаются явно отмеченными. **Остановлено после Stage11C; Stage12 не начат.**
