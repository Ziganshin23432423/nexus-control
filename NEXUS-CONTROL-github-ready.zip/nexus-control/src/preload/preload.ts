import { contextBridge, ipcRenderer } from 'electron';
import { IPC_CHANNELS } from '../shared/constants';
import type { AppInfo, ConnectionCheckResult, Computer, ComputerDraft, IpcResult, NexusApi, RemoteDesktopLaunchResult, SshTerminalLaunchResult, WakeComputerResult, WakeAndConnectProgress, WakeAndRdpResult, WakeAndSshResult } from '../shared/types';

const api: NexusApi = Object.freeze({
  wakeAndOpenRemoteDesktop: (id: string): Promise<IpcResult<WakeAndRdpResult>> => ipcRenderer.invoke(IPC_CHANNELS.wakeAndOpenRemoteDesktop, id),
  wakeAndOpenSshTerminal: (id: string): Promise<IpcResult<WakeAndSshResult>> => ipcRenderer.invoke(IPC_CHANNELS.wakeAndOpenSshTerminal, id),
  cancelWakeAndConnect: (id: string): Promise<IpcResult<{ computerId: string; cancelled: boolean }>> => ipcRenderer.invoke(IPC_CHANNELS.cancelWakeAndConnect, id),
  onWakeAndConnectProgress: (listener: (progress: WakeAndConnectProgress) => void): (() => void) => {
    const handler = (_event: Electron.IpcRendererEvent, progress: WakeAndConnectProgress): void => listener(progress);
    ipcRenderer.on(IPC_CHANNELS.wakeAndConnectProgress, handler);
    return () => { ipcRenderer.removeListener(IPC_CHANNELS.wakeAndConnectProgress, handler); };
  },
  wakeComputer: (id: string): Promise<IpcResult<WakeComputerResult>> => ipcRenderer.invoke(IPC_CHANNELS.wakeComputer, id),
  getAppInfo: (): Promise<AppInfo> => ipcRenderer.invoke(IPC_CHANNELS.getAppInfo),
  listComputers: (): Promise<IpcResult<Computer[]>> => ipcRenderer.invoke(IPC_CHANNELS.listComputers),
  createComputer: (draft: ComputerDraft): Promise<IpcResult<Computer>> => ipcRenderer.invoke(IPC_CHANNELS.createComputer, draft),
  updateComputer: (id: string, draft: ComputerDraft): Promise<IpcResult<Computer>> => ipcRenderer.invoke(IPC_CHANNELS.updateComputer, id, draft),
  deleteComputer: (id: string): Promise<IpcResult<null>> => ipcRenderer.invoke(IPC_CHANNELS.deleteComputer, id),
  checkComputerStatus: (id: string): Promise<IpcResult<ConnectionCheckResult>> => ipcRenderer.invoke(IPC_CHANNELS.checkComputerStatus, id),
  refreshAllComputerStatuses: (): Promise<IpcResult<ConnectionCheckResult[]>> => ipcRenderer.invoke(IPC_CHANNELS.refreshAllComputerStatuses),
  openSshTerminal: (id: string): Promise<IpcResult<SshTerminalLaunchResult>> => ipcRenderer.invoke(IPC_CHANNELS.openSshTerminal, id),
  openRemoteDesktop: (id: string): Promise<IpcResult<RemoteDesktopLaunchResult>> => ipcRenderer.invoke(IPC_CHANNELS.openRemoteDesktop, id),
  cancelComputerStatusChecks: (): Promise<void> => ipcRenderer.invoke(IPC_CHANNELS.cancelComputerStatusChecks),
});

contextBridge.exposeInMainWorld('nexus', api);
