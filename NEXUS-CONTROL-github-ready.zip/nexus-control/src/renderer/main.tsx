import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { AppErrorBoundary } from './components/AppErrorBoundary';
import { App } from './App';
import { AppearanceProvider } from './appearance/AppearanceProvider';
import { Starfield } from './appearance/Starfield';
import './styles/tokens.css';
import './styles/global.css';
import './styles/workspace.css';
import './styles/computers.css';
import './styles/dialog.css';
import './styles/feedback.css';
import './styles/guide.css';
import './styles/visual-direction.css';
import './styles/brand-typography.css';

const root = document.getElementById('root');
if (!root) throw new Error('Root element is missing.');

createRoot(root).render(
  <StrictMode>
    <AppearanceProvider><Starfield /><AppErrorBoundary><App /></AppErrorBoundary></AppearanceProvider>
  </StrictMode>,
);
