import type { Computer, ConnectionCheckResult, WakeAndConnectProgress } from '../../shared/types';
import { ComputerCard } from '../components/ComputerCard';
import { Icon } from '../components/Icon';
import type { DemoAction, DemoJob } from '../state/demoTypes';
import { createDemoStatus } from '../state/demoData';
import { unverifiedStatus } from '../state/computerStatus';
import { EmptyState } from './EmptyState';

interface ComputersPageProps {
  demoOnly?: boolean;
  workflows?: Readonly<Record<string, WakeAndConnectProgress>>;
  wakePendingIds?: Readonly<Record<string, boolean>>;
  sshPendingIds?: Readonly<Record<string, boolean>>;
  rdpPendingIds?: Readonly<Record<string, boolean>>;
  computers: readonly Computer[];
  statuses: Readonly<Record<string, ConnectionCheckResult>>;
  jobs: Readonly<Record<string, DemoJob>>;
  isBusy: boolean;
  isChecking?: boolean;
  onCancelCheck?(): void;
  onAdd(): void;
  onOpen(computerId: string): void;
  onCheck(): void;
  onAction(computer: Computer, action: DemoAction): void;
  onCancel(computerId: string): void;
}

export function ComputersPage({ demoOnly = true, rdpPendingIds = {}, sshPendingIds = {}, wakePendingIds = {}, workflows = {}, computers, statuses, jobs, isBusy, isChecking = false, onCancelCheck, onAdd, onOpen, onCheck, onAction, onCancel }: ComputersPageProps): React.JSX.Element {
  if (computers.length === 0) return <EmptyState onAdd={onAdd} />;
  const onlineCount = computers.filter((computer) => statuses[computer.id]?.status === 'online').length;

  return (
    <section className="page computers-page" aria-labelledby="computers-title">
      <div className="page-heading">
        <div><h1 id="computers-title" tabIndex={-1}>Мои компьютеры</h1><div className="inventory-caption"><span>{computers.length} {computers.length === 1 ? 'компьютер' : computers.length < 5 ? 'компьютера' : 'компьютеров'}</span><span className="caption-divider" /><span className="online-count"><span className="status-dot" />{onlineCount} онлайн</span></div></div>
        <button className="button button-primary add-button" onClick={onAdd}><Icon name="plus" />Добавить компьютер</button>
      </div>

      <div className="inventory-toolbar"><div className="inventory-toolbar-actions"><button className="text-button refresh-button" disabled={isBusy || isChecking || Object.values(jobs).some(job => job.action === 'check')} onClick={onCheck} aria-label="Проверить статусы" aria-busy={isChecking}><Icon name="refresh" size={15} className={(isChecking || Object.values(jobs).some((job) => job.action === 'check')) ? 'spin' : ''} />{(isChecking || Object.values(jobs).some((job) => job.action === 'check')) ? 'Проверка…' : 'Обновить'}</button>{!demoOnly && isChecking && <button className="text-button" onClick={onCancelCheck}>Отмена проверки</button>}</div></div>
      <div className="computer-grid">
        {computers.map((computer) => <ComputerCard workflow={workflows[computer.id]} wakePending={wakePendingIds[computer.id] ?? false} sshPending={sshPendingIds[computer.id] ?? false} rdpPending={rdpPendingIds[computer.id] ?? false} demoOnly={demoOnly} key={computer.id} computer={computer} status={statuses[computer.id] ?? (demoOnly ? createDemoStatus(computer, 'offline') : unverifiedStatus(computer))} job={jobs[computer.id]} onOpen={() => onOpen(computer.id)} onAction={(action) => onAction(computer, action)} onCancel={() => onCancel(computer.id)} />)}
      </div>
      <div className="workspace-note"><Icon name="info" size={15} /><span>{demoOnly ? 'Это демо-устройства. Все действия имитируются.' : 'Доступность определена по RDP / SSH. «Недоступен» не означает, что компьютер выключен.'}</span></div>
    </section>
  );
}
