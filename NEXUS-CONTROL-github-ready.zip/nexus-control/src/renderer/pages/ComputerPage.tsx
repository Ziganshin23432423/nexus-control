import { HelpButton } from '../guide/HelpButton';
import type { Computer, ConnectionCheckResult, WakeAndConnectProgress } from '../../shared/types';
import { ComputerActions } from '../components/ComputerActions';
import { Icon } from '../components/Icon';
import { StatusBadge } from '../components/StatusBadge';
import type { DemoAction, DemoJob } from '../state/demoTypes';

interface ComputerPageProps {
  demoOnly?: boolean;
  rdpPending?: boolean;
  sshPending?: boolean;
  wakePending?: boolean;
  workflow?: WakeAndConnectProgress | undefined;
  checking?: boolean;
  onCheck(): void;
  onDelete(): void;
  computer: Computer;
  status: ConnectionCheckResult;
  job: DemoJob | undefined;
  onBack(): void;
  onEdit(): void;
  onAction(action: DemoAction): void;
  onCancel(): void;
}

export function ComputerPage({ demoOnly = true, rdpPending = false, sshPending = false, wakePending = false, workflow, checking = false, onCheck, onDelete, computer, status, job, onBack, onEdit, onAction, onCancel }: ComputerPageProps): React.JSX.Element {
  const information = [
    ['Hostname', computer.hostname || 'Не указан'],
    ['Локальный IP / hostname', computer.localAddress],
    ['Удалённый IP', computer.remoteAddress ?? 'Не настроен'],
    ['MAC-адрес', computer.macAddress ?? 'Не настроен'],
    ['Операционная система', computer.operatingSystem === 'windows' ? 'Windows' : 'Linux'],
    ['Имя пользователя', computer.username ?? 'Не указано'],
  ] as const;

  return (
    <section className="page computer-page" aria-labelledby="computer-title">
      <button className="text-button back-button" onClick={onBack}><Icon name="arrowLeft" size={17} />Назад</button>
      <div className="computer-page-heading">
        <div className="computer-heading-identity"><span className="detail-device-icon"><Icon name="monitor" size={29} /></span><div><h1 id="computer-title" tabIndex={-1}>{computer.name}</h1><span className="os-caption"><Icon name={computer.operatingSystem === 'windows' ? 'windows' : 'terminal'} size={13} />{computer.operatingSystem === 'windows' ? 'Windows PC' : 'Linux PC'}</span></div></div>
        <div className="computer-heading-actions"><StatusBadge status={status.status} />{!demoOnly && <button className="text-button" onClick={onCheck} disabled={checking} aria-busy={checking}><Icon name="refresh" size={15} className={checking ? "spin" : ""} />Обновить</button>}<button className="button button-secondary button-small" disabled={job !== undefined || rdpPending || sshPending || wakePending || workflow !== undefined} onClick={onEdit}><Icon name="pencil" size={15} />Редактировать</button><button className="text-button" onClick={onDelete} disabled={job !== undefined || rdpPending || sshPending || wakePending || workflow !== undefined}>Удалить</button></div>
      </div>

      <div className="computer-detail-grid">
        <section className="panel information-panel" aria-labelledby="information-title">
          <div className="panel-heading"><Icon name="network" size={17} /><h2 id="information-title">О КОМПЬЮТЕРЕ</h2></div>
          <dl className="information-grid">
            {information.map(([label, value]) => <div key={label}><dt>{label}</dt><dd className={label === 'Операционная система' || label === 'Имя пользователя' ? '' : 'mono'}>{value}</dd></div>)}
          </dl>
          {computer.notes && <p className="computer-note"><Icon name="info" size={15} />{computer.notes}</p>}
          {computer.wakeOnLan && <details className="technical-details"><summary>Параметры Wake-on-LAN<Icon name="chevronDown" size={15} /></summary><dl><div><dt>Broadcast address</dt><dd className="mono">{computer.wakeOnLan.broadcastAddress}</dd></div><div><dt>Порт</dt><dd className="mono">{computer.wakeOnLan.port}</dd></div></dl></details>}
        </section>

        <section className="panel connection-panel" aria-labelledby="connection-title">
          <div className="panel-heading"><Icon name="monitor" size={17} /><h2 id="connection-title">ПОДКЛЮЧЕНИЕ</h2></div>
          <div className="connection-services">
            <div><span className="connection-service-icon"><Icon name="monitor" size={18} /></span><span><strong>RDP</strong><small>Удалённый рабочий стол</small></span><StatusBadge status={status.rdp} compact /><HelpButton label="RDP" articleId={status.rdp==='unavailable'?'troubleshooting/rdp-unavailable':'connection/rdp'}/></div>
            <div><span className="connection-service-icon"><Icon name="terminal" size={18} /></span><span><strong>SSH</strong><small>Терминал</small></span><StatusBadge status={status.ssh} compact /><HelpButton label="SSH" articleId={status.ssh==='unavailable'?'troubleshooting/ssh-unavailable':'connection/ssh'}/></div>
            <div><span className="connection-service-icon"><Icon name="power" size={18} /></span><span><strong>Wake-on-LAN</strong><small>Включение компьютера</small></span><StatusBadge status={status.wakeOnLan} compact /><HelpButton label="Wake-on-LAN" articleId="wol/setup"/></div>
          </div>
          {!demoOnly && status.services && <details className="technical-details network-details"><summary>Подробнее о проверке<Icon name="chevronDown" size={15} /></summary>
            {status.services.map((service) => <div className="network-service-detail" key={service.service}><strong>{service.service.toUpperCase()} · TCP {service.port}</strong>
              {service.addressUsed && <p>{service.addressKind === 'remote' ? 'Удалённый адрес' : 'Локальный адрес'}: <span className="mono">{service.addressUsed}</span>{service.latencyMs !== null && ` · ${service.latencyMs} мс`}</p>}
              {service.attempts.map((attempt) => <p key={attempt.addressKind}>{attempt.addressKind === 'local' ? 'Локальный' : 'Удалённый'} · <span className="mono">{attempt.address}</span> · {attempt.status === 'ready' ? 'Готов' : 'Нет ответа'}{attempt.errorCode && ` (${attempt.errorCode})`}</p>)}
              {service.status === 'disabled' && <p>Не настроен — не проверялся</p>}</div>)}
            {status.checkedAt && <p>Проверено: {new Date(status.checkedAt).toLocaleTimeString('ru-RU')}</p>}
          </details>}
          <div className="detail-actions"><ComputerActions workflow={workflow} wakePending={wakePending} sshPending={sshPending} rdpPending={rdpPending} demoOnly={demoOnly} computer={computer} status={status} job={job} expanded onAction={onAction} onCancel={onCancel} /></div>
          <p className="demo-action-caption"><Icon name={demoOnly ? "beaker" : "info"} size={13} />{demoOnly ? 'Подключение и питание имитируются' : 'RDP открывается в клиенте Windows. Запуск клиента не подтверждает вход. SSH открывается в отдельной консоли. Magic Packet подтверждает только отправку, а не включение ПК.'}</p>
        </section>
      </div>
    </section>
  );
}
