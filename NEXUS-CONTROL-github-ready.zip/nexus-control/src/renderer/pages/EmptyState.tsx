import { Icon } from '../components/Icon';

export function EmptyState({ onAdd }: { onAdd(): void }): React.JSX.Element {
  return (
    <section className="empty-state" aria-labelledby="empty-title">
      <div className="empty-device"><Icon name="monitor" size={42} /><span className="empty-device-plus"><Icon name="plus" size={15} /></span></div>
      <h1 id="empty-title" tabIndex={-1}>У вас пока нет компьютеров.</h1>
      <p>Добавьте первый компьютер, чтобы начать работу.</p>
      <button className="button button-primary" onClick={onAdd}><Icon name="plus" />Добавить компьютер</button>
    </section>
  );
}
