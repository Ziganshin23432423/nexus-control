import { createContext, useContext } from 'react';
import type { GuideArticleId } from './ids';
export const GuideContext = createContext<{open(id?:GuideArticleId):void;openOverlay(id:GuideArticleId):void}>({open:()=>{},openOverlay:()=>{}});
export const useGuide = () => useContext(GuideContext);
