import type { GuideArticleId } from "./ids.js";
import type { GuideArticle } from "./types.js";
import { articles as s0 } from "./content/quick-start.js";
import { articles as s1 } from "./content/connection.js";
import { articles as s2 } from "./content/wol.js";
import { articles as s3 } from "./content/troubleshooting.js";
import { articles as s4 } from "./content/security.js";
import { articles as s5 } from "./content/terms.js";
export const GUIDE_ARTICLES: readonly GuideArticle[] = Object.freeze([...s0,...s1,...s2,...s3,...s4,...s5]);
const index = new Map<string, GuideArticle>(GUIDE_ARTICLES.map(a => [a.id,a]));
export function getGuideArticle(id: GuideArticleId): GuideArticle | undefined { return index.get(id); }
