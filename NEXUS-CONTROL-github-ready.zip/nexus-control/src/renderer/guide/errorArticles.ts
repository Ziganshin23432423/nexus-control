import type { IpcErrorCode } from '../../shared/types.js';
import type { GuideArticleId } from './ids.js';
export const ERROR_GUIDE_ARTICLES: Readonly<Partial<Record<IpcErrorCode,GuideArticleId>>> = {
RDP_UNAVAILABLE:'troubleshooting/rdp-unavailable',SSH_UNAVAILABLE:'troubleshooting/ssh-unavailable',WOL_SEND_ERROR:'troubleshooting/wol',WOL_TIMEOUT:'troubleshooting/wol',WAKE_CONNECT_TIMEOUT:'troubleshooting/wake-connect-timeout',SSH_CLIENT_MISSING:'connection/openssh-client',SSH_HOST_MISSING:'troubleshooting/windows-terminal',RDP_DISABLED:'quick-start/rdp-requirements',SSH_DISABLED:'quick-start/ssh-requirements',WOL_DISABLED:'wol/setup',RDP_LAUNCH_ERROR:'connection/rdp',SSH_LAUNCH_ERROR:'connection/windows-terminal',NETWORK_ERROR:'troubleshooting/pc-unavailable'};
