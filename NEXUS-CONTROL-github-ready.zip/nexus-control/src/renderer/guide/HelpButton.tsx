import { Icon } from '../components/Icon';
import { useGuide } from './context';
import type { GuideArticleId } from './ids';
export function HelpButton({articleId,label,overlay=false}:{articleId:GuideArticleId;label:string;overlay?:boolean}):React.JSX.Element { const guide=useGuide();return <button type="button" className="guide-help" aria-label={`Инструкция: ${label}`} title={`Инструкция: ${label}`} onClick={()=>overlay?guide.openOverlay(articleId):guide.open(articleId)}><Icon name="info" size={14}/></button>; }
