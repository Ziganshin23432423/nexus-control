import { useEffect,useRef } from 'react';
import type { GuideArticleId } from './ids';
import { GuidePage } from './GuidePage';
export function GuideDialog({articleId,onClose}:{articleId:GuideArticleId;onClose():void}):React.JSX.Element {const ref=useRef<HTMLDialogElement>(null);useEffect(()=>{const prior=document.activeElement;const dialog=ref.current;dialog?.showModal();return()=>{dialog?.close();if(prior instanceof HTMLElement&&prior.isConnected)prior.focus();};},[]);return <dialog ref={ref} className="guide-dialog" aria-label="Инструкция NEXUS GUIDE" onCancel={e=>{e.preventDefault();onClose();}}><GuidePage initialArticleId={articleId} onClose={onClose} overlay/></dialog>;}
