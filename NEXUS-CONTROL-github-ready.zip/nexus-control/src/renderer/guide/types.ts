import type { GuideArticleId } from './ids.js';
export type GuideSectionId = 'quick-start' | 'connection' | 'wol' | 'troubleshooting' | 'security' | 'terms';
export type GuideCommandId = 'hostname' | 'ipconfig' | 'ipconfigAll' | 'whoami';
export interface GuideSection { readonly id: GuideSectionId; readonly title: string; readonly description: string }
export interface GuideStep { readonly title: string; readonly text: string; readonly articleId: GuideArticleId; readonly commandId?: GuideCommandId }
export type GuideBlock = { readonly type: 'paragraph'; readonly text: string } | { readonly type: 'steps'; readonly items: readonly string[] } | { readonly type: 'callout'; readonly title: string; readonly text: string } | { readonly type: 'command'; readonly commandId: GuideCommandId } | { readonly type: 'checklist'; readonly steps: readonly GuideStep[] } | { readonly type: 'data-card'; readonly items: readonly string[] };
export interface GuideArticle { readonly id: GuideArticleId; readonly sectionId: GuideSectionId; readonly title: string; readonly description: string; readonly keywords: readonly string[]; readonly blocks: readonly GuideBlock[]; readonly related: readonly GuideArticleId[]; readonly sources: readonly string[] }
