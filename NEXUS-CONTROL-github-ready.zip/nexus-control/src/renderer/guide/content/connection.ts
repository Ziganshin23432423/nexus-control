import type { GuideArticle } from "../types.js";
export const articles: readonly GuideArticle[] = [
  {
    "id": "connection/rdp",
    "sectionId": "connection",
    "title": "RDP: подготовить Windows",
    "description": "RDP открывает рабочий стол другого компьютера в стандартном клиенте Windows.",
    "keywords": [
      "3389",
      "remote desktop"
    ],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "На целевом ПК: Пуск → Параметры → Система → О системе. Проверьте редакцию: Windows Home не принимает стандартные RDP-подключения; нужны Pro, Enterprise или Education.",
          "Параметры → Система → Удалённый рабочий стол. Включите доступ и подтвердите изменение.",
          "В «Пользователи удалённого рабочего стола» разрешите нужную учётную запись. Оставьте NLA включённой.",
          "Убедитесь, что ПК включён, сеть доступна, а firewall разрешает RDP. На ПК с NEXUS сохраните адрес и включите RDP в карточке."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Изменение разрешает удалённый доступ. Выполняйте его только на своём ПК или с разрешением владельца. Пароль вводится в клиенте Windows; PIN Windows Hello не равен паролю."
      }
    ],
    "related": [
      "troubleshooting/rdp-unavailable",
      "security/rdp-password"
    ],
    "sources": [
      "rdp"
    ]
  },
  {
    "id": "connection/ssh",
    "sectionId": "connection",
    "title": "SSH: открыть терминал",
    "description": "SSH даёт защищённую консоль. NEXUS открывает Windows OpenSSH, а вход выполняет сам клиент.",
    "keywords": [
      "22"
    ],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Подготовьте Server на другом ПК и Client на ПК с NEXUS.",
          "Заполните адрес и имя пользователя, включите SSH в карточке.",
          "Нажмите «Терминал». TCP 22 должен отвечать; затем проверяйте host key и вход в самой консоли."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Ввод пароля в консоли может не показывать символы. Это нормально. Не отключайте проверку ключа сервера."
      }
    ],
    "related": [
      "connection/openssh-server",
      "connection/openssh-client",
      "security/host-key"
    ],
    "sources": []
  },
  {
    "id": "connection/local-address",
    "sectionId": "connection",
    "title": "Локальный адрес",
    "description": "Адрес ПК в вашей домашней или рабочей сети.",
    "keywords": [
      "ip",
      "IPv4"
    ],
    "blocks": [
      {
        "type": "command",
        "commandId": "ipconfig"
      },
      {
        "type": "steps",
        "items": [
          "На целевом ПК найдите IPv4 активного Ethernet / Wi-Fi адаптера.",
          "Перенесите его в «Локальный IP / hostname», например 192.168.1.25.",
          "При смене DHCP-адреса обновите карточку или настройте резервирование адреса на своём роутере вручную."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "127.0.0.1 указывает на текущий компьютер. 169.254.x.x часто означает, что DHCP не выдал адрес; проверьте сеть."
      }
    ],
    "related": [
      "troubleshooting/local-address"
    ],
    "sources": [
      "ipconfig"
    ]
  },
  {
    "id": "connection/remote-address",
    "sectionId": "connection",
    "title": "Удалённый / VPN-адрес",
    "description": "Дополнительный адрес для уже настроенной удалённой сети.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Сначала настройте разрешённый VPN / маршрут вне NEXUS.",
          "Укажите выданный VPN-адрес другого ПК в Remote / VPN IP.",
          "NEXUS проверяет локальный адрес, затем сохранённый удалённый адрес при недоступности первого."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Заполнение поля не создаёт VPN и не пробрасывает порты. Public IP роутера не гарантирует доступ к нужному ПК."
      }
    ],
    "related": [
      "security/vpn",
      "troubleshooting/remote-address"
    ],
    "sources": []
  },
  {
    "id": "connection/hostname",
    "sectionId": "connection",
    "title": "Hostname",
    "description": "Сетевое имя компьютера, например HOME-PC.",
    "keywords": [],
    "blocks": [
      {
        "type": "command",
        "commandId": "hostname"
      },
      {
        "type": "paragraph",
        "text": "В карточке Hostname — справочная информация. Если хотите подключаться по имени, впишите его также в «Локальный IP / hostname». Имя должно разрешаться вашей сетью."
      }
    ],
    "related": [
      "connection/local-address"
    ],
    "sources": [
      "hostname"
    ]
  },
  {
    "id": "connection/ports",
    "sectionId": "connection",
    "title": "Порты",
    "description": "Порт выбирает службу на адресе компьютера.",
    "keywords": [
      "3389",
      "22",
      "9"
    ],
    "blocks": [
      {
        "type": "paragraph",
        "text": "NEXUS проверяет RDP на TCP 3389 и SSH на TCP 22. WoL отправляет UDP, по умолчанию на порт 9. Протокол TCP / UDP имеет значение."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Нестандартные RDP / SSH порты в текущем MVP не настраиваются. Поле WoL Port не меняет порт SSH или RDP."
      }
    ],
    "related": [
      "connection/service-checks",
      "terms/tcp",
      "terms/udp"
    ],
    "sources": []
  },
  {
    "id": "connection/service-checks",
    "sectionId": "connection",
    "title": "Почему NEXUS проверяет 3389 и 22",
    "description": "Проверки показывают сетевую доступность настроенных служб.",
    "keywords": [
      "3389",
      "22"
    ],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Если отвечает хотя бы одна включённая служба, ПК считается онлайн. Отсутствие ответа не доказывает выключение: возможны firewall, маршрут или остановленная служба."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "TCP ready означает принятие соединения на порту, а не успешную аутентификацию и не проверку RDP / SSH handshake. NEXUS не полагается только на ping."
      }
    ],
    "related": [
      "troubleshooting/pc-unavailable"
    ],
    "sources": []
  },
  {
    "id": "connection/username",
    "sectionId": "connection",
    "title": "Имя пользователя SSH",
    "description": "Username — учётная запись целевого ПК, под которой откроется SSH-сессия.",
    "keywords": [
      "username",
      "login"
    ],
    "blocks": [
      {
        "type": "command",
        "commandId": "whoami"
      },
      {
        "type": "paragraph",
        "text": "Запустите команду на целевом ПК под нужным пользователем. Для локальной Windows-учётной записи может подходить username, для доменной — DOMAIN\\user. Используйте имя, соответствующее настройкам OpenSSH Server."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Отображаемое имя и почта Microsoft Account не всегда подходят для входа. Проверьте разрешённую учётную запись с администратором; пароль не добавляйте в карточку."
      }
    ],
    "related": [
      "security/ssh-password"
    ],
    "sources": [
      "whoami"
    ]
  },
  {
    "id": "connection/openssh-client",
    "sectionId": "connection",
    "title": "Установить OpenSSH Client",
    "description": "Client нужен на компьютере с NEXUS; он подключается к SSH Server.",
    "keywords": [
      "client missing",
      "ssh.exe"
    ],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Через поиск Пуск откройте «Дополнительные компоненты» / Optional Features. В Windows 10 обычно: Параметры → Приложения → Дополнительные компоненты. В Windows 11 расположение зависит от выпуска; используйте поиск.",
          "Проверьте список установленных компонентов. Если OpenSSH Client отсутствует, выберите добавление / просмотр компонентов, найдите OpenSSH Client и установите.",
          "Повторите открытие терминала в NEXUS."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Установка может потребовать интернет, права администратора и доступ к Windows Update. Guide её не выполняет."
      }
    ],
    "related": [
      "troubleshooting/openssh-client"
    ],
    "sources": [
      "openssh"
    ]
  },
  {
    "id": "connection/openssh-server",
    "sectionId": "connection",
    "title": "Подготовить OpenSSH Server",
    "description": "Server принимает подключения на целевом ПК. Установка Client на нём не заменяет Server.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "На целевом ПК через Пуск найдите Optional Features / «Дополнительные компоненты». Установите OpenSSH Server, если его нет.",
          "Через поиск Пуск откройте «Службы». Найдите OpenSSH SSH Server (sshd), запустите и при необходимости задайте автоматический запуск.",
          "Установка создаёт правило firewall для TCP 22. Если правила нет или оно отключено, администратор должен проверить доступ для вашей сети. Не отключайте firewall целиком."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Вы вручную включаете сетевой доступ к консоли. Убедитесь, что пользователю разрешён вход; NEXUS не настраивает sshd или firewall."
      }
    ],
    "related": [
      "connection/username",
      "troubleshooting/ssh-unavailable"
    ],
    "sources": [
      "openssh"
    ]
  },
  {
    "id": "connection/windows-terminal",
    "sectionId": "connection",
    "title": "Windows Terminal",
    "description": "Удобное отдельное окно для SSH. При его отсутствии NEXUS использует стандартный Console Host.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Windows Terminal необязателен для SSH. Если хотите использовать его, установите официальный Microsoft Windows Terminal отдельно. Обязателен OpenSSH Client."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Открытая консоль не доказывает успешный вход. Сообщения SSH и пароль остаются внутри консоли."
      }
    ],
    "related": [
      "connection/openssh-client",
      "troubleshooting/windows-terminal"
    ],
    "sources": [
      "terminal"
    ]
  }
];
