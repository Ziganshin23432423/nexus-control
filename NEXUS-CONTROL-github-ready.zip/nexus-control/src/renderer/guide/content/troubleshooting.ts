import type { GuideArticle } from "../types.js";
export const articles: readonly GuideArticle[] = [
  {
    "id": "troubleshooting/pc-unavailable",
    "sectionId": "troubleshooting",
    "title": "ПК не отвечает",
    "description": "Нет ответа от настроенных служб; это не доказательство выключения.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте питание и подключение к вашей сети.",
          "Сверьте адрес, VPN и доступность конкретной службы.",
          "Проверьте firewall целевого ПК, не отключая его целиком."
        ]
      }
    ],
    "related": [
      "connection/service-checks"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/rdp-unavailable",
    "sectionId": "troubleshooting",
    "title": "RDP не отвечает",
    "description": "Порт TCP 3389 недоступен.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте редакцию Windows и включение удалённого рабочего стола.",
          "Проверьте адрес, доступ сети и правило firewall.",
          "Если порт уже готов, но вход не проходит, проверьте пользователя и пароль в клиенте."
        ]
      }
    ],
    "related": [
      "connection/rdp"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/ssh-unavailable",
    "sectionId": "troubleshooting",
    "title": "SSH не отвечает",
    "description": "Порт TCP 22 недоступен.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте OpenSSH Server на целевом ПК, а не только Client.",
          "Проверьте состояние службы sshd и firewall.",
          "Сверьте адрес. Ошибки входа решайте в консоли, не записывая пароль в NEXUS."
        ]
      }
    ],
    "related": [
      "connection/openssh-server"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/wol",
    "sectionId": "troubleshooting",
    "title": "WoL не работает",
    "description": "Проверьте путь сигнала и поддержку пробуждения.",
    "keywords": [
      "не включается"
    ],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте MAC Ethernet и маску / broadcast.",
          "Проверьте питание, BIOS и параметры драйвера.",
          "Попробуйте сон в одной локальной сети; учитывайте VLAN и изоляцию клиентов Wi-Fi."
        ]
      }
    ],
    "related": [
      "wol/setup",
      "wol/packet-sent"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/local-address",
    "sectionId": "troubleshooting",
    "title": "Local address не работает",
    "description": "Адрес мог измениться или имя не разрешается.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "На целевом ПК повторно посмотрите IPv4 активного адаптера.",
          "Сверьте адрес в карточке и вашу подсеть.",
          "Если hostname не работает, попробуйте известный IPv4 того же ПК."
        ]
      }
    ],
    "related": [
      "connection/local-address"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/remote-address",
    "sectionId": "troubleshooting",
    "title": "Remote address не работает",
    "description": "Удалённый маршрут должен быть настроен отдельно.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте подключение VPN и актуальный адрес цели.",
          "Убедитесь, что VPN разрешает доступ к целевому ПК / порту.",
          "Не путайте public IP роутера и VPN IP компьютера."
        ]
      }
    ],
    "related": [
      "connection/remote-address"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/openssh-client",
    "sectionId": "troubleshooting",
    "title": "OpenSSH Client не найден",
    "description": "На ПК с NEXUS отсутствует стандартный SSH-клиент.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Откройте Optional Features и проверьте OpenSSH Client.",
          "Установите компонент вручную, затем повторите подключение."
        ]
      }
    ],
    "related": [
      "connection/openssh-client"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/windows-terminal",
    "sectionId": "troubleshooting",
    "title": "Windows Terminal не найден",
    "description": "SSH может использовать стандартный Console Host.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте OpenSSH Client — он обязателен.",
          "При необходимости отдельно установите официальный Windows Terminal.",
          "Если отсутствует и стандартная консоль Windows, восстановите системные компоненты с администратором."
        ]
      }
    ],
    "related": [
      "connection/windows-terminal"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/wake-connect-timeout",
    "sectionId": "troubleshooting",
    "title": "Timeout Wake → Connect",
    "description": "Нужная служба не стала доступна за 90 секунд.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте, проснулся ли ПК физически.",
          "Проверьте нужную службу: онлайн SSH не означает готовность RDP и наоборот.",
          "При медленной загрузке дождитесь готовности и нажмите «Повторить». Отмена останавливает ожидание, но не отменяет уже отправленный пакет."
        ]
      }
    ],
    "related": [
      "wol/packet-sent",
      "troubleshooting/rdp-unavailable"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/unverified",
    "sectionId": "troubleshooting",
    "title": "Что означает «Не проверено»",
    "description": "Проверка ещё не выполнялась или нет проверяемых служб.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Включите только подготовленные RDP / SSH и проверьте статусы.",
          "Если настроен только WoL, NEXUS не может подтвердить онлайн по этому сигналу."
        ]
      }
    ],
    "related": [
      "connection/service-checks"
    ],
    "sources": []
  },
  {
    "id": "troubleshooting/unavailable",
    "sectionId": "troubleshooting",
    "title": "Что означает «Недоступен»",
    "description": "Настроенные службы не ответили за ограниченное время.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте адрес, сеть, питание и настройки служб.",
          "Повторите проверку после исправления причины."
        ]
      }
    ],
    "related": [
      "troubleshooting/pc-unavailable"
    ],
    "sources": []
  }
];
