import type { GuideArticle } from "../types.js";
export const articles: readonly GuideArticle[] = [
  {
    "id": "quick-start/prepare-target-pc",
    "sectionId": "quick-start",
    "title": "Подготовить другой ПК за 5 минут",
    "description": "Короткий маршрут: собрать данные, включить нужные службы и добавить компьютер в NEXUS.",
    "keywords": [
      "quick start",
      "настроить",
      "подготовка"
    ],
    "blocks": [
      {
        "type": "callout",
        "title": "Перед началом",
        "text": "Это ориентир для уже готовой системы. Установка компонентов и настройка BIOS могут занять больше времени. Все настройки меняете вы, вручную; Guide ничего не запускает."
      },
      {
        "type": "checklist",
        "steps": [
          {
            "title": "Узнайте имя компьютера",
            "text": "На целевом ПК откройте командную строку и посмотрите имя.",
            "articleId": "connection/hostname",
            "commandId": "hostname"
          },
          {
            "title": "Узнайте локальный IPv4",
            "text": "Найдите активный Ethernet-адаптер, IPv4 и маску подсети. Не берите адрес отключённого адаптера.",
            "articleId": "connection/local-address",
            "commandId": "ipconfig"
          },
          {
            "title": "Узнайте MAC Ethernet",
            "text": "Запишите физический адрес проводного адаптера и маску его подсети.",
            "articleId": "wol/mac-address",
            "commandId": "ipconfigAll"
          },
          {
            "title": "Подготовьте RDP",
            "text": "Если нужен рабочий стол, проверьте редакцию Windows и разрешите RDP на целевом ПК.",
            "articleId": "connection/rdp"
          },
          {
            "title": "Подготовьте SSH",
            "text": "Если нужен терминал, установите и запустите OpenSSH Server на целевом ПК. Client нужен на ПК с NEXUS.",
            "articleId": "connection/openssh-server"
          },
          {
            "title": "Подготовьте Wake-on-LAN",
            "text": "Проверьте поддержку оборудования, BIOS/UEFI и драйвер Ethernet. Начните с пробуждения из сна.",
            "articleId": "wol/setup"
          },
          {
            "title": "Запишите SSH username",
            "text": "Уточните имя нужной учётной записи. Оно не всегда совпадает с отображаемым именем профиля.",
            "articleId": "connection/username",
            "commandId": "whoami"
          },
          {
            "title": "Вернитесь к NEXUS",
            "text": "Добавьте компьютер в USER DATA, перенесите адреса и включите подготовленные возможности.",
            "articleId": "quick-start/add-computer"
          }
        ]
      },
      {
        "type": "data-card",
        "items": [
          "Имя ПК / hostname",
          "Локальный IPv4",
          "MAC проводного Ethernet-адаптера",
          "Маска подсети / broadcast",
          "SSH username",
          "Remote / VPN IP — необязательно"
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Пароль НЕ записывать в NEXUS. Отметки чек-листа — ваши заметки в текущем окне, а не проверка системы."
      }
    ],
    "related": [
      "quick-start/add-computer",
      "quick-start/first-connection"
    ],
    "sources": []
  },
  {
    "id": "quick-start/add-computer",
    "sectionId": "quick-start",
    "title": "Как добавить компьютер в NEXUS",
    "description": "Создайте карточку в USER DATA — там настройки сохраняются после перезапуска.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Откройте «Мои компьютеры» → «Добавить компьютер».",
          "Введите название и локальный IP / hostname. Поле Hostname — справочная подпись; подключение использует адрес.",
          "Включите только подготовленные RDP, SSH и WoL. Для SSH задайте username; для WoL — MAC, broadcast и порт 9.",
          "Сохраните. DEMO DATA служит для знакомства и не записывает компьютеры в USER DATA."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Флажок в карточке не включает службу на другом ПК. Сначала подготовьте её вручную."
      }
    ],
    "related": [
      "quick-start/prepare-target-pc"
    ],
    "sources": []
  },
  {
    "id": "quick-start/first-connection",
    "sectionId": "quick-start",
    "title": "Первое подключение",
    "description": "Проверьте статус службы и откройте нужный клиент.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Выберите USER DATA и свою карточку.",
          "Нажмите «Проверить статусы». Готовность TCP не подтверждает вход.",
          "Откройте «Рабочий стол» или «Терминал». Введите учётные данные в клиенте Windows / OpenSSH.",
          "Если ПК спит и WoL настроен, используйте «Включить и подключиться»."
        ]
      }
    ],
    "related": [
      "connection/rdp",
      "connection/ssh"
    ],
    "sources": []
  },
  {
    "id": "quick-start/rdp-requirements",
    "sectionId": "quick-start",
    "title": "Что необходимо для RDP",
    "description": "Поддерживаемая редакция Windows на целевом ПК, разрешённый доступ, сеть и учётная запись.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Поддерживаемая редакция Windows на целевом ПК, разрешённый доступ, сеть и учётная запись."
      },
      {
        "type": "callout",
        "title": "Как подготовить",
        "text": "NEXUS не устанавливает компоненты и не меняет системные настройки."
      }
    ],
    "related": [
      "connection/rdp"
    ],
    "sources": []
  },
  {
    "id": "quick-start/ssh-requirements",
    "sectionId": "quick-start",
    "title": "Что необходимо для SSH",
    "description": "OpenSSH Server на целевом ПК, OpenSSH Client на ПК с NEXUS и разрешённый пользователь.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "OpenSSH Server на целевом ПК, OpenSSH Client на ПК с NEXUS и разрешённый пользователь."
      },
      {
        "type": "callout",
        "title": "Как подготовить",
        "text": "NEXUS не устанавливает компоненты и не меняет системные настройки."
      }
    ],
    "related": [
      "connection/openssh-server"
    ],
    "sources": []
  },
  {
    "id": "quick-start/wol-requirements",
    "sectionId": "quick-start",
    "title": "Что необходимо для Wake-on-LAN",
    "description": "Совместимые BIOS/UEFI, Ethernet-адаптер и питание в нужном состоянии сна или выключения.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Совместимые BIOS/UEFI, Ethernet-адаптер и питание в нужном состоянии сна или выключения."
      },
      {
        "type": "callout",
        "title": "Как подготовить",
        "text": "NEXUS не устанавливает компоненты и не меняет системные настройки."
      }
    ],
    "related": [
      "wol/setup"
    ],
    "sources": []
  }
];
