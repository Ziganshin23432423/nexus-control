import type { GuideArticle } from "../types.js";
export const articles: readonly GuideArticle[] = [
  {
    "id": "terms/ip-address",
    "sectionId": "terms",
    "title": "IP address",
    "description": "Сетевой адрес устройства. Для карточки NEXUS используйте IPv4 или разрешаемый hostname.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Сетевой адрес устройства. Для карточки NEXUS используйте IPv4 или разрешаемый hostname."
      }
    ],
    "related": [
      "connection/local-address"
    ],
    "sources": []
  },
  {
    "id": "terms/local-ip",
    "sectionId": "terms",
    "title": "Local IP",
    "description": "Адрес компьютера внутри вашей локальной сети.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Адрес компьютера внутри вашей локальной сети."
      }
    ],
    "related": [
      "connection/local-address"
    ],
    "sources": []
  },
  {
    "id": "terms/remote-ip",
    "sectionId": "terms",
    "title": "Remote IP",
    "description": "Адрес для отдельно настроенного удалённого маршрута.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Адрес для отдельно настроенного удалённого маршрута."
      }
    ],
    "related": [
      "connection/remote-address"
    ],
    "sources": []
  },
  {
    "id": "terms/vpn-ip",
    "sectionId": "terms",
    "title": "VPN IP",
    "description": "Адрес, через который компьютер доступен в вашей VPN-сети.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Адрес, через который компьютер доступен в вашей VPN-сети."
      }
    ],
    "related": [
      "security/vpn"
    ],
    "sources": []
  },
  {
    "id": "terms/mac-address",
    "sectionId": "terms",
    "title": "MAC",
    "description": "Физический адрес конкретного адаптера; используется для WoL.",
    "keywords": [
      "мак адрес"
    ],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Физический адрес конкретного адаптера; используется для WoL."
      }
    ],
    "related": [
      "wol/mac-address"
    ],
    "sources": []
  },
  {
    "id": "terms/hostname",
    "sectionId": "terms",
    "title": "Hostname",
    "description": "Сетевое имя компьютера; разрешение имени зависит от вашей сети.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Сетевое имя компьютера; разрешение имени зависит от вашей сети."
      }
    ],
    "related": [
      "connection/hostname"
    ],
    "sources": []
  },
  {
    "id": "terms/port",
    "sectionId": "terms",
    "title": "Port",
    "description": "Номер службы в адресе TCP / UDP, например SSH TCP 22.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Номер службы в адресе TCP / UDP, например SSH TCP 22."
      }
    ],
    "related": [
      "connection/ports"
    ],
    "sources": []
  },
  {
    "id": "terms/tcp",
    "sectionId": "terms",
    "title": "TCP",
    "description": "Протокол с установлением соединения. NEXUS проверяет им доступность RDP / SSH.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Протокол с установлением соединения. NEXUS проверяет им доступность RDP / SSH."
      }
    ],
    "related": [
      "connection/service-checks"
    ],
    "sources": []
  },
  {
    "id": "terms/udp",
    "sectionId": "terms",
    "title": "UDP",
    "description": "Протокол без подтверждённого соединения. Отправка не гарантирует доставку.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Протокол без подтверждённого соединения. Отправка не гарантирует доставку."
      }
    ],
    "related": [
      "wol/what-is-wol"
    ],
    "sources": []
  },
  {
    "id": "terms/broadcast",
    "sectionId": "terms",
    "title": "Broadcast",
    "description": "Рассылка всей локальной подсети; её адрес определяется IP и маской.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Рассылка всей локальной подсети; её адрес определяется IP и маской."
      }
    ],
    "related": [
      "wol/broadcast-address"
    ],
    "sources": []
  },
  {
    "id": "terms/rdp",
    "sectionId": "terms",
    "title": "RDP",
    "description": "Remote Desktop Protocol: удалённый рабочий стол. NEXUS открывает стандартный клиент.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Remote Desktop Protocol: удалённый рабочий стол. NEXUS открывает стандартный клиент."
      }
    ],
    "related": [
      "connection/rdp"
    ],
    "sources": []
  },
  {
    "id": "terms/ssh",
    "sectionId": "terms",
    "title": "SSH",
    "description": "Защищённое подключение к консоли. NEXUS использует существующий OpenSSH.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Защищённое подключение к консоли. NEXUS использует существующий OpenSSH."
      }
    ],
    "related": [
      "connection/ssh"
    ],
    "sources": []
  },
  {
    "id": "terms/wol",
    "sectionId": "terms",
    "title": "WoL",
    "description": "Wake-on-LAN: сигнал пробуждения для совместимого сетевого оборудования.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Wake-on-LAN: сигнал пробуждения для совместимого сетевого оборудования."
      }
    ],
    "related": [
      "wol/what-is-wol"
    ],
    "sources": []
  },
  {
    "id": "terms/vpn",
    "sectionId": "terms",
    "title": "VPN",
    "description": "Виртуальная частная сеть: отдельно настроенный защищённый маршрут.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Виртуальная частная сеть: отдельно настроенный защищённый маршрут."
      }
    ],
    "related": [
      "security/vpn"
    ],
    "sources": []
  }
];
