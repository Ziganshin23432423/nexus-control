import type { GuideArticle } from "../types.js";
export const articles: readonly GuideArticle[] = [
  {
    "id": "wol/setup",
    "sectionId": "wol",
    "title": "Настроить Wake-on-LAN",
    "description": "Подготовьте питание и Ethernet на целевом ПК, затем параметры карточки.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте руководство материнской платы / компьютера и адаптера: поддерживается ли WoL из нужного состояния.",
          "При необходимости вручную включите опцию BIOS/UEFI и параметры драйвера адаптера.",
          "Запишите MAC именно этого Ethernet-адаптера; вычислите broadcast по реальной маске подсети.",
          "В NEXUS включите Wake-on-LAN и задайте MAC, broadcast, UDP Port 9. Проверьте сначала в локальной сети из сна."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "В карточке «Настроен» означает наличие параметров. Это не подтверждение поддержки оборудования."
      }
    ],
    "related": [
      "wol/bios",
      "wol/adapter",
      "wol/broadcast-address",
      "troubleshooting/wol"
    ],
    "sources": [
      "dell",
      "wol"
    ]
  },
  {
    "id": "wol/what-is-wol",
    "sectionId": "wol",
    "title": "Что такое Wake-on-LAN",
    "description": "Magic Packet — специальный сетевой сигнал для совместимого адаптера.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Пакет содержит MAC целевого адаптера. NEXUS отправляет контролируемую рассылку UDP; ответ о фактическом пробуждении не приходит."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Адаптер должен получать питание и поддерживать пробуждение в текущем состоянии. Не любой выключенный ПК можно включить по сети."
      }
    ],
    "related": [
      "wol/power-states"
    ],
    "sources": []
  },
  {
    "id": "wol/mac-address",
    "sectionId": "wol",
    "title": "MAC-адрес",
    "description": "Аппаратный адрес сетевого адаптера — не IP и не имя компьютера.",
    "keywords": [
      "MAC",
      "мак адрес"
    ],
    "blocks": [
      {
        "type": "command",
        "commandId": "ipconfigAll"
      },
      {
        "type": "steps",
        "items": [
          "Найдите активный проводной Ethernet-адаптер на целевом ПК.",
          "Запишите «Физический адрес», например AA-BB-CC-DD-EE-FF. NEXUS принимает дефисы или двоеточия.",
          "Не используйте MAC VPN, Wi-Fi или отключённого адаптера вместо Ethernet."
        ]
      }
    ],
    "related": [
      "terms/mac-address"
    ],
    "sources": [
      "ipconfig"
    ]
  },
  {
    "id": "wol/broadcast-address",
    "sectionId": "wol",
    "title": "Broadcast address",
    "description": "Адрес рассылки всей подсети. Он зависит от IP и маски.",
    "keywords": [
      "подсеть",
      "маска"
    ],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Например, для 192.168.1.25 с маской 255.255.255.0 (/24) broadcast — 192.168.1.255. Для того же IP с маской 255.255.255.128 (/25) — 192.168.1.127."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Не заменяйте последний октет на 255 без знания маски. Уточните подсеть на целевом ПК или у администратора. Роутеры могут блокировать directed broadcast."
      }
    ],
    "related": [
      "connection/local-address",
      "terms/broadcast"
    ],
    "sources": []
  },
  {
    "id": "wol/port-9",
    "sectionId": "wol",
    "title": "Почему Port 9",
    "description": "UDP 9 — распространённое значение для отправки Magic Packet.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "В NEXUS это порт назначения UDP, по умолчанию 9. Меняйте его только если этого требует ваша сеть или устройство. Это не порт SSH / RDP."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Открытый TCP 9 не является условием WoL и не подтверждает готовность компьютера."
      }
    ],
    "related": [
      "connection/ports"
    ],
    "sources": []
  },
  {
    "id": "wol/bios",
    "sectionId": "wol",
    "title": "Wake-on-LAN в BIOS / UEFI",
    "description": "Опция пробуждения зависит от производителя и модели.",
    "keywords": [
      "bios",
      "uefi"
    ],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Откройте руководство вашей модели и найдите раздел пробуждения по Ethernet / PCI-E.",
          "Названия могут отличаться: Wake on LAN, Power On By PCI-E, Resume by LAN. Это примеры, а не универсальные пункты.",
          "Перед изменением запишите прежнее значение. Проверьте поддерживаемые состояния питания."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Не меняйте неизвестные BIOS-параметры и реестр ради WoL. NEXUS не входит в BIOS и не меняет настройки."
      }
    ],
    "related": [
      "wol/power-states"
    ],
    "sources": [
      "dell"
    ]
  },
  {
    "id": "wol/adapter",
    "sectionId": "wol",
    "title": "Сетевой адаптер Windows",
    "description": "Параметры WoL задаются драйвером Ethernet.",
    "keywords": [],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Диспетчер устройств → Сетевые адаптеры → нужный Ethernet → Свойства.",
          "Во вкладке «Дополнительно» проверьте поддерживаемые параметры Wake on Magic Packet / Wake-on-LAN; имена зависят от драйвера.",
          "Если есть «Управление электропитанием», проверьте разрешение пробуждать компьютер и ограничение Magic Packet согласно руководству модели."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Вкладки могут отсутствовать, в том числе на системах Modern Standby. Не считайте отсутствие опции ошибкой NEXUS; проверьте драйвер и документацию оборудования."
      }
    ],
    "related": [
      "wol/bios",
      "wol/power-states"
    ],
    "sources": [
      "dell"
    ]
  },
  {
    "id": "wol/power-states",
    "sectionId": "wol",
    "title": "Сон / выключение и WoL",
    "description": "Поддержка различается между сном, гибернацией и выключением.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "В Windows 10 WoL обычно поддерживается из сна и явно запрошенной гибернации. Гибридное выключение Fast Startup имеет другие ограничения. Прошивка может поддерживать отдельные сценарии выключения; Windows 11 и Modern Standby проверяйте по руководству модели."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Не обещаем пробуждение любого ПК. Начните со сна при подключённом питании и Ethernet. Не отключайте Fast Startup автоматически или без необходимости."
      }
    ],
    "related": [
      "wol/packet-sent",
      "troubleshooting/wol"
    ],
    "sources": [
      "wol",
      "dell"
    ]
  },
  {
    "id": "wol/packet-sent",
    "sectionId": "wol",
    "title": "Magic Packet отправлен, но ПК не включился",
    "description": "Отправка пакета и фактическое пробуждение — разные события.",
    "keywords": [
      "не включается"
    ],
    "blocks": [
      {
        "type": "steps",
        "items": [
          "Проверьте питание и Ethernet-кабель, MAC и broadcast.",
          "Проверьте BIOS, драйвер и поддержку текущего состояния питания.",
          "После пробуждения дождитесь загрузки RDP / SSH. Сетевая доступность может появиться позже."
        ]
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "NEXUS не получает аппаратное подтверждение WoL. Повторная отправка не исправляет неподдерживаемое оборудование."
      }
    ],
    "related": [
      "troubleshooting/wol"
    ],
    "sources": []
  },
  {
    "id": "wol/internet",
    "sectionId": "wol",
    "title": "Почему WoL через интернет может не работать",
    "description": "Обычная широковещательная рассылка обычно остаётся в локальной сети.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "NAT, firewall и маршрутизаторы могут не пропускать broadcast. VPN тоже не обязан переносить Ethernet-broadcast. Remote IP в карточке не делает WoL доступным через интернет."
      },
      {
        "type": "callout",
        "title": "Важно",
        "text": "Для удалённого пробуждения нужен поддерживаемый механизм вашей сети. Не открывайте порты публично наугад. Сначала подтвердите локальный WoL."
      }
    ],
    "related": [
      "security/vpn",
      "wol/broadcast-address"
    ],
    "sources": []
  }
];
