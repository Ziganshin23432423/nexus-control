import type { GuideArticle } from "../types.js";
export const articles: readonly GuideArticle[] = [
  {
    "id": "security/no-passwords",
    "sectionId": "security",
    "title": "Почему NEXUS не хранит пароль",
    "description": "Настройки содержат адреса и username, а не пароль.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Вводите секреты только в стандартном RDP-клиенте или SSH-консоли. Не добавляйте пароли в заметки, название или другие текстовые поля."
      }
    ],
    "related": [
      "security/host-key"
    ],
    "sources": []
  },
  {
    "id": "security/rdp-password",
    "sectionId": "security",
    "title": "Где вводить RDP-пароль",
    "description": "Учётные данные запрашивает стандартный клиент Windows.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Windows использует свои механизмы учётных данных. NEXUS не получает и не сохраняет пароль. PIN Windows Hello не является обычным паролем учётной записи."
      }
    ],
    "related": [
      "security/no-passwords"
    ],
    "sources": []
  },
  {
    "id": "security/ssh-password",
    "sectionId": "security",
    "title": "Где вводить SSH-пароль",
    "description": "Пароль запрашивает OpenSSH внутри открытой консоли.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "При вводе символы могут не отображаться. Username в карточке — только имя учётной записи. Guide не читает SSH-сессию."
      }
    ],
    "related": [
      "security/no-passwords"
    ],
    "sources": []
  },
  {
    "id": "security/host-key",
    "sectionId": "security",
    "title": "SSH host key",
    "description": "Ключ сервера помогает убедиться, что вы подключаетесь к нужному компьютеру.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "При первом подключении сверяйте fingerprint с доверенным значением целевого ПК. Не подтверждайте незнакомый или изменившийся ключ автоматически; изменение может означать переустановку или подмену сервера."
      }
    ],
    "related": [
      "security/no-passwords"
    ],
    "sources": [
      "keys"
    ]
  },
  {
    "id": "security/ssh-keys",
    "sectionId": "security",
    "title": "SSH keys: кратко",
    "description": "Ключевая аутентификация использует пару публичного и приватного ключей.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Публичный ключ разрешают на сервере. Приватный ключ храните только на своём клиенте и защищайте. NEXUS пока не управляет ключами и не получает их содержимое."
      }
    ],
    "related": [
      "security/no-passwords"
    ],
    "sources": [
      "keys"
    ]
  },
  {
    "id": "security/public-rdp",
    "sectionId": "security",
    "title": "Почему не стоит открывать RDP в интернет",
    "description": "Прямой публичный RDP увеличивает поверхность атак.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Предпочтителен настроенный защищённый VPN / шлюз с подходящим контролем доступа. NEXUS не создаёт VPN и не меняет роутер. Не пробрасывайте TCP 3389 без понимания защиты."
      }
    ],
    "related": [
      "security/no-passwords"
    ],
    "sources": [
      "outside"
    ]
  },
  {
    "id": "security/vpn",
    "sectionId": "security",
    "title": "VPN в контексте NEXUS",
    "description": "VPN даёт защищённый маршрут к своей удалённой сети.",
    "keywords": [],
    "blocks": [
      {
        "type": "paragraph",
        "text": "Настройте его отдельно, затем сохраните адрес цели. Доступ к TCP-службам через VPN не гарантирует прохождение WoL broadcast."
      }
    ],
    "related": [
      "security/no-passwords"
    ],
    "sources": []
  }
];
