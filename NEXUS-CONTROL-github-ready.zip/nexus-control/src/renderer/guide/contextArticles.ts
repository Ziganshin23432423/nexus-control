import type { GuideArticleId } from './ids.js';
export const FIELD_GUIDE_ARTICLES: Readonly<Partial<Record<string,GuideArticleId>>> = {hostname:'connection/hostname',localAddress:'connection/local-address',remoteAddress:'connection/remote-address',macAddress:'wol/mac-address',username:'connection/username',broadcastAddress:'wol/broadcast-address',port:'wol/port-9'};
