import { useState } from 'react';
import { guideCommandText } from './commands';
import type { GuideCommandId } from './types';
export function GuideCommand({commandId}:{commandId:GuideCommandId}):React.JSX.Element {const [message,setMessage]=useState('');async function copy():Promise<void>{try{await navigator.clipboard.writeText(guideCommandText(commandId));setMessage('Скопировано');}catch{setMessage('Выделите команду и нажмите Ctrl+C.');}}return <div className="guide-command"><div><code>{guideCommandText(commandId)}</code><button className="text-button" type="button" onClick={()=>void copy()}>Копировать</button></div><small>Только текст. Выполните вручную на указанном ПК.</small><span role="status">{message}</span></div>;}
