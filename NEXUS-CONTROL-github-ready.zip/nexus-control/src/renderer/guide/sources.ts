export const GUIDE_SOURCES: Readonly<Record<string,{readonly title:string;readonly url:string;readonly checkedAt:string}>> = {
  "rdp": {
    "title": "Microsoft: Remote Desktop",
    "url": "https://learn.microsoft.com/en-us/windows-server/remote/remote-desktop-services/remotepc/remote-desktop-allow-access",
    "checkedAt": "2026-10-01"
  },
  "openssh": {
    "title": "Microsoft: OpenSSH",
    "url": "https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_install_firstuse",
    "checkedAt": "2026-10-01"
  },
  "wol": {
    "title": "Microsoft: WoL и питание",
    "url": "https://learn.microsoft.com/en-us/troubleshoot/windows-client/setup-upgrade-and-drivers/wake-on-lan-feature",
    "checkedAt": "2026-10-01"
  },
  "dell": {
    "title": "Dell: WoL — аппаратные ограничения",
    "url": "https://www.dell.com/support/kbdoc/en-us/000129137/wake-on-lan-wol-troubleshooting-best-practices",
    "checkedAt": "2026-10-01"
  },
  "ipconfig": {
    "title": "Microsoft: ipconfig",
    "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/ipconfig",
    "checkedAt": "2026-10-01"
  },
  "hostname": {
    "title": "Microsoft: hostname",
    "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/hostname",
    "checkedAt": "2026-10-01"
  },
  "whoami": {
    "title": "Microsoft: whoami",
    "url": "https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/whoami",
    "checkedAt": "2026-10-01"
  },
  "keys": {
    "title": "Microsoft: SSH keys",
    "url": "https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh_keymanagement",
    "checkedAt": "2026-10-01"
  },
  "outside": {
    "title": "Microsoft: удалённый доступ извне",
    "url": "https://learn.microsoft.com/en-us/windows-server/remote/remote-desktop-services/remotepc/remote-desktop-allow-outside-access",
    "checkedAt": "2026-10-01"
  },
  "terminal": {
    "title": "Microsoft: Windows Terminal SSH",
    "url": "https://learn.microsoft.com/en-us/windows/terminal/tutorials/ssh",
    "checkedAt": "2026-10-01"
  }
};
