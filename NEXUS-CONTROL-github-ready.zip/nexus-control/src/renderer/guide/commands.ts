import type { GuideCommandId } from './types.js';
export const GUIDE_COMMANDS = Object.freeze({ hostname: 'hostname', ipconfig: 'ipconfig', ipconfigAll: 'ipconfig /all', whoami: 'whoami' });
export function guideCommandText(id: GuideCommandId): string { if (!Object.hasOwn(GUIDE_COMMANDS,id)) throw new Error('Unknown static command'); return GUIDE_COMMANDS[id]; }
