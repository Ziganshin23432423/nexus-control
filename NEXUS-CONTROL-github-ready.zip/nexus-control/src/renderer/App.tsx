import { AppearanceDialog } from './appearance/AppearanceDialog';
import { GuideContext } from './guide/context';
import { GuidePage } from './guide/GuidePage';
import { GuideDialog } from './guide/GuideDialog';
import type { GuideArticleId } from './guide/ids';
import { setUxAppVersion } from './state/notifyError';
import { useWakeAndConnect } from './hooks/useWakeAndConnect';
import { useWakeComputer } from './hooks/useWakeComputer';
import { useSshTerminal } from './hooks/useSshTerminal';
import { useEffect, useRef, useState } from 'react';
import type { Computer, ComputerDraft, IpcResult } from '../shared/types';
import { AppFooter } from './components/AppFooter';
import { AppHeader } from './components/AppHeader';
import { ComputerFormDialog } from './components/ComputerFormDialog';
import { DeleteComputerDialog } from './components/DeleteComputerDialog';
import { SplashScreen } from './components/SplashScreen';
import { Toasts } from './components/Toasts';
import { useRemoteDesktop } from './hooks/useRemoteDesktop';
import { performComputerAction } from './state/computerActions';
import type { DemoAction } from './state/demoTypes';
import { useAppInfo } from './hooks/useAppInfo';
import { useDemoComputers } from './hooks/useDemoComputers';
import { useConnectionStatuses } from './hooks/useConnectionStatuses';
import { useUserComputers } from './hooks/useUserComputers';
import { useToasts } from './hooks/useToasts';
import { ComputerPage } from './pages/ComputerPage';
import { ComputersPage } from './pages/ComputersPage';
import { unverifiedStatus } from './state/computerStatus';
import type { DataSource } from './state/computerStatus';

export function App(): React.JSX.Element {
  const { info, error, retry } = useAppInfo();
  const { toasts, notify, dismiss } = useToasts();
  const demo = useDemoComputers(notify);
  const user = useUserComputers(notify);
  const [appearanceOpen, setAppearanceOpen] = useState(false);
  const [source, setSource] = useState<DataSource>('user');
  const demoOnly = source !== 'user';
  const rdp = useRemoteDesktop(!demoOnly, notify);
  const workflow = useWakeAndConnect(!demoOnly, notify);
  const wake = useWakeComputer(!demoOnly, notify);
  const ssh = useSshTerminal(!demoOnly, notify);
  const network = useConnectionStatuses(user.computers, !demoOnly && !user.loading && !user.error);
  const [guideOpen,setGuideOpen]=useState(false);
  const [guideArticleId,setGuideArticleId]=useState<GuideArticleId|null>(null);
  const [contextArticleId,setContextArticleId]=useState<GuideArticleId|null>(null);
  function openGuide(id?:GuideArticleId):void {setGuideArticleId(id??null);setGuideOpen(true);}
  function home():void {setGuideOpen(false);setComputerId(null);}
  const [started, setStarted] = useState(false);
  const [computerId, setComputerId] = useState<string | null>(null);
  const [formTarget, setFormTarget] = useState<Computer | 'new' | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Computer | null>(null);
  const pageRef = useRef<HTMLElement>(null);
  const computers = demoOnly ? demo.computers : user.computers;
  const statuses = demoOnly ? demo.statuses : network.statuses;
  const selected = computers.find((computer) => computer.id === computerId);
  useEffect(() => { if (!info) return; setUxAppVersion(info.version); const timer = window.setTimeout(() => setStarted(true), 650); return () => window.clearTimeout(timer); }, [info]);
  useEffect(() => { if (!started) return; pageRef.current?.scrollTo({ top: 0 }); pageRef.current?.querySelector<HTMLElement>(guideOpen&&guideArticleId===null?'input[type=search]':'h1')?.focus({ preventScroll: true }); }, [computerId, started, source, guideOpen]);
  function switchSource(next: DataSource): void {
    toasts.forEach(toast=>dismiss(toast.id));
    setComputerId(null); setFormTarget(null); setDeleteTarget(null);
    demo.switchScenario(next === 'demo-empty' ? 'empty' : 'computers'); setSource(next);
  }
  function action(computer: Computer, requested: DemoAction): void {
    performComputerAction(demoOnly, computer, requested, demo.performAction, (id) => { void rdp.open(id); }, (id) => { void ssh.open(id); }, (id) => { void wake.wake(id); }, (id) => { void workflow.start(id, 'rdp'); }, (id) => { void workflow.start(id, 'ssh'); });
  }
  async function save(draft: ComputerDraft): Promise<IpcResult<Computer>> {
    let result: IpcResult<Computer>;
    if (demoOnly) {
      const existing = formTarget !== 'new' ? formTarget : null;
      const now = new Date().toISOString();
      const computer: Computer = { ...draft, id: existing?.id ?? crypto.randomUUID(), createdAt: existing?.createdAt ?? now, updatedAt: now };
      demo.saveComputer(computer); result = { ok: true, value: computer };
    } else result = await user.save(draft, formTarget !== 'new' ? formTarget?.id ?? null : null);
    if (result.ok) { setFormTarget(null); window.requestAnimationFrame(() => pageRef.current?.querySelector<HTMLElement>('h1')?.focus()); }
    return result;
  }
  async function remove(): Promise<IpcResult<null>> {
    if (!deleteTarget) return { ok: true, value: null };
    const result = demoOnly ? (demo.deleteComputer(deleteTarget.id), { ok: true as const, value: null }) : await user.remove(deleteTarget.id);
    if (result.ok) { setDeleteTarget(null); setComputerId(null); }
    return result;
  }
  if ((!started || !info) && !guideOpen) return <div className="app-shell app-boot"><AppHeader onHome={home} onAppearance={()=>setAppearanceOpen(true)} onGuide={()=>openGuide()} guideOpen={guideOpen} /><SplashScreen error={error} onRetry={retry} /><footer className="boot-footer">NEXUS CONTROL</footer>{appearanceOpen&&<AppearanceDialog onClose={()=>setAppearanceOpen(false)}/>}</div>;
  return <GuideContext.Provider value={{open:openGuide,openOverlay:setContextArticleId}}><div className="app-shell"><AppHeader onHome={home} onAppearance={()=>setAppearanceOpen(true)} onGuide={()=>openGuide()} guideOpen={guideOpen} /><main className="main-scroll" ref={pageRef}>
    {!guideOpen && !demoOnly && network.notice && <p className="network-error" role="status">{network.notice}</p>}
    {!guideOpen && !demoOnly && network.error && <p className="network-error" role="alert">{network.error} <button className="text-button" disabled={network.isChecking} onClick={network.refresh}>Повторить проверку</button></p>}
    {guideOpen ? <GuidePage initialArticleId={guideArticleId} onClose={home}/> : !demoOnly && (user.loading || user.error) ? <section className="page storage-state" role={user.error ? 'alert' : 'status'}><h1 tabIndex={-1}>{user.error ? 'Настройки не удалось открыть' : 'Загружаем компьютеры…'}</h1>{user.error && <><p>{user.error}</p><p>Файл не очищен. Можно исправить настройки и повторить загрузку или открыть демо.</p><button className="button button-secondary" onClick={() => void user.reload()}>Повторить загрузку</button></>}</section>
    : selected ? <ComputerPage workflow={workflow.jobs[selected.id]} wakePending={wake.pendingIds[selected.id] ?? false} sshPending={ssh.pendingIds[selected.id] ?? false} rdpPending={rdp.pendingIds[selected.id] ?? false} demoOnly={demoOnly} computer={selected} status={statuses[selected.id] ?? unverifiedStatus(selected)} job={demoOnly ? demo.jobs[selected.id] : undefined} checking={network.isChecking} onCheck={() => network.checkOne(selected)} onBack={() => setComputerId(null)} onEdit={() => setFormTarget(selected)} onDelete={() => setDeleteTarget(selected)} onAction={(requested) => action(selected, requested)} onCancel={() => { if (demoOnly) demo.cancelJob(selected.id); else void workflow.cancel(selected.id); }} />
    : <ComputersPage workflows={workflow.jobs} wakePendingIds={wake.pendingIds} sshPendingIds={ssh.pendingIds} rdpPendingIds={rdp.pendingIds} demoOnly={demoOnly} computers={computers} statuses={statuses} jobs={demoOnly ? demo.jobs : {}} isBusy={demoOnly ? demo.isBusy : user.busy} isChecking={!demoOnly && network.isChecking} onCancelCheck={network.cancel} onAdd={() => setFormTarget('new')} onOpen={setComputerId} onCheck={() => { if (demoOnly) demo.checkAll(); else network.refresh(); }} onAction={action} onCancel={id => { if (demoOnly) demo.cancelJob(id); else void workflow.cancel(id); }} />}
  </main><AppFooter info={info??{name:"NEXUS CONTROL",version:"0.1.0",mode:"production",platform:"unsupported"}} source={source} disabled={user.busy || rdp.isBusy || ssh.isBusy || wake.isBusy || workflow.isBusy} onSource={switchSource} /><Toasts messages={toasts} onDismiss={dismiss} onGuide={openGuide} />
  {appearanceOpen&&<AppearanceDialog onClose={()=>setAppearanceOpen(false)}/>}
  {formTarget !== null && <ComputerFormDialog demoOnly={demoOnly} computer={formTarget === 'new' ? null : formTarget} onClose={() => setFormTarget(null)} onSave={save} />}
  {deleteTarget && <DeleteComputerDialog computer={deleteTarget} demoOnly={demoOnly} onClose={() => setDeleteTarget(null)} onDelete={remove} />}{contextArticleId&&<GuideDialog articleId={contextArticleId} onClose={()=>setContextArticleId(null)}/>}</div></GuideContext.Provider>;
}
