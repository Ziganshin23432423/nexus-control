import type { GuideArticleId } from '../guide/ids.js';
import type { ConnectionCheckResult } from '../../shared/types.js';

export type DemoScenario = 'computers' | 'empty';
export type DemoAction = 'rdp' | 'ssh' | 'wake' | 'wake-rdp' | 'wake-ssh';

export interface DemoJob {
  readonly action: DemoAction | 'check';
  readonly previousStatus: ConnectionCheckResult;
}

export interface ToastMessage {
  readonly id: string;
  readonly title: string;
  readonly description: string;
  readonly options?: ToastOptions | undefined;
  readonly kind: 'success' | 'info' | 'warning' | 'error';
}

export interface ToastOptions { readonly guideArticleId?: GuideArticleId | undefined; readonly retry?: (() => void) | undefined; readonly details?: string | undefined }

export type Notify = (title: string, description: string, kind?: ToastMessage['kind'], options?: ToastOptions) => void;
