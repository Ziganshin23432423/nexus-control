import type { IpcErrorCode } from '../../shared/types.js';
import type { Notify } from './demoTypes.js';
import { presentError, safeTechnicalDetails } from './operationUx.js';
let appVersion = '';
export function setUxAppVersion(version: string): void { appVersion = version; }
export function notifyError(notify: Notify, code: IpcErrorCode, retry?: () => void, service?: 'rdp' | 'ssh' | 'wol'): void {
  const ux = presentError(code);
  // Build-time application version, no privileged lookup or config exposure.
  notify(ux.title, ux.description, ux.phase === 'cancelled' ? 'info' : ux.phase === 'timeout' ? 'warning' : 'error', {
    guideArticleId: ux.guideArticleId,
    retry: ux.retry ? retry : undefined,
    details: safeTechnicalDetails({code, ...(service ? {service} : {}), timestamp: new Date().toISOString(), version: appVersion}),
  });
}
