import type { Computer, IpcErrorCode, WakeAndConnectProgress } from '../../shared/types.js';
import { ERROR_GUIDE_ARTICLES } from '../guide/errorArticles.js';
import type { GuideArticleId } from '../guide/ids.js';
export type OperationPhase = 'idle' | 'checking' | 'sending' | 'waiting' | 'launching' | 'success' | 'cancelled' | 'timeout' | 'error';
export interface ErrorPresentation { readonly title: string; readonly description: string; readonly retry: boolean; readonly phase: OperationPhase;readonly guideArticleId?:GuideArticleId | undefined }
const entry = (title: string, description: string, retry = false, phase: OperationPhase = 'error'): ErrorPresentation => ({title, description, retry, phase});
export const ERROR_PRESENTATIONS: Readonly<Record<IpcErrorCode, ErrorPresentation>> = {
  RDP_UNAVAILABLE: entry('RDP не отвечает', 'Проверьте, включён ли компьютер и разрешён ли удалённый рабочий стол.', true),
  SSH_UNAVAILABLE: entry('SSH не отвечает', 'Проверьте, включён ли компьютер и запущена ли служба OpenSSH Server.', true),
  RDP_CLIENT_MISSING: entry('RDP-клиент не найден', 'Проверьте наличие стандартного клиента удалённого рабочего стола Windows.'),
  SSH_CLIENT_MISSING: entry('OpenSSH Client не найден', 'Установите стандартный компонент OpenSSH Client в Windows.'),
  SSH_HOST_MISSING: entry('Консоль Windows не найдена', 'Проверьте наличие Windows Terminal или стандартного Console Host.'),
  RDP_LAUNCH_ERROR: entry('Не удалось открыть RDP-клиент', 'Проверьте стандартный клиент Windows и повторите попытку.', true),
  SSH_LAUNCH_ERROR: entry('Не удалось открыть SSH-терминал', 'Проверьте стандартный OpenSSH Client и повторите попытку.', true),
  WOL_SEND_ERROR: entry('Не удалось отправить Magic Packet', 'Проверьте сетевое подключение и адрес рассылки Wake-on-LAN.', true),
  WOL_TIMEOUT: entry('Отправка сигнала заняла слишком много времени', 'Проверьте сеть. Отправка части пакетов возможна; повтор выполняется только по вашему нажатию.', true, 'timeout'),
  WAKE_CONNECT_TIMEOUT: entry('Компьютер не стал доступен', 'Сигнал включения был отправлен, но служба не ответила за 90 секунд.', true, 'timeout'),
  CANCELLED: entry('Ожидание отменено. Уже отправленный сигнал включения отменить нельзя.', 'Операция остановлена. Открытая сессия не закрывается.', false, 'cancelled'),
  NETWORK_ERROR: entry('Не удалось проверить доступность', 'Проверьте сеть и повторите проверку.', true),
  STORAGE_ERROR: entry('Настройки не удалось открыть', 'Файл не очищен. Повторите загрузку или откройте демо.', true),
  VALIDATION_ERROR: entry('Проверьте настройки компьютера', 'Исправьте отмеченные поля и сохраните настройки.'),
  NOT_FOUND: entry('Компьютер не найден', 'Карточка была удалена. Вернитесь к списку компьютеров.'),
  LIMIT_REACHED: entry('Достигнут лимит компьютеров', 'Удалите ненужную карточку перед добавлением новой.'),
  RDP_DISABLED: entry('RDP не настроен', 'Включите RDP в настройках карточки.'),
  SSH_DISABLED: entry('SSH не настроен', 'Включите SSH и укажите имя пользователя в настройках карточки.'),
  WOL_DISABLED: entry('Wake-on-LAN не настроен', 'Укажите MAC-адрес и параметры рассылки в настройках карточки.'),
  RDP_BUSY: entry('Подключение уже выполняется', 'Дождитесь завершения операции для этого компьютера.'),
  SSH_BUSY: entry('Подключение уже выполняется', 'Дождитесь завершения операции для этого компьютера.'),
  WOL_BUSY: entry('Сигнал уже отправляется', 'Дождитесь завершения операции для этого компьютера.'),
  WAKE_CONNECT_BUSY: entry('Подключение уже выполняется', 'Дождитесь завершения или отмените ожидание для этого компьютера.'),
  RDP_UNSUPPORTED: entry('RDP недоступен на этой платформе', 'Запуск стандартного RDP-клиента сейчас поддерживается только в Windows.'),
  SSH_UNSUPPORTED: entry('SSH недоступен на этой платформе', 'Запуск стандартного SSH-клиента сейчас поддерживается только в Windows.'),
  WOL_UNSUPPORTED: entry('Wake-on-LAN недоступен на этой платформе', 'Отправка сигнала сейчас поддерживается только в Windows.'),
  WAKE_CONNECT_UNSUPPORTED: entry('Включение с подключением недоступно', 'Этот сценарий сейчас поддерживается только в Windows.'),
};
export function presentError(code: IpcErrorCode): ErrorPresentation { const ux=(Object.hasOwn(ERROR_PRESENTATIONS, code) ? ERROR_PRESENTATIONS[code] : undefined) ?? entry('Операция не завершена', 'Повторите попытку.', true);return {...ux,guideArticleId:Object.hasOwn(ERROR_GUIDE_ARTICLES,code)?ERROR_GUIDE_ARTICLES[code]:undefined}; }
export const SUCCESS_TITLES = { rdp: 'RDP-клиент открыт', ssh: 'SSH-терминал открыт', wake: 'Magic Packet отправлен' } as const;
export function remainingSeconds(value: number | undefined): number | null { return value === undefined || !Number.isFinite(value) ? null : Math.min(90, Math.max(0, Math.ceil(value))); }
export function progressLabel(progress: WakeAndConnectProgress): string {
  if (progress.phase === 'sending') return 'Отправка сигнала…';
  if (progress.phase === 'launching') return 'Открываем клиент…';
  const seconds = remainingSeconds(progress.remainingSeconds);
  return `Ожидание ${progress.service.toUpperCase()}${seconds === null ? '…' : ` · ${seconds} сек`}`;
}
export function removeProgress<T>(jobs: Readonly<Record<string, T>>, id: string): Record<string, T> { const next = {...jobs}; delete next[id]; return next; }
export function capabilityActions(computer: Computer): readonly string[] {
  const wake = Boolean(computer.wakeOnLan && computer.macAddress);
  return [...(computer.rdpEnabled ? ['rdp'] : []), ...(computer.sshEnabled ? ['ssh'] : []), ...(wake ? ['wake'] : []), ...(wake && computer.rdpEnabled ? ['wake-rdp'] : []), ...(wake && computer.sshEnabled ? ['wake-ssh'] : [])];
}
/** Whitelist only; never serialise an exception/configuration/IPC reply. */
export function safeTechnicalDetails(input: { code: IpcErrorCode; service?: 'rdp' | 'ssh' | 'wol'; addressKind?: 'local' | 'remote'; timestamp: string; version: string }): string {
  const code = Object.hasOwn(ERROR_PRESENTATIONS, input.code) ? input.code : 'UNKNOWN';
  const service = ['rdp','ssh','wol'].includes(input.service ?? '') ? input.service!.toUpperCase() : '—';
  const endpoint = input.addressKind === 'local' || input.addressKind === 'remote' ? input.addressKind : '—';
  const timestamp = /^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(input.timestamp) ? input.timestamp : '—';
  const version = /^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$/.test(input.version) ? input.version : '—';
  return `Код: ${code}\nСлужба: ${service}\nТип адреса: ${endpoint}\nВремя: ${timestamp}\nВерсия: ${version}`;
}
export class ToastDeduplicator {
  private readonly seen = new Map<string, number>();
  accept(title: string, description: string, kind: string, now: number): boolean {
    for (const [key, time] of this.seen) if (now - time >= 4500) this.seen.delete(key);
    const key = JSON.stringify([title, description, kind]);
    if (this.seen.has(key)) return false;
    this.seen.set(key, now); return true;
  }
  clear(): void { this.seen.clear(); }
}
export const ERROR_FALLBACK = {title: 'Интерфейс временно недоступен', description: 'Перезапуск интерфейса не очищает локальные настройки. Перезапустите интерфейс, чтобы продолжить.', action: 'Перезапустить интерфейс'} as const;
