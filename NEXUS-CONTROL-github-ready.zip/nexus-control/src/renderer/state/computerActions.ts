import type { Computer } from '../../shared/types.js';
import type { DemoAction } from './demoTypes.js';

/** Demo actions are routed before any user/native capability is considered. */
export function performComputerAction(
  demoOnly: boolean, computer: Computer, action: DemoAction,
  demoAction: (computer: Computer, action: DemoAction) => void,
  openRemoteDesktop: (id: string) => void,
  openSshTerminal: (id: string) => void,
  wakeComputer: (id: string) => void = () => {},
  wakeAndOpenRdp: (id: string) => void = () => {},
  wakeAndOpenSsh: (id: string) => void = () => {},
): void {
  if (demoOnly) { demoAction(computer, action); return; }
  if (action === 'rdp') openRemoteDesktop(computer.id);
  if (action === 'ssh') openSshTerminal(computer.id);
  if (action === 'wake') wakeComputer(computer.id);
  if (action === 'wake-rdp') wakeAndOpenRdp(computer.id);
  if (action === 'wake-ssh') wakeAndOpenSsh(computer.id);
}
