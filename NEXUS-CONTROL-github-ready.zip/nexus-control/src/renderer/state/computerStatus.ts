import type { Computer, ConnectionCheckResult } from '../../shared/types';
export function unverifiedStatus(computer: Computer): ConnectionCheckResult {
  return { computerId: computer.id, status: computer.rdpEnabled || computer.sshEnabled ? 'unknown' : 'no-services', rdp: computer.rdpEnabled ? 'unknown' : 'disabled',
    ssh: computer.sshEnabled ? 'unknown' : 'disabled', wakeOnLan: computer.wakeOnLan ? 'configured' : 'disabled', checkedAt: null };
}
export type DataSource = 'user' | 'demo-computers' | 'demo-empty';
