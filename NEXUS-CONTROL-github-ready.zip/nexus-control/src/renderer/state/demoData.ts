import type { Computer, ComputerStatus, ConnectionCheckResult } from '../../shared/types';

const createdAt = '2026-10-01T08:00:00.000Z';

/** These fixtures use the real shared model, with no native provider calls. */
export function createDemoComputers(): Computer[] {
  return [
    {
      id: 'demo-main-pc',
      name: 'MAIN PC',
      operatingSystem: 'windows',
      hostname: 'MAIN-PC',
      localAddress: '192.168.1.10',
      remoteAddress: null,
      macAddress: 'A4:5E:60:8A:1C:10',
      username: 'alex',
      rdpEnabled: true,
      sshEnabled: true,
      wakeOnLan: { broadcastAddress: '192.168.1.255', port: 9 },
      notes: 'Основной рабочий компьютер.',
      createdAt,
      updatedAt: createdAt,
    },
    {
      id: 'demo-pc-home',
      name: 'PC HOME',
      operatingSystem: 'windows',
      hostname: 'HOME-PC',
      localAddress: '192.168.1.25',
      remoteAddress: null,
      macAddress: 'D8:BB:C1:45:6A:25',
      username: 'zigan',
      rdpEnabled: true,
      sshEnabled: true,
      wakeOnLan: { broadcastAddress: '192.168.1.255', port: 9 },
      notes: 'Домашний компьютер. Включите его перед подключением.',
      createdAt,
      updatedAt: createdAt,
    },
  ];
}

export function createDemoStatus(computer: Computer, status: ComputerStatus): ConnectionCheckResult {
  const serviceStatus = status === 'online' ? 'ready' : status === 'checking' ? 'checking' : 'unavailable';
  return {
    computerId: computer.id,
    status,
    rdp: computer.rdpEnabled ? serviceStatus : 'disabled',
    ssh: computer.sshEnabled ? serviceStatus : 'disabled',
    wakeOnLan: computer.wakeOnLan && computer.macAddress ? 'configured' : 'disabled',
    checkedAt: status === 'checking' ? null : new Date().toISOString(),
  };
}

export function createInitialStatuses(computers: readonly Computer[]): Record<string, ConnectionCheckResult> {
  return Object.fromEntries(computers.map((computer) => [
    computer.id,
    createDemoStatus(computer, computer.id === 'demo-main-pc' ? 'online' : 'offline'),
  ]));
}
