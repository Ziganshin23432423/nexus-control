import type { Computer, ConnectionCheckResult } from '../../shared/types.js';
/** Pure generation gate, also used by renderer tests with out-of-order promises. */
export class StatusRequests {
  private generation = 0;
  begin(): number { return ++this.generation; }
  invalidate(): void { this.generation++; }
  isCurrent(request: number): boolean { return request === this.generation; }
  canApply(request: number, snapshot: readonly Computer[], current: readonly Computer[], results: readonly ConnectionCheckResult[], targets: readonly Computer[] = snapshot): boolean {
    return this.isCurrent(request) && snapshot === current && results.length === targets.length && new Set(results.map(result => result.computerId)).size === targets.length && results.every((result) => {
      const computer = targets.find(item => item.id === result.computerId);
      if (!computer || computer.updatedAt !== result.configUpdatedAt) return false;
      if (computer.rdpEnabled ? !['ready','unavailable'].includes(result.rdp) : result.rdp !== 'disabled') return false;
      if (computer.sshEnabled ? !['ready','unavailable'].includes(result.ssh) : result.ssh !== 'disabled') return false;
      const expected = result.rdp === 'ready' || result.ssh === 'ready' ? 'online' : computer.rdpEnabled || computer.sshEnabled ? 'offline' : 'no-services';
      return result.status === expected;
    });
  }
}
