import type { MotionProfile } from './preferences.js';
export interface Star {readonly x:number;readonly y:number;readonly layer:0|1|2;readonly radius:number;readonly alpha:number;readonly phase:number}
export function starCount(width:number,height:number):number{return Math.min(220,Math.max(70,Math.round(Math.max(1,width)*Math.max(1,height)/4400)));}
export function cappedPixelRatio(ratio:number):number{return Number.isFinite(ratio)?Math.max(1,Math.min(1.5,ratio)):1;}
export function normalizedPointer(x:number,y:number,width:number,height:number):readonly[number,number]{return [Math.max(-1,Math.min(1,2*x/Math.max(1,width)-1)),Math.max(-1,Math.min(1,2*y/Math.max(1,height)-1))];}
export function createStars(count:number,seed=1951):readonly Star[]{let state=seed>>>0;const rand=():number=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};return Array.from({length:Math.max(0,Math.min(220,Math.floor(count)))},()=>{const depth=rand();const layer=depth<.66?0:depth<.93?1:2;return {x:rand(),y:rand(),layer,radius:[.45,.65,.85][layer]!+rand()*.2,alpha:[.20,.34,.53][layer]!+rand()*.17,phase:rand()*Math.PI*2};});}
export interface StarfieldFrame {readonly stars:readonly Star[];readonly width:number;readonly height:number;readonly time:number;readonly pointer:readonly[number,number];readonly profile:MotionProfile}
export interface StarfieldSurface {resize(width:number,height:number,dpr:number):void;draw(frame:StarfieldFrame):void;activity(state:'running'|'paused'|'static'|'stopped'):void}
export interface StarfieldHost {now():number;requestFrame(callback:(time:number)=>void):number;cancelFrame(id:number):void;hidden():boolean;size():readonly[number,number,number];onPointer(callback:(x:number,y:number)=>void):()=>void;onVisibility(callback:()=>void):()=>void;onResize(callback:()=>void):()=>void}
/** One owned RAF, refs/plain state only. No React updates in pointer/animation paths. */
export class StarfieldEngine {
 private frame:number|null=null;private running=false;private lastTime=0;private lastDraw=0;private time=0;private width=1;private height=1;private stars:readonly Star[]=[];private target:readonly[number,number]=[0,0];private pointer:readonly[number,number]=[0,0];private cleanups:(()=>void)[]=[];
 constructor(private readonly profile:MotionProfile,private readonly host:StarfieldHost,private readonly surface:StarfieldSurface){}
 start():void{if(this.running)return;this.running=true;this.resize();this.cleanups=[this.host.onResize(()=>this.resize()),this.host.onVisibility(()=>this.visibility())];if(this.profile.animated)this.cleanups.push(this.host.onPointer((x,y)=>{this.target=normalizedPointer(x,y,this.width,this.height);}));this.visibility();}
 stop():void{this.running=false;this.cancel();for(const cleanup of this.cleanups)cleanup();this.cleanups=[];this.surface.activity('stopped');}
 private cancel():void{if(this.frame!==null)this.host.cancelFrame(this.frame);this.frame=null;}
 private resize():void{if(!this.running)return;const [width,height,ratio]=this.host.size();this.width=Math.max(1,width);this.height=Math.max(1,height);this.stars=createStars(starCount(this.width,this.height));this.surface.resize(this.width,this.height,cappedPixelRatio(ratio));this.draw();}
 private draw():void{this.surface.draw({stars:this.stars,width:this.width,height:this.height,time:this.time,pointer:this.pointer,profile:this.profile});}
 private visibility():void{this.cancel();if(!this.running)return;if(!this.profile.animated){this.surface.activity('static');return;}if(this.host.hidden()){this.surface.activity('paused');return;}this.lastTime=this.host.now();this.lastDraw=this.lastTime;this.surface.activity('running');this.schedule();}
 private schedule():void{if(this.running&&this.profile.animated&&!this.host.hidden()&&this.frame===null)this.frame=this.host.requestFrame(time=>this.tick(time));}
 private tick(timestamp:number):void{this.frame=null;if(!this.running||this.host.hidden())return;const dt=Math.max(0,Math.min(100,timestamp-this.lastTime));this.lastTime=timestamp;this.time+=dt/1000;const factor=1-Math.exp(-dt/180);this.pointer=[this.pointer[0]+(this.target[0]-this.pointer[0])*factor,this.pointer[1]+(this.target[1]-this.pointer[1])*factor];if(timestamp-this.lastDraw>=1000/this.profile.fps){this.lastDraw=timestamp;this.draw();}this.schedule();}
}
