export type EffectsMode = 'full' | 'calm' | 'minimal';
export type DensityMode = 'normal' | 'compact';
export interface AppearancePreferences { readonly effects: EffectsMode; readonly density: DensityMode }
export const APPEARANCE_KEY = 'nexus.appearance.v1';
export const DEFAULT_APPEARANCE: AppearancePreferences = Object.freeze({effects:'full',density:'normal'});
export const EFFECTS_OPTIONS = [
 {value:'full',title:'Полные',description:'Живой фон, мягкий параллакс и переходы.'},
 {value:'calm',title:'Спокойные',description:'Меньше движения. Тот же характер NEXUS.'},
 {value:'minimal',title:'Минимальные',description:'Статичный фон и короткие переходы.'},
] as const;
export const DENSITY_OPTIONS = [{value:'normal',title:'Обычная',description:'Комфортные отступы.'},{value:'compact',title:'Компактная',description:'Больше машин на экране.'}] as const;
export function validateAppearance(value: unknown): AppearancePreferences {
 if(!value||typeof value!=='object'||Array.isArray(value)) return DEFAULT_APPEARANCE;
 const input=value as Record<string,unknown>;
 if(Object.keys(input).length!==2||!Object.hasOwn(input,'effects')||!Object.hasOwn(input,'density')||typeof input['effects']!=='string'||typeof input['density']!=='string'||!['full','calm','minimal'].includes(input['effects'])||!['normal','compact'].includes(input['density']))return DEFAULT_APPEARANCE;
 return {effects:input['effects'] as EffectsMode,density:input['density'] as DensityMode};
}
export interface AppearanceStorage { getItem(key:string):string|null;setItem(key:string,value:string):void;removeItem(key:string):void }
export function readAppearance(storage:AppearanceStorage):AppearancePreferences {try{const text=storage.getItem(APPEARANCE_KEY);return text===null?DEFAULT_APPEARANCE:validateAppearance(JSON.parse(text) as unknown);}catch{return DEFAULT_APPEARANCE;}}
export function saveAppearance(storage:AppearanceStorage,value:AppearancePreferences):boolean{try{storage.setItem(APPEARANCE_KEY,JSON.stringify(validateAppearance(value)));return true;}catch{return false;}}
export function resetAppearance(storage:AppearanceStorage):boolean{try{storage.removeItem(APPEARANCE_KEY);return true;}catch{return false;}}
export function effectiveEffects(effects:EffectsMode,reducedMotion:boolean):EffectsMode{return reducedMotion?'minimal':effects;}
export interface MotionProfile {readonly animated:boolean;readonly fps:number;readonly parallax:readonly [number,number,number];readonly drift:number;readonly twinkle:number}
export function motionProfile(mode:EffectsMode):MotionProfile{switch(mode){case 'full':return {animated:true,fps:30,parallax:[4,11,22],drift:1,twinkle:.10};case 'calm':return {animated:true,fps:20,parallax:[.6,1.5,2.5],drift:.22,twinkle:.025};case 'minimal':return {animated:false,fps:0,parallax:[0,0,0],drift:0,twinkle:0};}}
