import { createContext,useContext,useEffect,useLayoutEffect,useState } from 'react';
import type { ReactNode } from 'react';
import { DEFAULT_APPEARANCE,effectiveEffects,readAppearance,resetAppearance,saveAppearance,validateAppearance } from './preferences';
import type { AppearancePreferences,EffectsMode } from './preferences';
interface AppearanceContextValue { readonly preferences:AppearancePreferences;readonly effectiveMode:EffectsMode;readonly reducedMotion:boolean;readonly persisted:boolean;update(value:AppearancePreferences):void;reset():void }
const Context=createContext<AppearanceContextValue>({preferences:DEFAULT_APPEARANCE,effectiveMode:'full',reducedMotion:false,persisted:true,update:()=>{},reset:()=>{}});
export function useAppearance():AppearanceContextValue{return useContext(Context);}
export function AppearanceProvider({children}:{children:ReactNode}):React.JSX.Element{
 const [preferences,setPreferences]=useState(()=>{try{return readAppearance(window.localStorage);}catch{return DEFAULT_APPEARANCE;}});
 const [reducedMotion,setReducedMotion]=useState(()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches);
 const [persisted,setPersisted]=useState(true);const effectiveMode=effectiveEffects(preferences.effects,reducedMotion);
 useEffect(()=>{const media=window.matchMedia('(prefers-reduced-motion: reduce)');const changed=()=>setReducedMotion(media.matches);media.addEventListener('change',changed);changed();return()=>media.removeEventListener('change',changed);},[]);
 useLayoutEffect(()=>{document.documentElement.dataset['effects']=effectiveMode;document.documentElement.dataset['density']=preferences.density;return()=>{delete document.documentElement.dataset['effects'];delete document.documentElement.dataset['density'];};},[effectiveMode,preferences.density]);
 function update(value:AppearancePreferences):void{const next=validateAppearance(value);setPreferences(next);try{setPersisted(saveAppearance(window.localStorage,next));}catch{setPersisted(false);}}
 function reset():void{setPreferences(DEFAULT_APPEARANCE);try{setPersisted(resetAppearance(window.localStorage));}catch{setPersisted(false);}}
 return <Context.Provider value={{preferences,effectiveMode,reducedMotion,persisted,update,reset}}>{children}</Context.Provider>;
}
