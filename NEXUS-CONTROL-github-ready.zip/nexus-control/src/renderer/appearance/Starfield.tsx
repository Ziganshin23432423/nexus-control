import { useEffect,useRef } from 'react';
import { useAppearance } from './AppearanceProvider';
import { motionProfile } from './preferences';
import { StarfieldEngine, starCount } from './starfieldEngine';
import type { StarfieldFrame } from './starfieldEngine';
export function Starfield():React.JSX.Element{
 const canvasRef=useRef<HTMLCanvasElement>(null);const {effectiveMode}=useAppearance();
 useEffect(()=>{const canvas=canvasRef.current;if(!canvas)return;const ctx=canvas.getContext('2d',{alpha:true});if(!ctx)return;const palette=getComputedStyle(canvas);const gridColor=palette.getPropertyValue('--color-grid').trim();const starColor=palette.getPropertyValue('--color-stars-rgb').trim();
 function draw(f:StarfieldFrame):void{if(!ctx||!canvas)return;ctx.clearRect(0,0,f.width,f.height);ctx.strokeStyle=gridColor;ctx.lineWidth=.5;for(const x of [.18,.82]){ctx.beginPath();ctx.moveTo(f.width*x,0);ctx.lineTo(f.width*x,f.height);ctx.stroke();}for(const star of f.stars){const amplitude=f.profile.parallax[star.layer];const drift=f.profile.drift*(star.layer+1);const x=star.x*f.width+f.pointer[0]*amplitude+Math.sin(f.time*.045+star.phase)*drift;const y=star.y*f.height+f.pointer[1]*amplitude+Math.cos(f.time*.025+star.phase)*drift;const alpha=star.alpha*(1+Math.sin(f.time*.35+star.phase)*f.profile.twinkle);if(star.layer===2&&star.phase<1.4){ctx.beginPath();ctx.arc(x,y,star.radius*3,0,Math.PI*2);ctx.fillStyle=`rgba(${starColor},${alpha*.09})`;ctx.fill();}ctx.beginPath();ctx.arc(x,y,star.radius,0,Math.PI*2);ctx.fillStyle=`rgba(${starColor},${alpha})`;ctx.fill();}}
 const engine=new StarfieldEngine(motionProfile(effectiveMode),{
 now:()=>performance.now(),requestFrame:cb=>window.requestAnimationFrame(cb),cancelFrame:id=>window.cancelAnimationFrame(id),hidden:()=>document.hidden,size:()=>[canvas.clientWidth,canvas.clientHeight,window.devicePixelRatio],
 onPointer:cb=>{const listener=(e:PointerEvent)=>cb(e.clientX,e.clientY);window.addEventListener('pointermove',listener,{passive:true});return()=>window.removeEventListener('pointermove',listener);},
 onVisibility:cb=>{document.addEventListener('visibilitychange',cb);return()=>document.removeEventListener('visibilitychange',cb);},
 onResize:cb=>{const observer=new ResizeObserver(cb);observer.observe(canvas);window.addEventListener('resize',cb,{passive:true});return()=>{observer.disconnect();window.removeEventListener('resize',cb);};},
 },{resize:(w,h,dpr)=>{canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);canvas.dataset['starCount']=String(starCount(w,h));},draw,activity:state=>{canvas.dataset['activity']=state;}});
 engine.start();return()=>engine.stop();
 },[effectiveMode]);
 return <div className="nexus-background" aria-hidden="true"><canvas ref={canvasRef} className="nexus-starfield"/><div className="nexus-atmosphere"/></div>;
}
