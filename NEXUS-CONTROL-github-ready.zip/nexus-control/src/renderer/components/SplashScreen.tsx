import { APP_NAME, APP_TAGLINE } from '../../shared/constants';
import { Icon } from './Icon';
import { NexusMark } from './NexusMark';

export function SplashScreen({ error, onRetry }: { error: string | null; onRetry(): void }): React.JSX.Element {
  return (
    <main className="welcome" aria-labelledby="app-title">
      <NexusMark />
      <h1 id="app-title">{APP_NAME}</h1>
      <p className="tagline">{APP_TAGLINE}</p>
      <div className={`splash-state${error ? ' splash-error' : ''}`} role={error ? 'alert' : 'status'}>
        <Icon name={error ? 'info' : 'loader'} size={15} className={error ? '' : 'spin'} />
        <span>{error ?? 'Подготовка рабочего пространства…'}</span>
      </div>
      {error && <button className="button button-secondary" onClick={onRetry}>Повторить запуск</button>}
    </main>
  );
}
