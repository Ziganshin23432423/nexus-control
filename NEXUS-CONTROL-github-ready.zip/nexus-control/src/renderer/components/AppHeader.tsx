import { Icon } from './Icon';
import { NexusMark } from './NexusMark';
import { BrandWordmark } from './BrandWordmark';

export function AppHeader({ onHome,onGuide,onAppearance,guideOpen=false }: { onHome(): void;onGuide?():void;onAppearance?():void;guideOpen?:boolean }): React.JSX.Element {
  return (
    <header className="app-header">
      <button className="brand" onClick={onHome} aria-label="NEXUS CONTROL — главная">
        <NexusMark />
        <BrandWordmark />
      </button>
      {onGuide&&<nav className="guide-header-nav" aria-label="Основная навигация"><button aria-current={!guideOpen?"page":undefined} onClick={onHome}>Мои компьютеры</button><button aria-current={guideOpen?"page":undefined} onClick={onGuide}><Icon name="book" size={15}/>NEXUS GUIDE</button>{onAppearance&&<button className="appearance-trigger" aria-label="Внешний вид" onClick={onAppearance}><Icon name="settings" size={18}/></button>}</nav>}
      <span className="platform-label"><Icon name="windows" size={13} /> Windows Desktop</span>
    </header>
  );
}
