import type { GuideArticleId } from '../guide/ids';
import type { ToastMessage } from '../state/demoTypes';
import { Icon } from './Icon';

export function Toasts({ messages, onDismiss,onGuide }: { messages: readonly ToastMessage[]; onDismiss(id: string): void;onGuide?(id:GuideArticleId):void }): React.JSX.Element {
  return (
    <aside className="toast-region" aria-label="Уведомления" aria-live="polite" aria-atomic="false">
      {messages.map((toast) => <div className={`toast toast-${toast.kind}`} key={toast.id} role="status"><Icon name={toast.kind === 'success' ? 'checkCircle' : 'info'} size={20} /><div><strong>{toast.title}</strong><p>{toast.description}</p>{toast.options?.retry && <button className="text-button" onClick={() => { onDismiss(toast.id); toast.options?.retry?.(); }}>Повторить</button>}{toast.options?.guideArticleId&&onGuide&&<button className="text-button" onClick={()=>{onDismiss(toast.id);onGuide(toast.options!.guideArticleId!);}}>Открыть инструкцию</button>}{toast.options?.details && <details><summary>Технические сведения</summary><pre>{toast.options.details}</pre></details>}</div><button className="icon-button toast-close" onClick={() => onDismiss(toast.id)} aria-label={`Закрыть уведомление: ${toast.title}`}><Icon name="close" size={15} /></button></div>)}
    </aside>
  );
}
