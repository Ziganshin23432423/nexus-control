import { HelpButton } from '../guide/HelpButton';
import { FIELD_GUIDE_ARTICLES } from '../guide/contextArticles';
import { presentError } from '../state/operationUx';
import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { DEFAULT_COMPUTER_OPERATING_SYSTEM } from '../../shared/constants';
import { validateComputerDraft } from '../../shared/validation';
import type { Computer, ComputerDraft, IpcResult, ValidationErrors } from '../../shared/types';
import { Icon } from './Icon';

/** Text input draft derived from the shared model, not a second computer model. */
type FormFields = Pick<Computer, 'name' | 'hostname' | 'localAddress'> & {
  remoteAddress: string;
  macAddress: string;
  username: string;
  broadcastAddress: string;
  port: string;
};
type FormErrors = ValidationErrors;

interface FieldProps {
  name: keyof FormFields;
  label: string;
  value: string;
  placeholder: string;
  hint?: string;
  error: string | undefined;
  required?: boolean;
  optional?: boolean;
  maxLength?: number;
  numeric?: boolean;
  onChange(value: string): void;
}

function Field({ name, label, value, placeholder, hint, error, required = false, optional = false, maxLength = 253, numeric = false, onChange }: FieldProps): React.JSX.Element {
  const id = `computer-${name}`;
  const description = error ? `${id}-error` : hint ? `${id}-hint` : undefined;
  return (
    <div className={`form-field${error ? ' field-invalid' : ''}`}>
      <div className="guide-field-heading"><label htmlFor={id}>{label}{required && <span className="required-marker"> *</span>}{optional && <span className="optional-marker">Необязательно</span>}</label>{FIELD_GUIDE_ARTICLES[name]&&<HelpButton label={label} articleId={FIELD_GUIDE_ARTICLES[name]!} overlay/>}</div>
      <input id={id} name={name} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} maxLength={maxLength} inputMode={numeric ? 'numeric' : 'text'} autoComplete="off" spellCheck={false} aria-required={required} aria-invalid={Boolean(error)} aria-describedby={description} />
      {error ? <p className="field-error" id={`${id}-error`} role="alert">{error}</p> : hint && <p className="field-hint" id={`${id}-hint`}>{hint}</p>}
    </div>
  );
}

interface ComputerFormDialogProps {
  computer: Computer | null;
  onClose(): void;
  demoOnly: boolean;
  onSave(draft: ComputerDraft): Promise<IpcResult<Computer>>;
}

export function ComputerFormDialog({ computer, demoOnly, onClose, onSave }: ComputerFormDialogProps): React.JSX.Element {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [fields, setFields] = useState<FormFields>(() => ({
    name: computer?.name ?? '', hostname: computer?.hostname ?? '', localAddress: computer?.localAddress ?? '',
    remoteAddress: computer?.remoteAddress ?? '', macAddress: computer?.macAddress ?? '', username: computer?.username ?? '',
    broadcastAddress: computer?.wakeOnLan?.broadcastAddress ?? '', port: String(computer?.wakeOnLan?.port ?? 9),
  }));
  const [rdpEnabled, setRdpEnabled] = useState(computer?.rdpEnabled ?? true);
  const [sshEnabled, setSshEnabled] = useState(computer?.sshEnabled ?? false);
  const [wolEnabled, setWolEnabled] = useState(computer?.wakeOnLan !== null && computer?.wakeOnLan !== undefined);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});

  useEffect(() => {
    const dialog = dialogRef.current;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    dialog?.showModal();
    dialog?.querySelector<HTMLInputElement>('input[name="name"]')?.focus();
    return () => {
      dialog?.close();
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, []);

  function change(name: keyof FormFields, value: string): void {
    setFields((current) => ({ ...current, [name]: value }));
    setErrors((current) => {
      const next = { ...current };
      delete next[name];
      return next;
    });
  }

  async function submit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    if (saving) return;
    const result = validateComputerDraft({
      name: fields.name, operatingSystem: DEFAULT_COMPUTER_OPERATING_SYSTEM,
      hostname: fields.hostname, localAddress: fields.localAddress,
      remoteAddress: fields.remoteAddress || null, macAddress: fields.macAddress || null,
      username: fields.username || null, rdpEnabled, sshEnabled,
      wakeOnLan: wolEnabled ? { broadcastAddress: fields.broadcastAddress, port: /^\d+$/.test(fields.port) ? Number(fields.port) : NaN } : null,
      notes: computer?.notes ?? '',
    });
    if (!result.ok) {
      setErrors(result.errors);
      const field = Object.keys(result.errors)[0];
      dialogRef.current?.querySelector<HTMLInputElement>(`input[name="${field}"]`)?.focus();
      return;
    }
    setErrors({}); setSaving(true);
    try {
      const saved = await onSave(result.value);
      if (!saved.ok) setErrors({ ...saved.error.fieldErrors, _form: presentError(saved.error.code).description });
    } catch { setErrors({ _form: 'Не удалось сохранить настройки. Попробуйте ещё раз.' }); }
    finally { setSaving(false); }
  }

  return (
    <dialog className="computer-dialog" ref={dialogRef} aria-labelledby="computer-form-title" aria-describedby="computer-form-demo-note" onCancel={(event) => { event.preventDefault(); if (!saving) onClose(); }} onClick={(event) => {
      if (event.target !== event.currentTarget) return;
      const rectangle = event.currentTarget.getBoundingClientRect();
      if (event.clientX < rectangle.left || event.clientX > rectangle.right || event.clientY < rectangle.top || event.clientY > rectangle.bottom) { if (!saving) onClose(); }
    }}>
      <form className="computer-form" onSubmit={submit} noValidate>
        <header className="dialog-heading"><span className="dialog-device-icon"><Icon name="monitor" size={22} /></span><div><h2 id="computer-form-title">{computer ? 'Редактировать компьютер' : 'Добавить компьютер'}</h2><p>{computer ? 'Параметры выбранного устройства' : 'Все подключения начинаются с одной карточки'}</p></div><button type="button" className="icon-button" onClick={onClose} disabled={saving} aria-label={computer ? 'Закрыть окно редактирования' : 'Закрыть окно добавления'}><Icon name="close" size={20} /></button></header>

        <div className="dialog-body"><fieldset disabled={saving}>
          {(errors._form || errors.operatingSystem || errors.notes) && <p className="field-error" role="alert">{errors._form ?? errors.operatingSystem ?? errors.notes}</p>}
          <div className="form-grid">
            <Field name="name" label="Название" value={fields.name} placeholder="Например, PC HOME" maxLength={64} required error={errors.name} onChange={(value) => change('name', value)} />
            <fieldset className="operating-system-field"><legend>Операционная система</legend><div className="os-choices"><label className="os-choice os-selected"><input type="radio" name="operatingSystem" value="windows" checked readOnly /><Icon name="windows" size={18} /><span>Windows</span><Icon name="check" size={14} /></label><label className="os-choice os-future"><input type="radio" name="operatingSystem" value="linux" disabled /><Icon name="terminal" size={18} /><span>Linux<small>Поддержка позже</small></span><Icon name="lock" size={12} /></label></div></fieldset>
            <Field name="hostname" label="Hostname" value={fields.hostname} placeholder="HOME-PC" hint="Имя компьютера в сети" error={errors.hostname} onChange={(value) => change('hostname', value)} />
            <Field name="localAddress" label="Локальный IP / hostname" value={fields.localAddress} placeholder="192.168.1.25" required hint="Адрес в вашей локальной сети" error={errors.localAddress} onChange={(value) => change('localAddress', value)} />
            <Field name="remoteAddress" label="Удалённый / VPN IP" value={fields.remoteAddress} placeholder="Не настроен" optional error={errors.remoteAddress} onChange={(value) => change('remoteAddress', value)} />
            <Field name="macAddress" label="MAC-адрес" value={fields.macAddress} placeholder="AA:BB:CC:DD:EE:FF" maxLength={17} required={wolEnabled} hint="Нужен для включения через Wake-on-LAN" error={errors.macAddress} onChange={(value) => change('macAddress', value)} />
            <Field name="username" label="Имя пользователя" value={fields.username} placeholder="Windows / SSH username" maxLength={128} required={sshEnabled} hint="Пароль будет запрашивать клиент подключения" error={errors.username} onChange={(value) => change('username', value)} />
          </div>

          <fieldset className="capabilities-field"><legend>ВОЗМОЖНОСТИ</legend><div className="capability-grid">
            <label className={`capability-choice${rdpEnabled ? ' capability-selected' : ''}`}><input type="checkbox" role="switch" aria-label="RDP" checked={rdpEnabled} onChange={(event) => setRdpEnabled(event.target.checked)} /><Icon name="monitor" size={18} /><span><strong>RDP</strong><small>Рабочий стол</small></span><span className="switch" /></label>
            <label className={`capability-choice${sshEnabled ? ' capability-selected' : ''}`}><input type="checkbox" role="switch" aria-label="SSH" checked={sshEnabled} onChange={(event) => setSshEnabled(event.target.checked)} /><Icon name="terminal" size={18} /><span><strong>SSH</strong><small>Терминал</small></span><span className="switch" /></label>
            <label className={`capability-choice${wolEnabled ? ' capability-selected' : ''}`}><input type="checkbox" role="switch" aria-label="Wake-on-LAN" checked={wolEnabled} onChange={(event) => setWolEnabled(event.target.checked)} /><Icon name="power" size={18} /><span><strong>Wake-on-LAN</strong><small>Включение</small></span><span className="switch" /></label>
          </div></fieldset>

          {wolEnabled && <section className="wol-fields" aria-label="Настройки Wake-on-LAN"><div className="wol-heading"><Icon name="power" size={15} /><span>НАСТРОЙКИ WAKE-ON-LAN</span></div><div className="form-grid"><Field name="broadcastAddress" label="Broadcast address" value={fields.broadcastAddress} placeholder="192.168.1.255" required error={errors.broadcastAddress} onChange={(value) => change('broadcastAddress', value)} /><Field name="port" label="Порт" value={fields.port} placeholder="9" numeric maxLength={5} required hint="Стандартный порт — 9" error={errors.port} onChange={(value) => change('port', value)} /></div></section>}
        </fieldset></div>

        <footer className="dialog-footer"><span className="dialog-demo-note" id="computer-form-demo-note"><Icon name="beaker" size={14} />{demoOnly ? 'Только в текущей демо-сессии' : 'Сохраняется на этом компьютере'}</span><div><button type="button" className="button button-secondary" onClick={onClose} disabled={saving}>Отмена</button><button type="submit" disabled={saving} className="button button-primary"><Icon name={computer ? 'check' : 'plus'} size={17} />{saving ? 'Сохраняем…' : computer ? 'Сохранить изменения' : 'Добавить компьютер'}</button></div></footer>
      </form>
    </dialog>
  );
}
