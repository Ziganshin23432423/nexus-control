import type { AppInfo } from '../../shared/types';
import type { DataSource } from '../state/computerStatus';
import { Icon } from './Icon';
export function AppFooter({ info, source, disabled, onSource }: { info: AppInfo; source: DataSource; disabled: boolean; onSource(source: DataSource): void }): React.JSX.Element {
  return <footer className="app-footer"><div className="demo-caption"><span className="demo-tag"><Icon name={source === 'user' ? 'monitor' : 'beaker'} size={12} />{source === 'user' ? 'МОИ ДАННЫЕ' : 'ДЕМО'}</span><span>{source === 'user' ? 'Сохраняются локально' : 'Все действия имитируются'}</span></div><div className="footer-tools"><label className="scenario-control"><span>Данные</span><select aria-label="Источник данных" value={source} disabled={disabled} onChange={(event) => onSource(event.target.value === 'user' ? 'user' : event.target.value === 'demo-empty' ? 'demo-empty' : 'demo-computers')}><option value="user">Мои компьютеры</option><option value="demo-computers">Демо: два компьютера</option><option value="demo-empty">Демо: пустой список</option></select></label><span className="version">v{info.version}</span></div></footer>;
}
