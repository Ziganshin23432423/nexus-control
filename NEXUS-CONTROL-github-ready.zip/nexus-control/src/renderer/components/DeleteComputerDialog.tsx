import { presentError } from '../state/operationUx';
import { useEffect, useRef, useState } from 'react';
import type { Computer, IpcResult } from '../../shared/types';
export function DeleteComputerDialog({ computer, demoOnly, onClose, onDelete }: { computer: Computer; demoOnly: boolean; onClose(): void; onDelete(): Promise<IpcResult<null>> }): React.JSX.Element {
  const ref = useRef<HTMLDialogElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null; const dialog = ref.current; dialog?.showModal(); dialog?.querySelector<HTMLButtonElement>('button')?.focus(); return () => { dialog?.close(); if (previous?.isConnected) previous.focus(); }; }, []);
  async function remove(): Promise<void> {
    setBusy(true);
    try { const result = await onDelete(); if (!result.ok) setError(presentError(result.error.code).description); }
    catch { setError('Не удалось удалить компьютер. Попробуйте ещё раз.'); }
    finally { setBusy(false); }
  }
  return <dialog ref={ref} className="computer-dialog delete-dialog" aria-labelledby="delete-title" onCancel={(event) => { event.preventDefault(); if (!busy) onClose(); }}><header className="dialog-heading"><div><h2 id="delete-title">Удалить компьютер?</h2><p>{computer.name} · {computer.localAddress}</p></div></header><div className="dialog-body"><p>Будет удалена только карточка {computer.name}. Сам компьютер и его настройки не изменятся.</p><p className="field-hint">{demoOnly ? 'Изменения только в демо-сессии.' : 'Удаление сохранится после перезапуска.'}</p>{error && <p className="field-error" role="alert">{error}</p>}</div><footer className="dialog-footer"><div><button className="button button-secondary" disabled={busy} onClick={onClose}>Отмена</button><button className="button button-danger" disabled={busy} onClick={() => void remove()}>{busy ? 'Удаляем…' : 'Удалить компьютер'}</button></div></footer></dialog>;
}
