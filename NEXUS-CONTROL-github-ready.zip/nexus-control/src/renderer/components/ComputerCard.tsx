import { HelpButton } from '../guide/HelpButton';
import type { Computer, ConnectionCheckResult, WakeAndConnectProgress } from '../../shared/types';
import type { DemoAction, DemoJob } from '../state/demoTypes';
import { ComputerActions } from './ComputerActions';
import { Icon } from './Icon';
import { StatusBadge } from './StatusBadge';

interface ComputerCardProps {
  demoOnly?: boolean;
  rdpPending?: boolean;
  sshPending?: boolean;
  wakePending?: boolean;
  workflow?: WakeAndConnectProgress | undefined;
  computer: Computer;
  status: ConnectionCheckResult;
  job: DemoJob | undefined;
  onOpen(): void;
  onAction(action: DemoAction): void;
  onCancel(): void;
}

export function ComputerCard({ demoOnly = true, rdpPending = false, sshPending = false, wakePending = false, workflow, computer, status, job, onOpen, onAction, onCancel }: ComputerCardProps): React.JSX.Element {
  return (
    <article className={`computer-card${status.status === 'checking' ? ' card-checking' : ''}`} aria-label={computer.name}>
      <button className="card-navigation" onClick={onOpen} aria-label={`Открыть ${computer.name}`} />
      <div className="card-content">
        <div className="card-top">
          <span className="device-icon"><Icon name="monitor" size={23} /></span>
          <div className="card-identity"><h2>{computer.name}</h2><span className="os-caption"><Icon name={computer.operatingSystem === 'windows' ? 'windows' : 'terminal'} size={12} />{computer.operatingSystem === 'windows' ? 'Windows PC' : 'Linux PC'}</span></div>
          <StatusBadge status={status.status} />
        </div>
        <div className="card-address">
          <span className="hostname"><Icon name="network" size={15} />{computer.hostname || 'Hostname не указан'}</span>
          <span className="address-value">{computer.localAddress}</span>
        </div>
        <div className="card-services">
          <div><span className="service-label">RDP</span><StatusBadge status={status.rdp} compact /><HelpButton label="RDP" articleId={status.rdp==='unavailable'?'troubleshooting/rdp-unavailable':'connection/rdp'}/></div>
          <div><span className="service-label">SSH</span><StatusBadge status={status.ssh} compact /><HelpButton label="SSH" articleId={status.ssh==='unavailable'?'troubleshooting/ssh-unavailable':'connection/ssh'}/></div>
          <div><span className="service-label">Wake-on-LAN</span><StatusBadge status={status.wakeOnLan} compact /><HelpButton label="Wake-on-LAN" articleId="wol/setup"/></div>
        </div>
      </div>
      <div className="card-actions"><ComputerActions workflow={workflow} wakePending={wakePending} sshPending={sshPending} rdpPending={rdpPending} demoOnly={demoOnly} computer={computer} status={status} job={job} onAction={onAction} onCancel={onCancel} /></div>
      <div className="card-bottom"><span>Открыть компьютер</span><Icon name="arrowRight" size={15} /></div>
    </article>
  );
}
