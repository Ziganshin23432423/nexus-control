/** Open network N: two rails, one connection and three nodes. No enclosing tile. */
export function NexusMark(): React.JSX.Element {
  return (
    <svg className="nexus-mark" viewBox="0 0 32 32" fill="none" aria-hidden="true" focusable="false">
      <path d="M7 25V7L25 25V7" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="7" cy="7" r="2.4" fill="currentColor" />
      <circle cx="25" cy="25" r="2.4" fill="currentColor" />
      <circle cx="25" cy="7" r="2.4" fill="currentColor" />
    </svg>
  );
}
