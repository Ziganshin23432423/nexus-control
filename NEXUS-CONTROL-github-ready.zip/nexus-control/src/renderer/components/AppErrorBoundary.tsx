import { Component } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
import { ERROR_FALLBACK } from '../state/operationUx.js';
import { NexusMark } from './NexusMark.js';
export class AppErrorBoundary extends Component<{children: ReactNode}, {failed: boolean}> {
  override state = {failed: false};
  static getDerivedStateFromError(): {failed: boolean} { return {failed: true}; }
  override componentDidCatch(error: Error, info: ErrorInfo): void { if (import.meta.env?.DEV) console.error('Renderer boundary', error, info); }
  private readonly fail = (): void => { this.setState({failed: true}); };
  override componentDidMount(): void { window.addEventListener('error', this.fail); window.addEventListener('unhandledrejection', this.fail); }
  override componentWillUnmount(): void { window.removeEventListener('error', this.fail); window.removeEventListener('unhandledrejection', this.fail); }
  override render(): ReactNode {
    if (!this.state.failed) return this.props.children;
    return <main className="app-shell storage-state error-fallback" role="alert"><NexusMark /><span className="eyebrow">NEXUS CONTROL</span><h1>{ERROR_FALLBACK.title}</h1><p>{ERROR_FALLBACK.description}</p><button className="button button-primary" onClick={() => this.setState({failed: false})}>{ERROR_FALLBACK.action}</button></main>;
  }
}
