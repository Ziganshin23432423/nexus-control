import { capabilityActions, progressLabel } from '../state/operationUx';
import type { Computer, ConnectionCheckResult, WakeAndConnectProgress } from '../../shared/types';
import type { DemoAction, DemoJob } from '../state/demoTypes';
import { Icon } from './Icon';

interface ComputerActionsProps {
  demoOnly?: boolean;
  rdpPending?: boolean;
  sshPending?: boolean;
  wakePending?: boolean;
  workflow?: WakeAndConnectProgress | undefined;
  computer: Computer;
  status: ConnectionCheckResult;
  job: DemoJob | undefined;
  expanded?: boolean;
  onAction(action: DemoAction): void;
  onCancel(): void;
}

export function ComputerActions({ demoOnly = true, rdpPending = false, sshPending = false, wakePending = false, workflow, computer, status, job, expanded = false, onAction, onCancel }: ComputerActionsProps): React.JSX.Element {
  const capabilities = capabilityActions(computer);
  const waking = job?.action === 'wake' || job?.action === 'wake-rdp' || job?.action === 'wake-ssh';
  const checking = job?.action === 'check';
  const busy = job !== undefined || rdpPending || sshPending || wakePending;
  const online = status.status === 'online' || (checking && job?.previousStatus.status === 'online');

  if (workflow) {
    const label = progressLabel(workflow);
    return <div className="wake-progress" role="status" aria-live="polite" aria-busy="true"><div className="wake-progress-top"><Icon name="loader" size={17} className="spin" /><span>{label}</span><button className="text-button" onClick={onCancel}>Отменить</button></div><div className="progress-track" aria-hidden="true"><span /></div><p>До 90 секунд · отправка сигнала не подтверждает включение</p></div>;
  }
  if (waking) {
    return (
      <div className="wake-progress" role="status">
        <div className="wake-progress-top"><Icon name="loader" size={17} className="spin" /><span>Включаем компьютер…</span><button className="text-button" onClick={onCancel}>Отмена</button></div>
        <div className="progress-track"><span /></div>
        <p>Ожидаем готовности · демо</p>
      </div>
    );
  }

  if (demoOnly && !online && capabilities.includes('wake')) {
    return (
      <div className="action-stack">
        <button className="button button-primary" disabled={busy} onClick={() => onAction('wake')}><Icon name="power" />Включить</button>
        {computer.rdpEnabled && <button className="button button-secondary" disabled={busy} onClick={() => onAction('wake-rdp')}><Icon name="monitor" />Включить и подключиться</button>}
        {computer.sshEnabled && <button className="button button-secondary" disabled={busy} onClick={() => onAction('wake-ssh')}><Icon name="terminal" />Включить и открыть терминал</button>}
        {checking && <span className="action-hint">Проверяем демо-статусы…</span>}
      </div>
    );
  }

  return (
    <div className={expanded ? 'action-stack' : 'action-row'}>
      {computer.rdpEnabled && <button className="button button-primary" disabled={busy || status.rdp !== 'ready'} aria-busy={rdpPending} onClick={() => onAction('rdp')} title={status.rdp === 'unavailable' ? 'RDP пока не отвечает' : undefined}><Icon name={(rdpPending || job?.action === 'rdp') ? 'loader' : 'monitor'} className={(rdpPending || job?.action === 'rdp') ? 'spin' : ''} />{(rdpPending || job?.action === 'rdp') ? (demoOnly ? 'Открываем…' : 'Подключение…') : expanded ? 'Удалённый рабочий стол' : 'Рабочий стол'}</button>}
      {computer.sshEnabled && <button className="button button-secondary" disabled={busy || status.ssh !== 'ready'} aria-busy={sshPending} onClick={() => onAction('ssh')} title={status.ssh === 'unavailable' ? 'SSH пока не отвечает' : undefined}><Icon name={(sshPending || job?.action === 'ssh') ? 'loader' : 'terminal'} className={(sshPending || job?.action === 'ssh') ? 'spin' : ''} />{(sshPending || job?.action === 'ssh') ? (demoOnly ? 'Открываем…' : 'Подключение…') : expanded ? 'SSH-терминал' : 'Терминал'}</button>}
      {!demoOnly && capabilities.includes('wake') && <button className={`button wake-button ${online ? 'button-secondary' : 'button-primary'}`} disabled={busy} aria-busy={wakePending} onClick={() => onAction('wake')}><Icon name={wakePending ? 'loader' : 'power'} className={wakePending ? 'spin' : ''} />{wakePending ? 'Отправка…' : 'Включить'}</button>}
      {!demoOnly && capabilities.includes('wake-rdp') && <button className="button button-secondary wake-button wake-combined" disabled={busy || wakePending} onClick={() => onAction('wake-rdp')}><Icon name="monitor" />Включить и подключиться</button>}
      {!demoOnly && capabilities.includes('wake-ssh') && <button className="button button-secondary wake-button wake-combined" disabled={busy || wakePending} onClick={() => onAction('wake-ssh')}><Icon name="terminal" />Включить и открыть терминал</button>}
      {capabilities.length === 0 && <p className="action-hint">Подключения не настроены</p>}
    </div>
  );
}
