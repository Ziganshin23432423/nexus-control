/** Static brand lockup; display type is intentionally limited to identity and headings. */
export function BrandWordmark(): React.JSX.Element {
  return (
    <span className="brand-type">
      <span className="wordmark"><span className="wordmark-primary">NEXUS</span><span className="wordmark-secondary">CONTROL</span></span>
      <span className="brand-credit">by network.onion</span>
    </span>
  );
}
