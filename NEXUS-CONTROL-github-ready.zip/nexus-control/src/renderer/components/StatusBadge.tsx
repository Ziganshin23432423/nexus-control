import type { ComputerStatus, ServiceStatus, WakeOnLanStatus } from '../../shared/types';

type Status = ComputerStatus | ServiceStatus | WakeOnLanStatus;

const labels: Record<Status, string> = {
  'no-services': 'Нет проверяемых служб', unknown: 'Не проверен', online: 'Онлайн', offline: 'Недоступен', checking: 'Проверка…',
  ready: 'Готов', unavailable: 'Не отвечает', configured: 'Настроен', disabled: 'Не настроен',
};

export function StatusBadge({ status, compact = false }: { status: Status; compact?: boolean }): React.JSX.Element {
  return (
    <span className={`status-badge status-${status}${compact ? ' status-compact' : ''}`}>
      <span className="status-dot" aria-hidden="true" />
      {labels[status]}
    </span>
  );
}
