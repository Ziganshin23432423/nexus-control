import type { NexusApi } from '../shared/types';

declare global {
  interface Window {
    readonly nexus: NexusApi;
  }
}

export {};
