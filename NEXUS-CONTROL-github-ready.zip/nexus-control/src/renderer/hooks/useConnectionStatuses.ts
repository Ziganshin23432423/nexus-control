import { useCallback, useEffect, useRef, useState } from 'react';
import type { Computer, ConnectionCheckResult, IpcResult } from '../../shared/types';
import { unverifiedStatus } from '../state/computerStatus';
import { presentError } from '../state/operationUx';
import { StatusRequests } from '../state/statusRequests';

type Statuses = Record<string, ConnectionCheckResult>;
export function useConnectionStatuses(computers: readonly Computer[], enabled: boolean) {
  const [statuses, setStatuses] = useState<Statuses>({});
  const [isChecking, setChecking] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const running = useRef(false);
  const requests = useRef(new StatusRequests());
  const current = useRef(computers); current.current = computers;
  const active = useRef(enabled); active.current = enabled;
  const completed = useRef<Statuses>({});
  const completedSnapshots = useRef<Record<string, Computer>>({});
  const baseline = useCallback((): Statuses => Object.fromEntries(computers.map((computer) => {
    const previous = completed.current[computer.id];
    return [computer.id, previous?.configUpdatedAt === computer.updatedAt && completedSnapshots.current[computer.id] === computer ? previous : unverifiedStatus(computer)];
  })), [computers]);

  const refresh = useCallback(async (target?: Computer): Promise<void> => {
    if (!enabled || running.current) return;
    running.current = true;
    const generation = requests.current.begin();
    const snapshot = computers;
    const targets = target ? [target] : snapshot;
    const previous = baseline();
    const checking = { ...previous };
    for (const computer of targets) {
      const state = unverifiedStatus(computer);
      checking[computer.id] = { ...state, status: computer.rdpEnabled || computer.sshEnabled ? 'checking' : 'no-services',
        rdp: computer.rdpEnabled ? 'checking' : 'disabled', ssh: computer.sshEnabled ? 'checking' : 'disabled' };
    }
    setStatuses(checking); setChecking(true); setError(null); setNotice(null);
    try {
      const reply: IpcResult<readonly ConnectionCheckResult[]> = target
        ? await window.nexus.checkComputerStatus(target.id).then((result) => result.ok ? { ok: true, value: [result.value] } : result)
        : await window.nexus.refreshAllComputerStatuses();
      if (!active.current || !requests.current.isCurrent(generation) || current.current !== snapshot) return;
      if (!reply.ok) {
        setStatuses(previous);
        if (reply.error.code !== 'CANCELLED') setError(presentError(reply.error.code).description);
        return;
      }
      if (!requests.current.canApply(generation, snapshot, current.current, reply.value, targets)) { setStatuses(previous); setError('Настройки изменились. Обновите статусы ещё раз.'); return; }
      const next = { ...previous };
      for (const result of reply.value) next[result.computerId] = result;
      completed.current = next;
      completedSnapshots.current = Object.fromEntries(snapshot.map((computer) => [computer.id, computer]));
      setStatuses(next);
    } catch {
      if (active.current && requests.current.isCurrent(generation) && current.current === snapshot) { setStatuses(previous); setError('Не удалось выполнить проверку. Попробуйте ещё раз.'); }
    } finally {
      if (requests.current.isCurrent(generation)) running.current = false;
      if (active.current && requests.current.isCurrent(generation) && current.current === snapshot) setChecking(false);
    }
  }, [computers, enabled, baseline]);

  useEffect(() => {
    if (enabled) void refresh();
    else setChecking(false);
    return () => {
      running.current = false; requests.current.invalidate();
      void window.nexus.cancelComputerStatusChecks().catch(() => {});
    };
  }, [enabled, refresh]);

  function cancel(): void {
    running.current = false; const generation = requests.current.begin(); setChecking(false); setError(null); setNotice('Проверка отменена. Показан последний завершённый результат; без него — «Не проверен».'); setStatuses(baseline());
    void window.nexus.cancelComputerStatusChecks().catch(() => { if (active.current && requests.current.isCurrent(generation)) setError('Не удалось отменить проверку. Соединения завершатся по таймауту.'); });
  }
  return { statuses, isChecking, error, notice, refresh: () => void refresh(), checkOne: (computer: Computer) => void refresh(computer), cancel };
}
