import { SUCCESS_TITLES } from '../state/operationUx';
import { notifyError } from '../state/notifyError';
import { useEffect, useRef, useState } from 'react';
import type { Notify } from '../state/demoTypes';

export function useWakeComputer(enabled: boolean, notify: Notify) {
  const [pendingIds, setPendingIds] = useState<Readonly<Record<string, boolean>>>({});
  const enabledRef = useRef(enabled); enabledRef.current=enabled;
  const pending = useRef(new Set<string>());
  const mounted = useRef(false);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  async function wake(id: string): Promise<void> {
    if (!enabledRef.current || pending.current.has(id)) return;
    pending.current.add(id); setPendingIds(Object.fromEntries([...pending.current].map((key) => [key, true])));
    try {
      const reply = await window.nexus.wakeComputer(id);
      if (!mounted.current) return;
      if (reply.ok) notify(SUCCESS_TITLES.wake, 'Отправка не подтверждает включение компьютера. Статус можно проверить вручную.', 'success');
      else notifyError(notify, reply.error.code, () => { void wake(id); }, 'wol');
    } catch { if (mounted.current) notifyError(notify, 'NETWORK_ERROR', () => { void wake(id); }, 'wol'); }
    finally {
      pending.current.delete(id);
      if (mounted.current) setPendingIds(Object.fromEntries([...pending.current].map((key) => [key, true])));
    }
  }
  return { pendingIds, isBusy: Object.keys(pendingIds).length > 0, wake };
}
