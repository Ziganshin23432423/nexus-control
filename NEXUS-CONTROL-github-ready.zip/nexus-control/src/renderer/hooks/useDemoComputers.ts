import { useEffect, useRef, useState } from 'react';
import type { Computer, ConnectionCheckResult } from '../../shared/types';
import { createDemoComputers, createDemoStatus, createInitialStatuses } from '../state/demoData';
import type { DemoAction, DemoJob, DemoScenario, Notify } from '../state/demoTypes';

function withoutKey<T>(record: Readonly<Record<string, T>>, id: string): Record<string, T> {
  const next = { ...record };
  delete next[id];
  return next;
}

/** Stage 2 is an isolated in-memory simulator. No IPC, storage or network here. */
export function useDemoComputers(notify: Notify) {
  const [computers, setComputers] = useState<Computer[]>(createDemoComputers);
  const [statuses, setStatuses] = useState<Record<string, ConnectionCheckResult>>(() => createInitialStatuses(createDemoComputers()));
  const [jobs, setJobs] = useState<Record<string, DemoJob>>({});
  const [scenario, setScenario] = useState<DemoScenario>('computers');
  const timers = useRef(new Map<string, number>());

  useEffect(() => {
    const activeTimers = timers.current;
    return () => {
      activeTimers.forEach((timer) => window.clearTimeout(timer));
      activeTimers.clear();
    };
  }, []);

  function completeJob(id: string): void {
    timers.current.delete(id);
    setJobs((current) => withoutKey(current, id));
  }

  function switchScenario(nextScenario: DemoScenario): void {
    timers.current.forEach((timer) => window.clearTimeout(timer));
    timers.current.clear();
    const next = nextScenario === 'computers' ? createDemoComputers() : [];
    setComputers(next);
    setStatuses(createInitialStatuses(next));
    setJobs({});
    setScenario(nextScenario);
  }

  function saveComputer(computer: Computer): void {
    const exists = computers.some((current) => current.id === computer.id);
    const existingStatus = jobs[computer.id]?.previousStatus ?? statuses[computer.id];
    const timer = timers.current.get(computer.id);
    if (timer !== undefined) window.clearTimeout(timer);
    completeJob(computer.id);
    setComputers((current) => exists
      ? current.map((item) => item.id === computer.id ? computer : item)
      : [...current, computer]);
    const nextStatus = existingStatus?.status === 'online' ? 'online' : 'offline';
    setStatuses((current) => ({ ...current, [computer.id]: createDemoStatus(computer, nextStatus) }));
    notify(exists ? 'Настройки обновлены' : 'Компьютер добавлен', 'Изменения доступны до перезапуска приложения.', 'success');
  }

  function checkComputer(computer: Computer): void {
    if (timers.current.has(computer.id)) return;
    const previousStatus = statuses[computer.id] ?? createDemoStatus(computer, 'offline');
    setJobs((current) => ({ ...current, [computer.id]: { action: 'check', previousStatus } }));
    setStatuses((current) => ({ ...current, [computer.id]: createDemoStatus(computer, 'checking') }));
    timers.current.set(computer.id, window.setTimeout(() => {
      setStatuses((current) => ({ ...current, [computer.id]: { ...previousStatus, checkedAt: new Date().toISOString() } }));
      completeJob(computer.id);
    }, 800));
  }

  function checkAll(): void {
    computers.forEach(checkComputer);
    notify('Демо: проверка статусов', 'Показаны результаты демонстрационного сценария.');
  }

  function performAction(computer: Computer, action: DemoAction): void {
    if (timers.current.has(computer.id)) return;
    const previousStatus = statuses[computer.id] ?? createDemoStatus(computer, 'offline');
    const waking = action === 'wake' || action === 'wake-rdp' || action === 'wake-ssh';
    if (waking && previousStatus.wakeOnLan !== 'configured') return;
    if (action === 'wake-rdp' && !computer.rdpEnabled) return;
    if (action === 'wake-ssh' && !computer.sshEnabled) return;
    if (action === 'rdp' && previousStatus.rdp !== 'ready') return;
    if (action === 'ssh' && previousStatus.ssh !== 'ready') return;

    setJobs((current) => ({ ...current, [computer.id]: { action, previousStatus } }));
    if (waking) {
      setStatuses((current) => ({ ...current, [computer.id]: createDemoStatus(computer, 'checking') }));
      notify('Демо: включение компьютера', `Ожидаем ${computer.name} в демонстрационном сценарии.`);
    }

    timers.current.set(computer.id, window.setTimeout(() => {
      if (waking) {
        setStatuses((current) => ({ ...current, [computer.id]: createDemoStatus(computer, 'online') }));
        notify('Компьютер готов · демо', (action === 'wake-rdp' || action === 'wake-ssh')
          ? `Подключение к ${computer.name} имитируется.`
          : `${computer.name} теперь онлайн в демо-сценарии.`, 'success');
      } else {
        notify(action === 'rdp' ? 'Рабочий стол · демо' : 'SSH-терминал · демо', `Подключение к ${computer.name} имитируется.`, 'success');
      }
      completeJob(computer.id);
    }, waking ? 2400 : 450));
  }

  function cancelJob(computerId: string): void {
    const job = jobs[computerId];
    if (!job) return;
    const timer = timers.current.get(computerId);
    if (timer !== undefined) window.clearTimeout(timer);
    setStatuses((current) => ({ ...current, [computerId]: job.previousStatus }));
    completeJob(computerId);
    notify('Ожидание отменено', 'Демонстрационный сценарий остановлен.');
  }

  return {
    computers, statuses, jobs, scenario,
    isBusy: Object.keys(jobs).length > 0,
    switchScenario, saveComputer, checkAll, performAction, cancelJob,
    deleteComputer: (id: string): void => {
      const timer = timers.current.get(id);
      if (timer !== undefined) window.clearTimeout(timer);
      completeJob(id);
      setComputers((current) => current.filter((item) => item.id !== id));
      setStatuses((current) => withoutKey(current, id));
      notify('Компьютер удалён · демо', 'Изменения только в текущей демо-сессии.', 'success');
    },
  };
}
