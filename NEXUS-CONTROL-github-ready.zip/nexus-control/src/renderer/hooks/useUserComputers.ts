import { presentError } from '../state/operationUx';
import { useEffect, useState } from 'react';
import type { Computer, ComputerDraft, IpcResult } from '../../shared/types';
import type { Notify } from '../state/demoTypes';

const unavailable = <T,>(): IpcResult<T> => ({ ok: false, error: { code: 'STORAGE_ERROR', message: 'Не удалось сохранить настройки. Попробуйте ещё раз.' } });
export function useUserComputers(notify: Notify) {
  const [computers, setComputers] = useState<Computer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let active = true;
    void window.nexus.listComputers().then((result) => {
      if (!active) return;
      if (result.ok) setComputers(result.value); else setError(presentError(result.error.code).description);
    }).catch(() => { if (active) setError('Не удалось открыть локальные настройки.'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  async function reload(): Promise<void> {
    setLoading(true);
    try { const result = await window.nexus.listComputers();
      if (result.ok) { setComputers(result.value); setError(null); } else setError(presentError(result.error.code).description);
    } catch { setError('Не удалось открыть локальные настройки.'); }
    finally { setLoading(false); }
  }
  async function save(draft: ComputerDraft, id: string | null): Promise<IpcResult<Computer>> {
    setBusy(true);
    try {
      const result = id ? await window.nexus.updateComputer(id, draft) : await window.nexus.createComputer(draft);
      if (result.ok) {
        setComputers((current) => id ? current.map((item) => item.id === id ? result.value : item) : [...current, result.value]);
        notify(id ? 'Настройки сохранены' : 'Компьютер добавлен', 'Данные сохранены на этом компьютере.', 'success');
      }
      return result;
    } catch { return unavailable<Computer>(); } finally { setBusy(false); }
  }
  async function remove(id: string): Promise<IpcResult<null>> {
    setBusy(true);
    try { const result = await window.nexus.deleteComputer(id);
      if (result.ok) { setComputers((current) => current.filter((item) => item.id !== id)); notify('Компьютер удалён', 'Локальная карточка удалена.', 'success'); }
      return result;
    } catch { return unavailable<null>(); } finally { setBusy(false); }
  }
  return { computers, loading, error, busy, reload, save, remove };
}
