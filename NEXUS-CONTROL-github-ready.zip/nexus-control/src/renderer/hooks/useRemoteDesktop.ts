import { SUCCESS_TITLES } from '../state/operationUx';
import { notifyError } from '../state/notifyError';
import { useEffect, useRef, useState } from 'react';
import type { Notify } from '../state/demoTypes';

export function useRemoteDesktop(enabled: boolean, notify: Notify) {
  const [pendingIds, setPendingIds] = useState<Readonly<Record<string, boolean>>>({});
  const enabledRef = useRef(enabled); enabledRef.current=enabled;
  const pending = useRef(new Set<string>());
  const mounted = useRef(false);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; }; }, []);
  async function open(id: string): Promise<void> {
    if (!enabledRef.current || pending.current.has(id)) return;
    pending.current.add(id); setPendingIds(Object.fromEntries([...pending.current].map((key) => [key, true])));
    try {
      const reply = await window.nexus.openRemoteDesktop(id);
      if (!mounted.current) return;
      if (reply.ok) notify(SUCCESS_TITLES.rdp, 'Вход в компьютер выполняется в стандартном клиенте Windows.', 'success');
      else notifyError(notify, reply.error.code, () => { void open(id); }, 'rdp');
    } catch { if (mounted.current) notifyError(notify, 'NETWORK_ERROR', () => { void open(id); }, 'rdp'); }
    finally {
      pending.current.delete(id);
      if (mounted.current) setPendingIds(Object.fromEntries([...pending.current].map((key) => [key, true])));
    }
  }
  return { pendingIds, isBusy: Object.keys(pendingIds).length > 0, open };
}
