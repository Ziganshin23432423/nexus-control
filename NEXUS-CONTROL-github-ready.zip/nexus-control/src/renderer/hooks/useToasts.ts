import { useCallback, useEffect, useRef, useState } from 'react';
import { ToastDeduplicator } from '../state/operationUx';
import type { Notify, ToastMessage } from '../state/demoTypes';

export function useToasts(): { toasts: readonly ToastMessage[]; notify: Notify; dismiss(id: string): void } {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const visible = useRef(new Map<string, string>());
  const deduplicator = useRef(new ToastDeduplicator());
  const timers = useRef(new Map<string, number>());

  const dismiss = useCallback((id: string): void => {
    const timer = timers.current.get(id);
    if (timer !== undefined) window.clearTimeout(timer);
    timers.current.delete(id);
    visible.current.delete(id);
    deduplicator.current.clear();
    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const notify = useCallback<Notify>((title, description, kind = 'info', options) => {
    const key = JSON.stringify([title, description, kind]);
    if ([...visible.current.values()].includes(key)) return;
    if (!deduplicator.current.accept(title, description, kind, Date.now())) return;
    const id = crypto.randomUUID(); visible.current.set(id, key);
    setToasts((current) => {
      for (const dropped of current.slice(0, Math.max(0, current.length - 2))) { const timer = timers.current.get(dropped.id); if (timer !== undefined) window.clearTimeout(timer); timers.current.delete(dropped.id); visible.current.delete(dropped.id); }
      return [...current.slice(-2), { id, title, description, kind, options }];
    });
    if (kind !== 'error' && kind !== 'warning') timers.current.set(id, window.setTimeout(() => dismiss(id), 4500));
  }, [dismiss]);

  useEffect(() => {
    const activeTimers = timers.current;
    return () => {
      activeTimers.forEach((timer) => window.clearTimeout(timer));
      activeTimers.clear();
    };
  }, []);

  return { toasts, notify, dismiss };
}
