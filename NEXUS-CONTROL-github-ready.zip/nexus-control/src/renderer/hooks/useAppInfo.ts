import { useEffect, useState } from 'react';
import type { AppInfo } from '../../shared/types';

interface AppInfoState {
  readonly info: AppInfo | null;
  readonly error: string | null;
}

export function useAppInfo(): AppInfoState & {retry(): void} {
  const [attempt, setAttempt] = useState(0);
  const [state, setState] = useState<AppInfoState>({ info: null, error: null });

  useEffect(() => {
    let active = true;
    async function loadInfo(): Promise<void> {
      try {
        const info = await window.nexus.getAppInfo();
        if (active) setState({ info, error: null });
      } catch {
        if (active) {
          setState({
            info: null,
            error: 'Не удалось связаться с приложением. Перезапустите NEXUS CONTROL.',
          });
        }
      }
    }
    void loadInfo();
    return () => {
      active = false;
    };
  }, [attempt]);

  return {...state, retry: () => setAttempt(current => current + 1)};
}
