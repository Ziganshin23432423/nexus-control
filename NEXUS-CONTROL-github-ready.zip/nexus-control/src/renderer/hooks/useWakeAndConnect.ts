import { notifyError } from '../state/notifyError';
import { removeProgress, SUCCESS_TITLES } from '../state/operationUx';
import { useEffect, useRef, useState } from 'react';
import type { WakeAndConnectProgress } from '../../shared/types';
import type { Notify } from '../state/demoTypes';
export function useWakeAndConnect(enabled: boolean, notify: Notify) {
  const [jobs, setJobs] = useState<Readonly<Record<string, WakeAndConnectProgress>>>({});
  const enabledRef = useRef(enabled); enabledRef.current=enabled;
  const pending = useRef(new Set<string>());
  const mounted = useRef(false);
  useEffect(() => {
    mounted.current = true;
    const unsubscribe = window.nexus.onWakeAndConnectProgress(progress => {
      if (mounted.current && pending.current.has(progress.computerId)) setJobs(current => ({ ...current, [progress.computerId]: progress }));
    });
    const active = pending.current;
    return () => { mounted.current = false; unsubscribe(); for (const id of active) void window.nexus.cancelWakeAndConnect(id).catch(() => {}); };
  }, []);
  async function start(id: string, service: 'rdp' | 'ssh'): Promise<void> {
    if (!enabledRef.current || pending.current.has(id)) return;
    pending.current.add(id); setJobs(current => ({ ...current, [id]: { computerId: id, service, phase: 'sending' } }));
    try {
      const reply = await (service === 'rdp' ? window.nexus.wakeAndOpenRemoteDesktop(id) : window.nexus.wakeAndOpenSshTerminal(id));
      if (!mounted.current) return;
      if (reply.ok) notify(SUCCESS_TITLES[service], 'Сигнал отправлен, служба ответила. Вход выполняется в стандартном клиенте.', 'success');
      else notifyError(notify, reply.error.code, () => { void start(id, service); }, service);
    } catch { if (mounted.current) notifyError(notify, 'NETWORK_ERROR', () => { void start(id, service); }, service); }
    finally {
      pending.current.delete(id);
      if (mounted.current) setJobs(current => removeProgress(current, id));
    }
  }
  async function cancel(id: string): Promise<void> {
    if (!enabledRef.current || !pending.current.has(id)) return;
    try { const reply = await window.nexus.cancelWakeAndConnect(id); if (!reply.ok && mounted.current) notifyError(notify, reply.error.code, () => { void cancel(id); }); }
    catch { if (mounted.current) notify('Не удалось отменить ожидание', 'Повторите попытку.', 'error'); }
  }
  return { jobs, isBusy: Object.keys(jobs).length > 0, start, cancel };
}
