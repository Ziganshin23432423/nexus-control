import { UdpWakeOnLanProvider } from '../providers/UdpWakeOnLanProvider.js';
import { WindowsSshProvider } from '../providers/windows/WindowsSshProvider.js';
import { WindowsRdpProvider } from '../providers/windows/WindowsRdpProvider.js';
import type { HostPlatform } from '../../shared/types.js';
import type { PlatformProviders, PlatformService } from '../providers/contracts.js';

const unavailableProviders: PlatformProviders = Object.freeze({
  remoteDesktop: null,
  ssh: null,
  wakeOnLan: null,
});

function getHostPlatform(runtimePlatform: NodeJS.Platform): HostPlatform {
  if (runtimePlatform === 'win32') return 'windows';
  if (runtimePlatform === 'linux') return 'linux';
  return 'unsupported';
}

/**
 * Composition boundary for native providers. Windows RDP and interactive SSH are implemented native capabilities.
 * Register Windows providers here in their assigned stages; Linux comes later.
 */
export function createPlatformService(runtimePlatform: NodeJS.Platform): PlatformService {
  return Object.freeze({
    hostPlatform: getHostPlatform(runtimePlatform),
    providers: runtimePlatform === 'win32' ? Object.freeze({ ...unavailableProviders, remoteDesktop: new WindowsRdpProvider(), ssh: new WindowsSshProvider(), wakeOnLan: new UdpWakeOnLanProvider() }) : unavailableProviders,
  });
}
