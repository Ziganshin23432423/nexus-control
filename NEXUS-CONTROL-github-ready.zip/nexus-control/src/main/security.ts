import type { BrowserWindow } from 'electron';
import { session } from 'electron';
import { APP_PROTOCOL, DEV_RENDERER_ORIGIN } from '../shared/constants';

export function isAppUrl(url: URL): boolean {
  // Node's WHATWG URL does not know Chromium's registered custom schemes:
  // their .origin is "null", so check the components explicitly.
  return (
    url.protocol === `${APP_PROTOCOL}:` &&
    url.hostname === 'app' &&
    url.port === '' &&
    url.username === '' &&
    url.password === ''
  );
}

export function getDevelopmentUrl(): string | undefined {
  const candidate = process.env['ELECTRON_RENDERER_URL'];
  if (!candidate) return undefined;

  const url = new URL(candidate);
  if (
    url.origin !== DEV_RENDERER_ORIGIN ||
    url.pathname !== '/' ||
    url.username !== '' ||
    url.password !== '' ||
    url.search !== '' ||
    url.hash !== ''
  ) {
    throw new Error('Development renderer must use the configured loopback address.');
  }

  return url.href;
}

export function contentSecurityPolicy(isDevelopment: boolean): string {
  // Only React Refresh needs inline scripts. Production never allows them.
  const scriptSource = isDevelopment ? "'self' 'unsafe-inline'" : "'self'";
  const styleSource = isDevelopment ? "'self' 'unsafe-inline'" : "'self'";
  const connectionSource = isDevelopment
    ? `${DEV_RENDERER_ORIGIN} ws://127.0.0.1:5173`
    : "'none'";

  return [
    "default-src 'none'",
    `script-src ${scriptSource}`,
    `style-src ${styleSource}`,
    "img-src 'self' data:",
    "font-src 'self'",
    `connect-src ${connectionSource}`,
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'none'",
    "frame-src 'none'",
    "frame-ancestors 'none'",
  ].join('; ');
}

export function configureSessionSecurity(isDevelopment: boolean): void {
  const appSession = session.defaultSession;
  appSession.setPermissionRequestHandler((_webContents, _permission, callback) => {
    callback(false);
  });
  appSession.setPermissionCheckHandler(() => false);
  appSession.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [contentSecurityPolicy(isDevelopment)],
      },
    });
  });

  // UI assets are local. Dev may access only its own loopback HMR server.
  appSession.webRequest.onBeforeRequest((details, callback) => {
    let allowed = false;
    try {
      const url = new URL(details.url);
      allowed =
        isAppUrl(url) ||
        (isDevelopment &&
          (url.origin === DEV_RENDERER_ORIGIN || url.origin === 'ws://127.0.0.1:5173'));
    } catch {
      allowed = false;
    }
    callback({ cancel: !allowed });
  });
}

export function protectWindow(window: BrowserWindow): void {
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event) => event.preventDefault());
  window.webContents.on('will-frame-navigate', (event) => event.preventDefault());
  window.webContents.on('will-redirect', (event) => event.preventDefault());
  window.webContents.on('will-attach-webview', (event) => event.preventDefault());
}
