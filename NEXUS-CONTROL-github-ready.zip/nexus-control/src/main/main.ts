import { WakeAndConnectService } from './services/wakeAndConnectService';
import { registerWakeAndConnectHandlers } from './ipc/registerWakeAndConnectHandlers';
import { WakeOnLanService } from './services/wakeOnLanService';
import { registerWakeHandlers } from './ipc/registerWakeHandlers';
import { registerSshHandlers } from './ipc/registerSshHandlers';
import { SshTerminalService } from './services/sshTerminalService';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { app, BrowserWindow, dialog, Menu, protocol } from 'electron';
import { APP_ENTRY_URL, APP_ID, APP_NAME, APP_PROTOCOL, IPC_CHANNELS } from '../shared/constants';
import { registerAppHandlers } from './ipc/registerAppHandlers';
import { registerRdpHandlers } from './ipc/registerRdpHandlers';
import { RemoteDesktopService } from './services/remoteDesktopService';
import { CheckCoordinator } from './services/checkCoordinator';
import { registerNetworkHandlers } from './ipc/registerNetworkHandlers';
import { registerComputerHandlers } from './ipc/registerComputerHandlers';
import { ComputerStore } from './services/computerStore';
import { createElectronStoreRepository } from './services/electronStoreRepository';
import { registerAppProtocol } from './protocol';
import { createPlatformService } from './platform/createPlatformService';
import { configureSessionSecurity, getDevelopmentUrl, protectWindow } from './security';

app.setName(APP_NAME);
if (process.platform === 'win32') app.setAppUserModelId(APP_ID);
protocol.registerSchemesAsPrivileged([
  { scheme: APP_PROTOCOL, privileges: { standard: true, secure: true, supportFetchAPI: true } },
]);

let mainWindow: BrowserWindow | null = null;

function reportStartupError(error: unknown): void {
  console.error('NEXUS CONTROL startup failed:', error);
  dialog.showErrorBox(APP_NAME, 'Не удалось запустить приложение. Перезапустите NEXUS CONTROL.');
  app.exit(1);
}

async function createMainWindow(rendererUrl: string): Promise<void> {
  const window = new BrowserWindow({
    title: APP_NAME,
    icon: app.isPackaged
      ? join(process.resourcesPath, 'icon.ico')
      : fileURLToPath(new URL('../../build/icon.ico', import.meta.url)),
    width: 1120,
    height: 760,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#0b1017',
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      preload: fileURLToPath(new URL('../preload/preload.cjs', import.meta.url)),
      nodeIntegration: false,
      nodeIntegrationInWorker: false,
      nodeIntegrationInSubFrames: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      webviewTag: false,
      spellcheck: false,
      devTools: !app.isPackaged,
    },
  });
  mainWindow = window;
  protectWindow(window);

  window.once('ready-to-show', () => window.show());
  window.once('closed', () => {
    mainWindow = null;
  });
  await window.loadURL(rendererUrl);
}

app.whenReady().then(async () => {
  const developmentUrl = app.isPackaged ? undefined : getDevelopmentUrl();
  const rendererUrl = developmentUrl ?? APP_ENTRY_URL;
  const isDevelopment = developmentUrl !== undefined;

  Menu.setApplicationMenu(null);
  configureSessionSecurity(isDevelopment);
  registerAppProtocol(fileURLToPath(new URL('../renderer', import.meta.url)));
  const handlerOptions = {
    getMainWindow: () => mainWindow,
    rendererUrl,
    isDevelopment,
    platformService: createPlatformService(process.platform),
  };
  registerAppHandlers(handlerOptions);
  const computerStore = new ComputerStore(createElectronStoreRepository(app.getPath('userData')));
  const checks = new CheckCoordinator(computerStore);
  const pendingLaunches = new Map<string, AbortController>();
  const remoteDesktop = new RemoteDesktopService(computerStore, checks, handlerOptions.platformService.providers.remoteDesktop, pendingLaunches);
  const sshTerminal = new SshTerminalService(computerStore, checks, handlerOptions.platformService.providers.ssh, pendingLaunches);
  const workflowClaims = new Set<string>();
  const wake = new WakeOnLanService(computerStore, handlerOptions.platformService.providers.wakeOnLan, workflowClaims);
  const wakeAndConnect = new WakeAndConnectService(computerStore, checks, wake, remoteDesktop, sshTerminal,
    handlerOptions.platformService.providers, pendingLaunches, workflowClaims, undefined, progress => {
      const window = handlerOptions.getMainWindow();
      if (window && !window.isDestroyed() && window.webContents.getURL() === rendererUrl) window.webContents.send(IPC_CHANNELS.wakeAndConnectProgress, progress);
    });
  const cancelPending = (): void => { checks.cancel(); remoteDesktop.cancelPending(); sshTerminal.cancelPending(); wake.cancelPending(); wakeAndConnect.cancelAll(); };
  registerComputerHandlers(handlerOptions, computerStore, id => {
    checks.cancel();
    if (id) { pendingLaunches.get(id)?.abort(); wake.cancel(id); wakeAndConnect.cancel(id); }
  });
  registerRdpHandlers(handlerOptions, remoteDesktop);
  registerSshHandlers(handlerOptions, sshTerminal);
  registerWakeHandlers(handlerOptions, wake);
  registerWakeAndConnectHandlers(handlerOptions, wakeAndConnect);
  registerNetworkHandlers(handlerOptions, checks);
  app.on('before-quit', cancelPending);
  await createMainWindow(rendererUrl);
  mainWindow?.once('closed', cancelPending);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      void createMainWindow(rendererUrl).catch(reportStartupError);
    }
  });
}).catch(reportStartupError);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
