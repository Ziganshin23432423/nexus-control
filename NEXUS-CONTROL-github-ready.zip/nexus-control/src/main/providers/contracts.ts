import type { HostPlatform, WakeOnLanConfig } from '../../shared/types.js';

/** Main-process services validate inputs before handing them to a provider. */
export interface RemoteDesktopTarget {
  readonly host: string;
  readonly port: number;
  readonly signal?: AbortSignal;
}

export interface SshTarget {
  readonly host: string;
  readonly port: number;
  readonly username: string;
  readonly signal?: AbortSignal;
}

export interface WakeOnLanRequest extends WakeOnLanConfig {
  readonly macAddress: string;
  readonly packet: Uint8Array;
  readonly signal?: AbortSignal;
}

/** Resolves after launching the client; authentication belongs to the client. */
export interface RemoteDesktopProvider {
  readonly id: string;
  open(target: RemoteDesktopTarget): Promise<void>;
}

export interface SshProvider {
  readonly id: string;
  open(target: SshTarget): Promise<void>;
}

/** UDP transport only. Packet generation and wake/wait/connect remain common. */
export interface WakeOnLanProvider {
  readonly id: string;
  send(request: WakeOnLanRequest): Promise<void>;
}

/** A null slot means the capability is not implemented or available. */
export interface PlatformProviders {
  readonly remoteDesktop: RemoteDesktopProvider | null;
  readonly ssh: SshProvider | null;
  readonly wakeOnLan: WakeOnLanProvider | null;
}

export interface PlatformService {
  readonly hostPlatform: HostPlatform;
  readonly providers: PlatformProviders;
}
