import { createSocket } from 'node:dgram';
import { createMagicPacket } from '../../shared/magicPacket.js';
import { isValidIpv4, isValidPort } from '../../shared/validation.js';
import type { WakeOnLanProvider, WakeOnLanRequest } from './contracts.js';
import { WakeOnLanError } from '../services/wakeOnLanError.js';

export interface WakeSocket {
  onError(callback: () => void): () => void;
  onClose(callback: () => void): () => void;
  bind(port: 0, callback: () => void): void;
  setBroadcast(value: true): void;
  send(packet: Uint8Array, port: number, address: string, callback: (error: Error | null) => void): void;
  close(): void;
}
export interface WakeTransportDependencies {
  readonly socketFactory: () => WakeSocket;
  readonly schedule: (callback: () => void, milliseconds: number) => () => void;
}
const dependencies: WakeTransportDependencies = {
  socketFactory: () => {
    const socket = createSocket('udp4');
    return {
      onError: callback => { socket.on('error', callback); return () => socket.removeListener('error', callback); },
      onClose: callback => { socket.once('close', callback); return () => socket.removeListener('close', callback); },
      bind: (port, callback) => { socket.bind(port, callback); },
      setBroadcast: value => { socket.setBroadcast(value); },
      send: (packet, port, address, callback) => { socket.send(packet, port, address, callback); },
      close: () => { socket.close(); },
    };
  },
  schedule: (callback, milliseconds) => { const timer = setTimeout(callback, milliseconds); return () => clearTimeout(timer); },
};
const failure = () => new WakeOnLanError('WOL_SEND_ERROR', 'Не удалось отправить Magic Packet. Проверьте настройки сети и повторите попытку.');

/** Main-only fixed UDP4 burst. It never checks, waits for, or marks a PC online. */
export class UdpWakeOnLanProvider implements WakeOnLanProvider {
  readonly id = 'node-udp4-wol';
  constructor(private readonly deps: WakeTransportDependencies = dependencies) {}
  async send(request: WakeOnLanRequest): Promise<void> {
    const { broadcastAddress, port, signal } = request;
    let packet: Uint8Array;
    try { packet = createMagicPacket(request.macAddress); }
    catch { throw new WakeOnLanError('WOL_SEND_ERROR', 'Некорректный MAC-адрес Wake-on-LAN.'); }
    if (!isValidIpv4(broadcastAddress) || !isValidPort(port) || request.packet.length !== 102 || !packet.every((byte, i) => byte === request.packet[i])) throw failure();
    if (signal?.aborted) throw new WakeOnLanError('CANCELLED', 'Отправка Wake-on-LAN отменена.');
    return new Promise<void>((resolve, reject) => {
      let socket: WakeSocket;
      try { socket = this.deps.socketFactory(); } catch { reject(failure()); return; }
      let finished = false;
      let settled = false;
      let outcome: WakeOnLanError | null = null;
      let cancelDeadline: (() => void) | undefined;
      let cancelDelay: (() => void) | undefined;
      const unsubscribe: (() => void)[] = [];
      const settle = (): void => {
        if (settled) return; settled = true;
        cancelDeadline?.(); cancelDelay?.(); signal?.removeEventListener('abort', abort);
        unsubscribe.forEach(remove => remove());
        if (outcome) reject(outcome); else resolve();
      };
      const finish = (error: WakeOnLanError | null): void => {
        if (finished) return; finished = true; outcome = error;
        cancelDeadline?.(); cancelDelay?.(); signal?.removeEventListener('abort', abort);
        // Keep error handling until close, including queued bind/send errors.
        try { socket.close(); }
        catch { outcome ??= failure(); settle(); } // dgram throws if a failed bind left no handle.
      };
      const abort = (): void => finish(new WakeOnLanError('CANCELLED', 'Отправка Wake-on-LAN отменена.'));
      let sent = 0;
      const sendNext = (): void => {
        if (finished) return;
        try {
          socket.send(packet, port, broadcastAddress, error => {
            if (finished) return;
            if (error) { finish(failure()); return; }
            sent++;
            if (sent === 3) finish(null);
            else { try { cancelDelay = this.deps.schedule(sendNext, 100); } catch { finish(failure()); } }
          });
        } catch { finish(failure()); }
      };
      try {
        unsubscribe.push(socket.onError(() => finish(failure())));
        unsubscribe.push(socket.onClose(() => { if (!finished) { finished = true; outcome = failure(); } settle(); }));
        cancelDeadline = this.deps.schedule(() => finish(new WakeOnLanError('WOL_TIMEOUT', 'Отправка Magic Packet заняла слишком много времени. Попробуйте ещё раз.')), 2500);
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        socket.bind(0, () => {
          if (finished) return;
          try { socket.setBroadcast(true); sendNext(); } catch { finish(failure()); }
        });
      } catch { finish(failure()); }
    });
  }
}
