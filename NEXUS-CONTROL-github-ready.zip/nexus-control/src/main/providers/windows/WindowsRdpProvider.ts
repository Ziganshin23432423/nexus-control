import { spawn } from 'node:child_process';
import type { SpawnOptions } from 'node:child_process';
import { stat } from 'node:fs/promises';
import { isTrustedWindowsDirectory } from './trustedWindowsPath.js';
import { win32 } from 'node:path';
import { isValidAddress } from '../../../shared/validation.js';
import type { RemoteDesktopProvider, RemoteDesktopTarget } from '../contracts.js';
import { CheckCancelledError } from '../../services/networkService.js';
import { RdpError } from '../../services/rdpError.js';

/** No PATH search or renderer-supplied executable. Environment belongs to main. */
export async function findWindowsRdpClient(
  environment: NodeJS.ProcessEnv = process.env,
  isFile: (path: string) => Promise<boolean> = async (path) => (await stat(path)).isFile(),
): Promise<string> {
  const root = environment.SystemRoot;
  if (!isTrustedWindowsDirectory(root)) {
    throw new RdpError('RDP_CLIENT_MISSING', 'Не удалось определить системную папку Windows для RDP-клиента.');
  }
  const executable = win32.join(root, 'System32', 'mstsc.exe');
  try { if (await isFile(executable)) return executable; } catch { /* Missing/inaccessible client is a controlled error. */ }
  throw new RdpError('RDP_CLIENT_MISSING', 'Стандартный RDP-клиент Windows не найден или недоступен.');
}

export interface RdpChild {
  once(event: 'spawn', listener: () => void): unknown;
  on(event: 'error', listener: (error: Error) => void): unknown;
  unref(): void;
}
export type SpawnRdpProcess = (executable: string, args: readonly string[], options: SpawnOptions) => RdpChild;
export function launchWindowsRdpClient(executable: string, args: readonly string[], spawnProcess: SpawnRdpProcess = spawn): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const child = spawnProcess(executable, args, { shell: false, detached: true, stdio: 'ignore', windowsHide: false });
      // Keep the error listener after spawn: later process errors must not crash NEXUS.
      child.on('error', () => reject(new RdpError('RDP_LAUNCH_ERROR', 'Не удалось открыть RDP-клиент Windows.')));
      child.once('spawn', () => { child.unref(); resolve(); });
      // Node reaps the process; no pipes/session wait and no kill on NEXUS shutdown.
    } catch { reject(new RdpError('RDP_LAUNCH_ERROR', 'Не удалось открыть RDP-клиент Windows.')); }
  });
}

export class WindowsRdpProvider implements RemoteDesktopProvider {
  readonly id = 'windows-mstsc';
  constructor(
    private readonly findClient: () => Promise<string> = findWindowsRdpClient,
    private readonly launch: (executable: string, args: readonly string[]) => Promise<void> = launchWindowsRdpClient,
  ) {}
  async open(target: RemoteDesktopTarget): Promise<void> {
    if (!isValidAddress(target.host) || target.port !== 3389) throw new RdpError('RDP_LAUNCH_ERROR', 'Некорректный адрес RDP-подключения.');
    if (target.signal?.aborted) throw new CheckCancelledError();
    const executable = await this.findClient();
    if (target.signal?.aborted) throw new CheckCancelledError();
    await this.launch(executable, [`/v:${target.host}`]);
  }
}
