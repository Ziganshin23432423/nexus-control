import { spawn } from 'node:child_process';
import type { SpawnOptions } from 'node:child_process';
import { isValidAddress, isValidUsername } from '../../../shared/validation.js';
import type { SshProvider, SshTarget } from '../contracts.js';
import { CheckCancelledError } from '../../services/networkService.js';
import { SshError } from '../../services/sshError.js';
import { findWindowsSshClients } from './windowsSshDiscovery.js';
import type { WindowsSshClients } from './windowsSshDiscovery.js';

export interface SshHostChild {
  once(event: 'spawn', listener: () => void): unknown;
  on(event: 'error', listener: (error: Error) => void): unknown;
  unref(): void;
}
export type SpawnSshHost = (executable: string, args: readonly string[], options: SpawnOptions) => SshHostChild;
export function launchWindowsSshHost(executable: string, args: readonly string[], spawnHost: SpawnSshHost = spawn): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const child = spawnHost(executable, args, { shell: false, detached: true, stdio: 'ignore', windowsHide: false });
      child.on('error', () => reject(new SshError('SSH_LAUNCH_ERROR', 'Не удалось открыть SSH-терминал.')));
      child.once('spawn', () => { child.unref(); resolve(); });
    } catch { reject(new SshError('SSH_LAUNCH_ERROR', 'Не удалось открыть SSH-терминал.')); }
  });
}

/** Only an interactive login. No command, script, password or arbitrary option. */
export class WindowsSshProvider implements SshProvider {
  readonly id = 'windows-openssh';
  constructor(
    private readonly discover: () => Promise<WindowsSshClients> = findWindowsSshClients,
    private readonly launch: (executable: string, args: readonly string[]) => Promise<void> = launchWindowsSshHost,
  ) {}
  async open(target: SshTarget): Promise<void> {
    const { host, username, port, signal } = target;
    if (!isValidAddress(host) || !isValidUsername(username) || port !== 22) throw new SshError('SSH_LAUNCH_ERROR', 'Некорректные параметры SSH-подключения.');
    if (signal?.aborted) throw new CheckCancelledError();
    const clients = await this.discover();
    if (signal?.aborted) throw new CheckCancelledError();
    // -l avoids interpreting UPN username's @ as the destination separator.
    // -- ends SSH options; nothing follows destination (no remote command).
    const sshArgs = ['-l', username, '-p', '22', '--', host];
    if (clients.terminal) {
      await this.launch(clients.terminal, ['-w', '-1', 'new-tab', '--', clients.ssh, ...sshArgs]);
    } else if (clients.consoleHost) {
      // Conhost creates fresh console I/O handles for its client. No shell involved.
      await this.launch(clients.consoleHost, ['--', clients.ssh, ...sshArgs]);
    } else throw new SshError('SSH_HOST_MISSING', 'Не найдено доступное консольное окно для SSH.');
  }
}
