import { stat, lstat } from 'node:fs/promises';
import { win32 } from 'node:path';
import { SshError } from '../../services/sshError.js';

import { isTrustedWindowsDirectory } from './trustedWindowsPath.js';

export interface WindowsSshClients {
  readonly ssh: string;
  readonly terminal: string | null;
  readonly consoleHost: string | null;
}
export interface WindowsSshDiscoveryDependencies {
  readonly environment: NodeJS.ProcessEnv;
  readonly isFile: (path: string) => Promise<boolean>;
  readonly isAlias: (path: string) => Promise<boolean>;
}
const defaults: WindowsSshDiscoveryDependencies = {
  environment: process.env,
  isFile: async path => (await stat(path)).isFile(),
  // App Execution Alias is a reparse point: inspect it without resolving its target.
  isAlias: async path => { const entry = await lstat(path); return entry.isFile() || entry.isSymbolicLink(); },
};
async function exists(check: (path: string) => Promise<boolean>, path: string): Promise<boolean> {
  try { return await check(path); } catch { return false; }
}
export async function findWindowsSshClients(deps: WindowsSshDiscoveryDependencies = defaults): Promise<WindowsSshClients> {
  const root = deps.environment.SystemRoot;
  if (!isTrustedWindowsDirectory(root)) throw new SshError('SSH_CLIENT_MISSING', 'OpenSSH Client не найден. Не удалось определить системную папку Windows.');
  const ssh = win32.join(root, 'System32', 'OpenSSH', 'ssh.exe');
  if (!await exists(deps.isFile, ssh)) throw new SshError('SSH_CLIENT_MISSING', 'OpenSSH Client не найден. Установите штатный клиент в дополнительных компонентах Windows.');
  const local = deps.environment.LOCALAPPDATA;
  const alias = isTrustedWindowsDirectory(local) ? win32.join(local, 'Microsoft', 'WindowsApps', 'wt.exe') : null;
  const terminal = alias && await exists(deps.isAlias, alias) ? alias : null;
  // Console Host is only needed if the standard Terminal alias is absent.
  const consolePath = win32.join(root, 'System32', 'conhost.exe');
  const consoleHost = !terminal && await exists(deps.isFile, consolePath) ? consolePath : null;
  if (!terminal && !consoleHost) throw new SshError('SSH_HOST_MISSING', 'Не найдено доступное консольное окно для SSH. Проверьте Windows Terminal или системный Console Host.');
  return { ssh, terminal, consoleHost };
}
