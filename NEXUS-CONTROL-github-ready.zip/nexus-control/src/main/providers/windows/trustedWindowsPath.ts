/** Host-owned standard directories only; never expand variables or search PATH. */
export function isTrustedWindowsDirectory(value: string | undefined): value is string {
  if (!value || !/^[a-z]:\\[^<>:"|?*%/\u0000-\u001f;]+$/i.test(value)) return false;
  return value.slice(3).split('\\').every(part => !!part && part !== '.' && part !== '..' &&
    !/[. ]$/.test(part) && !/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part));
}
