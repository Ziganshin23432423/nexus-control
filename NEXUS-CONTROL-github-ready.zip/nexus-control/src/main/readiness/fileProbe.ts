import { randomUUID } from 'node:crypto';
import { mkdir, open, unlink } from 'node:fs/promises';
import { join } from 'node:path';
/** Remove only a file this probe successfully created exclusively. Existing files stay untouched. */
export async function exclusiveWritableProbe(directory:string,token:string=randomUUID()):Promise<boolean>{
 if(!/^[a-zA-Z0-9-]+$/.test(token))throw new Error('Invalid probe token');
 await mkdir(directory,{recursive:true});
 const owned=join(directory,`nexus-smoke-${token}.tmp`);
 const handle=await open(owned,'wx');
 try{await handle.writeFile('diagnostic');return true;}
 finally{await handle.close().catch(()=>{});await unlink(owned).catch(()=>{});}
}
