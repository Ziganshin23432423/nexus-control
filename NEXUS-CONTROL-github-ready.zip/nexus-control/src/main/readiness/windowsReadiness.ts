import { win32 } from 'node:path';
import { isTrustedWindowsDirectory } from '../providers/windows/trustedWindowsPath.js';
export type SmokeStatus = 'PASS' | 'WARN' | 'FAIL';
export type SmokeScenario = 'app' | 'rdp' | 'ssh' | 'wol' | 'all';
export interface SmokeCheck { readonly id:string; readonly status:SmokeStatus; readonly message:string }
export interface SmokeReport { readonly platform:string;readonly architecture:string;readonly version:string;readonly scenario:SmokeScenario;readonly checks:readonly SmokeCheck[] }
export interface ReadinessDependencies {
  readonly platform:string;readonly architecture:string;readonly version:string;readonly scenario:SmokeScenario;
  readonly environment:Readonly<Record<string,string|undefined>>;
  isFile(path:string):Promise<boolean>; isAlias(path:string):Promise<boolean>;
  sourceSafe():Promise<boolean>; buildReady():Promise<boolean>; userDataWritable():Promise<boolean>;
  rendererStorage():Promise<boolean>; udpLifecycle():Promise<boolean>;
}
export async function runWindowsReadiness(deps:ReadinessDependencies):Promise<SmokeReport> {
  const checks:SmokeCheck[]=[];
  const add=(id:string,status:SmokeStatus,message:string):void=>{checks.push({id,status,message});};
  const probe=async(task:()=>Promise<boolean>):Promise<boolean>=>{try{return await task();}catch{return false;}};
  add('host',deps.platform==='win32'?'PASS':'FAIL',deps.platform==='win32'?'Windows: платформа подтверждена.':'Нужна Windows; этот результат не является проверкой Windows hardware.');
  add('architecture',['x64','arm64'].includes(deps.architecture)?'PASS':'WARN',`Архитектура: ${deps.architecture}.`);
  add('version','PASS',`NEXUS ${deps.version}.`);
  for(const [id,task] of [['source',()=>deps.sourceSafe()],['build',()=>deps.buildReady()],['userData',()=>deps.userDataWritable()],['appearance',()=>deps.rendererStorage()]] as const) {
    const ok=await probe(task);add(id,ok?'PASS':'FAIL',ok?`${id}: диагностическая проверка пройдена.`:`${id}: проверка не пройдена; см. WINDOWS-SMOKE.md.`);
  }
  if(deps.platform==='win32') {
    const rdp=deps.scenario==='all'||deps.scenario==='rdp',ssh=deps.scenario==='all'||deps.scenario==='ssh';
    const root=deps.environment['SystemRoot'];const valid=isTrustedWindowsDirectory(root);
    add('SystemRoot',valid?'PASS':rdp||ssh?'WARN':'PASS',valid?'Системный каталог Windows корректен.':rdp||ssh?'Системный каталог Windows отсутствует или некорректен.':'Системный каталог недоступен; для выбранного сценария он не нужен.');
    const found=async(name:string):Promise<boolean>=>valid&&await probe(()=>deps.isFile(win32.join(root,'System32',name)));
    const mstsc=await found('mstsc.exe'), openssh=await found('OpenSSH\\ssh.exe'),conhost=await found('conhost.exe');
    const local=deps.environment['LOCALAPPDATA'];const terminal=isTrustedWindowsDirectory(local)&&await probe(()=>deps.isAlias(win32.join(local,'Microsoft','WindowsApps','wt.exe')));
    add('mstsc',mstsc?'PASS':rdp?'WARN':'PASS',mstsc?'mstsc.exe найден, запуск не выполнялся.':rdp?'mstsc.exe отсутствует или недоступен.':'mstsc.exe отсутствует; RDP не выбран.');
    add('ssh',openssh?'PASS':ssh?'WARN':'PASS',openssh?'OpenSSH Client найден, запуск не выполнялся.':ssh?'OpenSSH Client отсутствует или недоступен.':'OpenSSH Client отсутствует; SSH не выбран.');
    add('terminal',terminal?'PASS':ssh&&!conhost?'WARN':'PASS',terminal?'Alias Windows Terminal найден; активация не проверялась.':conhost?'Alias Terminal отсутствует; найден резервный Console Host.':ssh?'Alias Terminal недоступен; резервный Console Host не найден.':'Alias Terminal отсутствует; SSH не выбран.');
    add('conhost',conhost?'PASS':ssh&&!terminal?'WARN':'PASS',conhost?'Console Host найден, запуск не выполнялся.':terminal?'Console Host отсутствует; при наличии Terminal он не обязателен.':ssh?'Console Host отсутствует или недоступен.':'Console Host отсутствует; SSH не выбран.');
    if(deps.scenario==='all'||deps.scenario==='wol') {const ok=await probe(()=>deps.udpLifecycle());add('udp',ok?'PASS':'WARN',ok?'UDP4 bind/close доступен; ни одного пакета не отправлено.':'UDP4 bind/close недоступен; Magic Packet не отправлен.');}
  }
  return {platform:deps.platform,architecture:deps.architecture,version:deps.version,scenario:deps.scenario,checks};
}
export function smokeExitCode(report:SmokeReport):number{return report.checks.some(row=>row.status==='FAIL')?1:0;}
export function smokeSummary(report:SmokeReport):string{return report.checks.map(row=>`${row.status.padEnd(4)} ${row.id}: ${row.message}`).join('\n');}
