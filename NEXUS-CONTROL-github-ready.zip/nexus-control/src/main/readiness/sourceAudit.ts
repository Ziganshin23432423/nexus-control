import { readdir, readFile } from 'node:fs/promises';
import { extname, posix, relative, resolve } from 'node:path';
const excluded = new Set(['node_modules','out','dist','release','coverage','.git','.test-out','.smoke-out']);
export async function projectEntries(root: string): Promise<string[]> {
  const entries: string[] = [];
  async function walk(directory: string): Promise<void> {
    for (const item of await readdir(directory, { withFileTypes: true })) {
      if (excluded.has(item.name) || item.isSymbolicLink()) continue;
      const path = resolve(directory, item.name);
      entries.push(relative(root, path).replaceAll('\\','/'));
      if (item.isDirectory()) await walk(path);
    }
  }
  await walk(root); return entries;
}
export function filenameIssues(entries: readonly string[]): string[] {
  const errors: string[] = [], paths = new Map<string,string>(), stems = new Map<string,string>();
  for (const path of entries) {
    const key = path.toLowerCase();
    if (paths.has(key)) errors.push(`Case collision: ${paths.get(key)} / ${path}`);
    paths.set(key,path);
    if (/\.(tsx?|jsx?|mjs|cjs)$/.test(path)) {
      const stem = path.replace(/\.(tsx?|jsx?|mjs|cjs)$/,'').toLowerCase();
      if (stems.has(stem)) errors.push(`Module collision: ${stems.get(stem)} / ${path}`);
      stems.set(stem,path);
    }
  }
  return errors;
}
/** Check exact relative import/asset spelling. TypeScript .js specifiers map to .ts sources. */
export function referenceIssues(file: string, source: string, entries: readonly string[]): string[] {
  const exact = new Set(entries), folded = new Map(entries.map(path => [path.toLowerCase(),path]));
  const issues: string[] = [];
  const references = [...source.matchAll(/(?:\bfrom\s*|\bimport\s*\(?|\brequire\s*\()\s*['"](\.[^'"]+)['"]/g)].map(match=>match[1]!);
  if (/\.css$/.test(file)) references.push(...[...source.matchAll(/url\(\s*['"]?(\.[^'")\s]+)['"]?\s*\)/g)].map(match=>match[1]!));
  if (/\.html$/.test(file)) references.push(...[...source.matchAll(/(?:href|src)=["'](\.[^"']+)["']/g)].map(match=>match[1]!));
  for (const reference of references) {
    const base = posix.normalize(posix.join(posix.dirname(file), reference));
    const candidates = /\.js$/.test(base) ? [base,base.slice(0,-3)+'.ts',base.slice(0,-3)+'.tsx'] : extname(base) ? [base] : [base+'.ts',base+'.tsx',base+'.js',base+'/index.ts',base+'/index.tsx'];
    if (/\.html$/.test(file) && base.endsWith('.svg')) candidates.push(posix.join(posix.dirname(file),'public',posix.basename(base)));
    if (candidates.some(path=>exact.has(path))) continue;
    if (candidates.some(path=>folded.has(path.toLowerCase()))) issues.push(`Reference case mismatch in ${file}: ${reference}`);
    // Unresolved references are already checked by TS/Vite; this scan targets Windows case ambiguity.
  }
  return issues;
}
export async function auditProject(root: string): Promise<string[]> {
  const entries = await projectEntries(root), issues = filenameIssues(entries);
  for (const file of entries.filter(path=>/\.(tsx?|jsx?|cjs|mjs|html|css)$/.test(path))) issues.push(...referenceIssues(file,await readFile(resolve(root,file),'utf8'),entries));
  return issues;
}
export function archiveMemberIssues(names: readonly string[]): string[] {
  return names.filter(name => {
    const parts=name.replaceAll('\\','/').split('/');
    return name.startsWith('/') || parts.includes('..') || parts.some(part=>excluded.has(part)||/^(?:cache|\.cache|profiles?|qa-user-data)$/i.test(part)) ||
      /(?:^|\/)starfield\.ts$/i.test(name) || /(?:^|\/)(?:\.env(?:\..*)?|.*\.tsbuildinfo|.*\.zip)$/i.test(name);
  });
}
