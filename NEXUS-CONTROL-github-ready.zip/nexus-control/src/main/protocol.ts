import { readFile } from 'node:fs/promises';
import { extname, isAbsolute, relative, resolve, sep } from 'node:path';
import { protocol } from 'electron';
import { APP_PROTOCOL } from '../shared/constants';
import { contentSecurityPolicy, isAppUrl } from './security';

const contentTypes: Readonly<Record<string, string>> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2',
};

export function registerAppProtocol(rendererDirectory: string): void {
  protocol.handle(APP_PROTOCOL, async (request) => {
    const url = new URL(request.url);
    if (!isAppUrl(url) || request.method !== 'GET') {
      return new Response('Forbidden', { status: 403 });
    }

    let pathname: string;
    try {
      pathname = decodeURIComponent(url.pathname);
    } catch {
      return new Response('Bad request', { status: 400 });
    }
    if (pathname.includes('\0') || pathname.includes('\\')) {
      return new Response('Bad request', { status: 400 });
    }

    const filePath = resolve(rendererDirectory, `.${pathname}`);
    const relativePath = relative(rendererDirectory, filePath);
    if (isAbsolute(relativePath) || relativePath === '..' || relativePath.startsWith(`..${sep}`)) {
      return new Response('Forbidden', { status: 403 });
    }

    try {
      const contentType = contentTypes[extname(filePath)];
      if (!contentType) return new Response('Not found', { status: 404 });
      const contents = await readFile(filePath);
      return new Response(new Uint8Array(contents), {
        headers: {
          'Content-Type': contentType,
          'Content-Security-Policy': contentSecurityPolicy(false),
          'X-Content-Type-Options': 'nosniff',
        },
      });
    } catch {
      return new Response('Not found', { status: 404 });
    }
  });
}
