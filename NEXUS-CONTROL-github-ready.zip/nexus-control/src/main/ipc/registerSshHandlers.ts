import { ipcMain } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import type { SshTerminalService } from '../services/sshTerminalService';
import { assertTrustedSender } from './registerAppHandlers';
import type { AppHandlerOptions } from './registerAppHandlers';
import { createSshRequestHandler } from './sshRequest';

export function registerSshHandlers(options: AppHandlerOptions, service: SshTerminalService): void {
  ipcMain.handle(IPC_CHANNELS.openSshTerminal, createSshRequestHandler((event) => assertTrustedSender(event, options), service));
}
