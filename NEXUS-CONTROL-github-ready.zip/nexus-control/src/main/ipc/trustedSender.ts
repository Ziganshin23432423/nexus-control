/** Identity checks are intentionally stricter than checking the URL alone. */
export function isTrustedIpcSender(
  event: { readonly sender: unknown; readonly senderFrame: { readonly url: string } | null },
  window: { isDestroyed(): boolean; readonly webContents: { readonly mainFrame: unknown } } | null,
  rendererUrl: string,
): boolean {
  return window !== null && !window.isDestroyed() && !!event.senderFrame &&
    event.sender === window.webContents && event.senderFrame === window.webContents.mainFrame &&
    event.senderFrame.url === rendererUrl;
}
