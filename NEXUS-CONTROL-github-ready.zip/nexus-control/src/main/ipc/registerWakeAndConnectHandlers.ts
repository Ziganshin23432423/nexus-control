import { ipcMain } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import type { WakeAndConnectService } from '../services/wakeAndConnectService';
import { assertTrustedSender } from './registerAppHandlers';
import type { AppHandlerOptions } from './registerAppHandlers';
import { createWakeAndConnectRequestHandler } from './wakeAndConnectRequest';
export function registerWakeAndConnectHandlers(options: AppHandlerOptions, service: WakeAndConnectService): void {
  const guard = (event: Electron.IpcMainInvokeEvent): void => assertTrustedSender(event, options);
  ipcMain.handle(IPC_CHANNELS.wakeAndOpenRemoteDesktop, createWakeAndConnectRequestHandler(guard, id => service.openRdp(id)));
  ipcMain.handle(IPC_CHANNELS.wakeAndOpenSshTerminal, createWakeAndConnectRequestHandler(guard, id => service.openSsh(id)));
  ipcMain.handle(IPC_CHANNELS.cancelWakeAndConnect, createWakeAndConnectRequestHandler(guard, id => service.cancel(id)));
}
