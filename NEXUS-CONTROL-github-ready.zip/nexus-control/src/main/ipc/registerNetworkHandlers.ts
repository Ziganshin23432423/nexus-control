import { ipcMain } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import type { IpcResult } from '../../shared/types';
import { ComputerStoreError } from '../services/computerStore';
import { StorageFormatError } from '../services/storageSchema';
import { CheckCancelledError } from '../services/networkService';
import type { CheckCoordinator } from '../services/checkCoordinator';
import { assertTrustedSender } from './registerAppHandlers';
import type { AppHandlerOptions } from './registerAppHandlers';
import { executeStoreOperation } from './registerComputerHandlers';

async function executeNetworkOperation<T>(operation: () => Promise<T>): Promise<IpcResult<T>> {
  try { return { ok: true, value: await operation() }; }
  catch (error) {
    if (error instanceof CheckCancelledError) return { ok: false, error: { code: 'CANCELLED', message: 'Проверка отменена.' } };
    if (error instanceof ComputerStoreError || error instanceof StorageFormatError || error instanceof SyntaxError || (typeof error === 'object' && error !== null && 'code' in error && ['ENOENT', 'EACCES', 'EPERM'].includes(String(error.code)))) return executeStoreOperation(() => { throw error; });
    return { ok: false, error: { code: 'NETWORK_ERROR', message: 'Не удалось выполнить проверку. Попробуйте обновить статусы ещё раз.' } };
  }
}
export function registerNetworkHandlers(options: AppHandlerOptions, coordinator: CheckCoordinator): void {
  ipcMain.handle(IPC_CHANNELS.checkComputerStatus, (event, id: unknown) => { assertTrustedSender(event, options); return executeNetworkOperation(() => coordinator.checkComputerStatus(id)); });
  ipcMain.handle(IPC_CHANNELS.refreshAllComputerStatuses, (event) => { assertTrustedSender(event, options); return executeNetworkOperation(() => coordinator.refreshAllComputerStatuses()); });
  ipcMain.handle(IPC_CHANNELS.cancelComputerStatusChecks, (event) => { assertTrustedSender(event, options); coordinator.cancel(); });
}
