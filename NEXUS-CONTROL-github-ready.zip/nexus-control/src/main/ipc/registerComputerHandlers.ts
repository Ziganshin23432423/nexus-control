import { ipcMain } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import type { IpcResult } from '../../shared/types';
import { ComputerStoreError } from '../services/computerStore';
import type { ComputerStore } from '../services/computerStore';
import { assertTrustedSender } from './registerAppHandlers';
import type { AppHandlerOptions } from './registerAppHandlers';

export function executeStoreOperation<T>(operation: () => T): IpcResult<T> {
  try { return { ok: true, value: operation() }; }
  catch (error) {
    if (error instanceof ComputerStoreError) return { ok: false, error: {
      code: error.code, message: error.message, ...(error.fieldErrors ? { fieldErrors: error.fieldErrors } : {}),
    } };
    return { ok: false, error: { code: 'STORAGE_ERROR', message: 'Не удалось прочитать или сохранить компьютеры. Файл может быть недоступен, повреждён или создан более новой версией. Исходные данные сохранены; проверьте файл и повторите попытку.' } };
  }
}
export function registerComputerHandlers(options: AppHandlerOptions, store: ComputerStore, onMutation: (computerId?: string) => void = () => {}): void {
  ipcMain.handle(IPC_CHANNELS.listComputers, (event) => { assertTrustedSender(event, options); return executeStoreOperation(() => store.list()); });
  ipcMain.handle(IPC_CHANNELS.createComputer, (event, input: unknown) => { assertTrustedSender(event, options); const result = executeStoreOperation(() => store.create(input)); if (result.ok) onMutation(); return result; });
  ipcMain.handle(IPC_CHANNELS.updateComputer, (event, id: unknown, input: unknown) => { assertTrustedSender(event, options); const result = executeStoreOperation(() => store.update(id, input)); if (result.ok) onMutation(result.value.id); return result; });
  ipcMain.handle(IPC_CHANNELS.deleteComputer, (event, id: unknown) => { assertTrustedSender(event, options); const result = executeStoreOperation(() => store.delete(id)); if (result.ok) onMutation(typeof id === 'string' ? id : undefined); return result; });
}
