import type { IpcResult, WakeComputerResult } from '../../shared/types.js';
import { ComputerStoreError } from '../services/computerStore.js';
import { StorageFormatError } from '../services/storageSchema.js';
import { WakeOnLanError } from '../services/wakeOnLanError.js';
import type { WakeOnLanService } from '../services/wakeOnLanService.js';

export function createWakeRequestHandler<Event>(assertSender: (event: Event) => void, service: Pick<WakeOnLanService, 'wake'>) {
  return async (event: Event, id: unknown, ...extra: unknown[]): Promise<IpcResult<WakeComputerResult>> => {
    assertSender(event);
    if (extra.length) return { ok: false, error: { code: 'VALIDATION_ERROR', message: 'Wake-on-LAN принимает только ID компьютера.' } };
    try { return { ok: true, value: await service.wake(id) }; }
    catch (error) {
      if (error instanceof WakeOnLanError || error instanceof ComputerStoreError) return { ok: false, error: { code: error.code, message: error.message } };
      if (error instanceof StorageFormatError || error instanceof SyntaxError || (typeof error === 'object' && error !== null && 'code' in error && ['ENOENT', 'EACCES', 'EPERM'].includes(String(error.code)))) return { ok: false, error: { code: 'STORAGE_ERROR', message: 'Не удалось прочитать конфигурацию. Исходные данные сохранены.' } };
      return { ok: false, error: { code: 'WOL_SEND_ERROR', message: 'Не удалось отправить Magic Packet. Попробуйте ещё раз.' } };
    }
  };
}
