import { ipcMain } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import type { RemoteDesktopService } from '../services/remoteDesktopService';
import { assertTrustedSender } from './registerAppHandlers';
import type { AppHandlerOptions } from './registerAppHandlers';
import { createRdpRequestHandler } from './rdpRequest';

export function registerRdpHandlers(options: AppHandlerOptions, service: RemoteDesktopService): void {
  ipcMain.handle(IPC_CHANNELS.openRemoteDesktop, createRdpRequestHandler((event) => assertTrustedSender(event, options), service));
}
