import type { IpcResult } from '../../shared/types.js';
import { ComputerStoreError } from '../services/computerStore.js';
import { StorageFormatError } from '../services/storageSchema.js';
import { WakeOnLanError } from '../services/wakeOnLanError.js';
import { WakeAndConnectError } from '../services/wakeAndConnectError.js';
import { RdpError } from '../services/rdpError.js';
import { SshError } from '../services/sshError.js';
import { CheckCancelledError } from '../services/networkService.js';
export function createWakeAndConnectRequestHandler<Event, Result>(assertSender: (event: Event) => void, operation: (id: unknown) => Promise<Result> | Result) {
  return async (event: Event, id: unknown, ...extra: unknown[]): Promise<IpcResult<Result>> => {
    assertSender(event);
    if (extra.length) return { ok: false, error: { code: 'VALIDATION_ERROR', message: 'Сценарий принимает только ID компьютера.' } };
    try { return { ok: true, value: await operation(id) }; }
    catch (error) {
      if (error instanceof WakeAndConnectError || error instanceof WakeOnLanError || error instanceof RdpError || error instanceof SshError || error instanceof ComputerStoreError) return { ok: false, error: { code: error.code, message: error.message } };
      if (error instanceof CheckCancelledError) return { ok: false, error: { code: 'CANCELLED', message: 'Ожидание отменено. Уже отправленный сигнал включения отменить нельзя.' } };
      if (error instanceof StorageFormatError || error instanceof SyntaxError || (typeof error === 'object' && error !== null && 'code' in error && ['ENOENT', 'EACCES', 'EPERM'].includes(String(error.code)))) return { ok: false, error: { code: 'STORAGE_ERROR', message: 'Не удалось прочитать конфигурацию. Исходные данные сохранены.' } };
      return { ok: false, error: { code: 'NETWORK_ERROR', message: 'Не удалось выполнить включение с подключением. Попробуйте ещё раз.' } };
    }
  };
}
