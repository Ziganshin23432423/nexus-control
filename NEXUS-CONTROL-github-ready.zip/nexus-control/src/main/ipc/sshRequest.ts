import type { IpcResult, SshTerminalLaunchResult } from '../../shared/types.js';
import { ComputerStoreError } from '../services/computerStore.js';
import { CheckCancelledError } from '../services/networkService.js';
import { SshError } from '../services/sshError.js';
import type { SshTerminalService } from '../services/sshTerminalService.js';
import { StorageFormatError } from '../services/storageSchema.js';

export function createSshRequestHandler<Event>(assertSender: (event: Event) => void, service: Pick<SshTerminalService, 'open'>) {
  return async (event: Event, id: unknown, ...extra: unknown[]): Promise<IpcResult<SshTerminalLaunchResult>> => {
    assertSender(event);
    if (extra.length) return { ok: false, error: { code: 'VALIDATION_ERROR', message: 'SSH-запрос принимает только ID компьютера.' } };
    try { return { ok: true, value: await service.open(id) }; }
    catch (error) {
      if (error instanceof SshError || error instanceof ComputerStoreError) return { ok: false, error: { code: error.code, message: error.message } };
      if (error instanceof CheckCancelledError) return { ok: false, error: { code: 'CANCELLED', message: 'Открытие SSH отменено: данные изменились или приложение закрывается.' } };
      if (error instanceof StorageFormatError || error instanceof SyntaxError || (typeof error === 'object' && error !== null && 'code' in error && ['ENOENT', 'EACCES', 'EPERM'].includes(String(error.code)))) return { ok: false, error: { code: 'STORAGE_ERROR', message: 'Не удалось прочитать конфигурацию. Исходные данные сохранены.' } };
      return { ok: false, error: { code: 'SSH_LAUNCH_ERROR', message: 'Не удалось открыть SSH-терминал. Попробуйте ещё раз.' } };
    }
  };
}
