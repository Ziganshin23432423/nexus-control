import { ipcMain } from 'electron';
import { IPC_CHANNELS } from '../../shared/constants';
import type { WakeOnLanService } from '../services/wakeOnLanService';
import { assertTrustedSender } from './registerAppHandlers';
import type { AppHandlerOptions } from './registerAppHandlers';
import { createWakeRequestHandler } from './wakeRequest';
export function registerWakeHandlers(options: AppHandlerOptions, service: WakeOnLanService): void {
  ipcMain.handle(IPC_CHANNELS.wakeComputer, createWakeRequestHandler(event => assertTrustedSender(event, options), service));
}
