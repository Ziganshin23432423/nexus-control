import type { IpcResult, RemoteDesktopLaunchResult } from '../../shared/types.js';
import { ComputerStoreError } from '../services/computerStore.js';
import { CheckCancelledError } from '../services/networkService.js';
import { RdpError } from '../services/rdpError.js';
import type { RemoteDesktopService } from '../services/remoteDesktopService.js';
import { StorageFormatError } from '../services/storageSchema.js';

/** Pure adapter for testability. Authorization happens before input/operation. */
export function createRdpRequestHandler<Event>(assertSender: (event: Event) => void, service: Pick<RemoteDesktopService, 'open'>) {
  return async (event: Event, id: unknown, ...extra: unknown[]): Promise<IpcResult<RemoteDesktopLaunchResult>> => {
    assertSender(event);
    if (extra.length) return { ok: false, error: { code: 'VALIDATION_ERROR', message: 'RDP-запрос принимает только ID компьютера.' } };
    try { return { ok: true, value: await service.open(id) }; }
    catch (error) {
      if (error instanceof RdpError || error instanceof ComputerStoreError) return { ok: false, error: { code: error.code, message: error.message } };
      if (error instanceof CheckCancelledError) return { ok: false, error: { code: 'CANCELLED', message: 'Открытие RDP отменено: данные изменились или приложение закрывается.' } };
      if (error instanceof StorageFormatError || error instanceof SyntaxError || (typeof error === 'object' && error !== null && 'code' in error && ['ENOENT', 'EACCES', 'EPERM'].includes(String(error.code)))) return { ok: false, error: { code: 'STORAGE_ERROR', message: 'Не удалось прочитать конфигурацию. Исходные данные сохранены.' } };
      return { ok: false, error: { code: 'RDP_LAUNCH_ERROR', message: 'Не удалось открыть RDP-клиент. Попробуйте ещё раз.' } };
    }
  };
}
