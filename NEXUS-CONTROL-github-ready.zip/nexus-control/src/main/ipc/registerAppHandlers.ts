import { isTrustedIpcSender } from './trustedSender';
import { app, ipcMain } from 'electron';
import type { BrowserWindow, IpcMainInvokeEvent } from 'electron';
import { APP_NAME, IPC_CHANNELS } from '../../shared/constants';
import type { AppInfo } from '../../shared/types';
import type { PlatformService } from '../providers/contracts';

export interface AppHandlerOptions {
  getMainWindow(): BrowserWindow | null;
  readonly rendererUrl: string;
  readonly isDevelopment: boolean;
  readonly platformService: PlatformService;
}

export function assertTrustedSender(event: IpcMainInvokeEvent, options: AppHandlerOptions): void {
  const window = options.getMainWindow();
  if (!isTrustedIpcSender(event, window, options.rendererUrl)) {
    throw new Error('IPC request rejected: untrusted sender.');
  }
}

export function registerAppHandlers(options: AppHandlerOptions): void {
  ipcMain.handle(IPC_CHANNELS.getAppInfo, (event): AppInfo => {
    assertTrustedSender(event, options);
    return {
      name: APP_NAME,
      version: app.getVersion(),
      mode: options.isDevelopment ? 'development' : 'production',
      platform: options.platformService.hostPlatform,
    };
  });
}
