import type { LaunchOwnership } from './launchOwnership.js';
import type { Computer, SshTerminalLaunchResult, ServiceCheckResult } from '../../shared/types.js';
import { isValidComputerId, isValidUsername, validateStoredComputer } from '../../shared/validation.js';
import type { SshProvider } from '../providers/contracts.js';
import { ComputerStoreError } from './computerStore.js';
import { CheckCancelledError } from './networkService.js';
import { SshError } from './sshError.js';

export class SshTerminalService {
  constructor(
    private readonly store: { get(id: unknown): Computer },
    private readonly checks: { checkSsh(computer: Computer, signal: AbortSignal): Promise<ServiceCheckResult> },
    private readonly provider: SshProvider | null,
    private readonly pending = new Map<string, AbortController>(),
  ) {}
  cancelPending(): void { for (const controller of this.pending.values()) controller.abort(); }
  open(id: unknown): Promise<SshTerminalLaunchResult> { return this.perform(id); }
  /** Only an owner already holding the shared launch slot may enter here. */
  openOwned(id: string, ownership: LaunchOwnership): Promise<SshTerminalLaunchResult> { return this.perform(id, ownership); }
  private async perform(id: unknown, ownership?: LaunchOwnership): Promise<SshTerminalLaunchResult> {
    if (!isValidComputerId(id)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректный ID компьютера.');
    if (this.pending.has(id) && this.pending.get(id) !== ownership?.controller) throw new SshError('SSH_BUSY', 'Для этого компьютера уже открывается клиент подключения.');
    if (ownership && (this.pending.get(id) !== ownership.controller || ownership.controller.signal.aborted)) throw new CheckCancelledError();
    const stored = this.store.get(id);
    if (stored.operatingSystem !== 'windows') throw new SshError('SSH_UNSUPPORTED', 'SSH для этой операционной системы пока не поддерживается.');
    const validation = validateStoredComputer(stored);
    if (!validation.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Сохранённая конфигурация компьютера некорректна.', validation.errors);
    const computer = validation.value;
    if (ownership && JSON.stringify(computer) !== JSON.stringify(ownership.computer)) throw new CheckCancelledError();
    if (!computer.sshEnabled) throw new SshError('SSH_DISABLED', 'SSH не настроен для этого компьютера.');
    if (!computer.username || !isValidUsername(computer.username)) throw new ComputerStoreError('VALIDATION_ERROR', 'Для SSH укажите корректное имя пользователя.');
    if (!this.provider) throw new SshError('SSH_UNSUPPORTED', 'SSH-терминал доступен только в Windows.');
    const controller = ownership?.controller ?? new AbortController();
    if (!ownership) this.pending.set(id, controller);
    try {
      const ssh = await this.checks.checkSsh(computer, controller.signal);
      if (controller.signal.aborted || JSON.stringify(this.store.get(id)) !== JSON.stringify(computer)) throw new CheckCancelledError();
      if (ssh.status !== 'ready' || !ssh.addressUsed) throw new SshError('SSH_UNAVAILABLE', 'SSH сейчас недоступен. Обновите статусы и попробуйте снова.');
      if (ssh.port !== 22 || ssh.service !== 'ssh' || ![computer.localAddress, computer.remoteAddress].includes(ssh.addressUsed)) throw new SshError('SSH_LAUNCH_ERROR', 'Не удалось определить адрес SSH-подключения.');
      // Revalidate immediately before crossing the native provider boundary.
      if (!isValidUsername(computer.username)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректное имя пользователя SSH.');
      await this.provider.open({ host: ssh.addressUsed, username: computer.username, port: 22, signal: controller.signal });
      return { computerId: id, state: 'terminal-opened', ssh };
    } finally { if (!ownership) this.pending.delete(id); }
  }
}
