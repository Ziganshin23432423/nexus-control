import type { Computer } from '../../shared/types.js';
/** Main-only ownership token. Never exposed in IPC. */
export interface LaunchOwnership {
  readonly controller: AbortController;
  readonly computer: Computer;
}
