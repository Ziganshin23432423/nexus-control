export type SshErrorCode = 'SSH_UNSUPPORTED' | 'SSH_DISABLED' | 'SSH_UNAVAILABLE' | 'SSH_CLIENT_MISSING' | 'SSH_HOST_MISSING' | 'SSH_LAUNCH_ERROR' | 'SSH_BUSY';
export class SshError extends Error {
  constructor(readonly code: SshErrorCode, message: string) { super(message); }
}
