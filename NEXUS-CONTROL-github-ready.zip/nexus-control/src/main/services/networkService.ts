import { SERVICE_PORTS } from '../../shared/networkConstants.js';
import type { AddressKind, CheckedService, Computer, ConnectionCheckResult, ServiceCheckResult, TcpAttempt } from '../../shared/types.js';
import { validateStoredComputer } from '../../shared/validation.js';
import { ComputerStoreError } from './computerStore.js';
import { createTcpProbe } from './tcpProbe.js';
import type { TcpProbe } from './tcpProbe.js';

export class CheckCancelledError extends Error {}
export class NetworkService {
  constructor(private readonly probe: TcpProbe = createTcpProbe(), private readonly now = () => new Date().toISOString()) {}
  async check(input: unknown, signal?: AbortSignal): Promise<ConnectionCheckResult> {
    const validation = validateStoredComputer(input);
    if (!validation.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Сохранённая конфигурация компьютера некорректна.', validation.errors);
    if (signal?.aborted) throw new CheckCancelledError();
    const computer = validation.value;
    const settled = await Promise.allSettled([this.checkService(computer, 'rdp', signal), this.checkService(computer, 'ssh', signal)]);
    if (signal?.aborted) throw new CheckCancelledError();
    const services: ServiceCheckResult[] = [];
    for (const result of settled) { if (result.status === 'rejected') throw result.reason; services.push(result.value); }
    const rdp = services[0]; const ssh = services[1];
    const enabled = computer.rdpEnabled || computer.sshEnabled;
    return { computerId: computer.id, configUpdatedAt: computer.updatedAt,
      status: !enabled ? 'no-services' : services.some((result) => result.status === 'ready') ? 'online' : 'offline',
      rdp: rdp?.status ?? 'disabled', ssh: ssh?.status ?? 'disabled', wakeOnLan: computer.wakeOnLan ? 'configured' : 'disabled', checkedAt: this.now(), services };
  }
  /** Same timeout/fallback/validation as status refresh, without probing SSH. */
  checkRdp(input: unknown, signal?: AbortSignal): Promise<ServiceCheckResult> { return this.checkConfiguredService(input, 'rdp', signal); }
  checkSsh(input: unknown, signal?: AbortSignal): Promise<ServiceCheckResult> { return this.checkConfiguredService(input, 'ssh', signal); }
  private async checkConfiguredService(input: unknown, service: CheckedService, signal?: AbortSignal): Promise<ServiceCheckResult> {
    const validation = validateStoredComputer(input);
    if (!validation.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Сохранённая конфигурация компьютера некорректна.', validation.errors);
    if (signal?.aborted) throw new CheckCancelledError();
    return this.checkService(validation.value, service, signal);
  }
  private async checkService(computer: Computer, service: CheckedService, signal?: AbortSignal): Promise<ServiceCheckResult> {
    const base = { service, port: SERVICE_PORTS[service], addressUsed: null, addressKind: null, latencyMs: null, errorCode: null, attempts: [] } as const;
    if (!(service === 'rdp' ? computer.rdpEnabled : computer.sshEnabled)) return { ...base, status: 'disabled' };
    const attempts: TcpAttempt[] = [];
    const addresses: { address: string; kind: AddressKind }[] = [{ address: computer.localAddress, kind: 'local' }];
    if (computer.remoteAddress && computer.remoteAddress.toLowerCase() !== computer.localAddress.toLowerCase()) addresses.push({ address: computer.remoteAddress, kind: 'remote' });
    for (const target of addresses) {
      if (signal?.aborted) throw new CheckCancelledError();
      const result = await this.probe(target.address, service, signal);
      if (result.errorCode === 'CANCELLED' || signal?.aborted) throw new CheckCancelledError();
      const addressKind = target.kind;
      attempts.push({ address: target.address, addressKind, ...result });
      if (result.status === 'ready') return { ...base, ...result, addressUsed: target.address, addressKind, attempts };
    }
    return { ...base, status: 'unavailable', errorCode: attempts.at(-1)?.errorCode ?? 'SOCKET_ERROR', attempts };
  }
}
