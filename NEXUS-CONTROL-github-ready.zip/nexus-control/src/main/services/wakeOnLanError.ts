import type { IpcErrorCode } from '../../shared/types.js';
export class WakeOnLanError extends Error {
  constructor(readonly code: Extract<IpcErrorCode, `WOL_${string}` | 'CANCELLED'>, message: string) { super(message); }
}
