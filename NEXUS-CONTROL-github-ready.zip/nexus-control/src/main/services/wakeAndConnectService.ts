import type { Computer, WakeAndConnectProgress, WakeAndRdpResult, WakeAndSshResult, ServiceCheckResult } from '../../shared/types.js';
import { isValidComputerId, isValidUsername, validateStoredComputer } from '../../shared/validation.js';
import { WAKE_CONNECT_DEADLINE_MS, WAKE_CONNECT_DELAY_MS } from '../../shared/wakeAndConnectConstants.js';
import type { PlatformProviders } from '../providers/contracts.js';
import type { CheckCoordinator } from './checkCoordinator.js';
import type { WakeOnLanService } from './wakeOnLanService.js';
import type { RemoteDesktopService } from './remoteDesktopService.js';
import type { SshTerminalService } from './sshTerminalService.js';
import { ComputerStoreError } from './computerStore.js';
import { CheckCancelledError } from './networkService.js';
import { RdpError } from './rdpError.js';
import { SshError } from './sshError.js';
import { WakeOnLanError } from './wakeOnLanError.js';
import { WakeAndConnectError } from './wakeAndConnectError.js';
import { workflowClock, workflowDelay } from './workflowClock.js';
import type { WorkflowClock } from './workflowClock.js';

/** Exactly two fixed user flows; no arbitrary steps, protocols, ports or commands. */
export class WakeAndConnectService {
  private readonly active = new Map<string, AbortController>();
  constructor(
    private readonly store: { get(id: unknown): Computer },
    private readonly checks: Pick<CheckCoordinator, 'checkRdp' | 'checkSsh'>,
    private readonly wake: Pick<WakeOnLanService, 'wakeOwned'>,
    private readonly rdp: Pick<RemoteDesktopService, 'openOwned'>,
    private readonly ssh: Pick<SshTerminalService, 'openOwned'>,
    private readonly providers: PlatformProviders,
    private readonly launchSlots: Map<string, AbortController>,
    private readonly claims: Set<string>,
    private readonly clock: WorkflowClock = workflowClock,
    private readonly progress: (value: WakeAndConnectProgress) => void = () => {},
  ) {}
  openRdp(id: unknown): Promise<WakeAndRdpResult> { return this.run(id, 'rdp') as Promise<WakeAndRdpResult>; }
  openSsh(id: unknown): Promise<WakeAndSshResult> { return this.run(id, 'ssh') as Promise<WakeAndSshResult>; }
  cancel(id: unknown): { computerId: string; cancelled: boolean } {
    if (!isValidComputerId(id)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректный ID компьютера.');
    const controller = this.active.get(id); controller?.abort();
    return { computerId: id, cancelled: controller !== undefined };
  }
  cancelAll(): void { for (const controller of this.active.values()) controller.abort(); }
  private async run(id: unknown, service: 'rdp' | 'ssh'): Promise<WakeAndRdpResult | WakeAndSshResult> {
    if (!isValidComputerId(id)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректный ID компьютера.');
    if (this.launchSlots.has(id) || this.active.has(id)) throw new WakeAndConnectError('WAKE_CONNECT_BUSY', 'Для этого компьютера уже выполняется подключение.');
    const stored = this.store.get(id);
    if (stored.operatingSystem === 'linux') throw new WakeAndConnectError('WAKE_CONNECT_UNSUPPORTED', 'Включение с подключением для этой операционной системы пока не поддерживается.');
    const validation = validateStoredComputer(stored);
    if (!validation.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Сохранённая конфигурация некорректна.', validation.errors);
    const computer = validation.value;
    if (!computer.macAddress || !computer.wakeOnLan) throw new WakeOnLanError('WOL_DISABLED', 'Для включения с подключением настройте Wake-on-LAN.');
    if (service === 'rdp' && !computer.rdpEnabled) throw new RdpError('RDP_DISABLED', 'RDP не настроен для этого компьютера.');
    if (service === 'ssh' && (!computer.sshEnabled || !computer.username || !isValidUsername(computer.username))) throw new SshError('SSH_DISABLED', 'Для сценария настройте SSH и имя пользователя.');
    if (!this.providers.wakeOnLan || !(service === 'rdp' ? this.providers.remoteDesktop : this.providers.ssh)) throw new WakeAndConnectError('WAKE_CONNECT_UNSUPPORTED', 'Включение с подключением сейчас доступно только в Windows.');
    const controller = new AbortController();
    const ownership = { controller, computer };
    this.active.set(id, controller); this.launchSlots.set(id, controller); this.claims.add(id);
    let cancelCountdown: (() => void) | undefined;
    let currentPhase: WakeAndConnectProgress['phase'] = 'sending';
    let cancelDeadline: (() => void) | undefined;
    let timedOut = false;
    let start = 0;
    let deadlineAt: number | null = null;
    const assertCurrent = (): void => {
      if (deadlineAt !== null && this.clock.now() >= deadlineAt) { timedOut = true; controller.abort(); }
      if (controller.signal.aborted) throw new CheckCancelledError();
      try { if (JSON.stringify(this.store.get(id)) !== JSON.stringify(computer)) throw new CheckCancelledError(); }
      catch { controller.abort(); throw new CheckCancelledError(); }
    };
    const report = (phase: WakeAndConnectProgress['phase']): void => {
      // A closed renderer must not break main cleanup or extend the workflow.
      currentPhase = phase;
      try { this.progress({ computerId: id, service, phase, ...(deadlineAt === null ? {} : {remainingSeconds: Math.max(0, Math.ceil((deadlineAt - this.clock.now()) / 1000))}) }); } catch { /* UI transport unavailable */ }
    };
    try {
      report('sending');
      await this.wake.wakeOwned(id, ownership); assertCurrent();
      start = this.clock.now(); deadlineAt = start + WAKE_CONNECT_DEADLINE_MS;
      cancelDeadline = this.clock.schedule(() => { timedOut = true; controller.abort(); }, WAKE_CONNECT_DEADLINE_MS);
      report('waiting');
      const countdown = (): void => {
        if (controller.signal.aborted || currentPhase !== 'waiting') return;
        report('waiting');
        if (deadlineAt !== null && this.clock.now() < deadlineAt) cancelCountdown = this.clock.schedule(countdown, 1000);
      };
      cancelCountdown = this.clock.schedule(countdown, 1000);
      while (true) {
        assertCurrent();
        if (this.clock.now() - start >= WAKE_CONNECT_DEADLINE_MS) { timedOut = true; controller.abort(); throw new CheckCancelledError(); }
        const result: ServiceCheckResult = await (service === 'rdp' ? this.checks.checkRdp(computer, controller.signal) : this.checks.checkSsh(computer, controller.signal));
        assertCurrent();
        if (result.status === 'ready') break;
        await workflowDelay(this.clock, Math.min(WAKE_CONNECT_DELAY_MS, Math.max(0, WAKE_CONNECT_DEADLINE_MS - (this.clock.now() - start))), controller.signal);
      }
      assertCurrent(); cancelCountdown?.(); report('launching');
      // Existing Stage5/6 service re-reads config and performs its own final fresh check.
      const result = service === 'rdp' ? await this.rdp.openOwned(id, ownership) : await this.ssh.openOwned(id, ownership);
      return { ...result, wakeSent: true, waitedMs: Math.max(0, Math.round(this.clock.now() - start)) };
    } catch (error) {
      if (timedOut) throw new WakeAndConnectError('WAKE_CONNECT_TIMEOUT', service === 'rdp' ? 'Компьютер не стал доступен по RDP за отведённое время.' : 'SSH не стал доступен за отведённое время.');
      if (deadlineAt !== null && this.clock.now() >= deadlineAt) { timedOut = true; controller.abort(); }
      if (controller.signal.aborted) throw new CheckCancelledError();
      throw error;
    } finally {
      cancelCountdown?.(); cancelDeadline?.(); controller.abort();
      this.active.delete(id); this.claims.delete(id);
      if (this.launchSlots.get(id) === controller) this.launchSlots.delete(id);
    }
  }
}
