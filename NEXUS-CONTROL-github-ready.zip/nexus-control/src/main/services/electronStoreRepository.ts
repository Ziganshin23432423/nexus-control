import Store from 'electron-store';
import { hasOnlyKeys, isRecord } from '../../shared/validation.js';
import type { ConfigurationRepository } from './computerStore.js';
import { parseStorageFile, StorageFormatError } from './storageSchema.js';

/** Main only. Lazy construction keeps storage errors reviewable in the UI. */
export function createElectronStoreRepository(directory: string): ConfigurationRepository {
  let store: Store<{ configuration: unknown }> | undefined;
  function getStore(): Store<{ configuration: unknown }> {
    store ??= new Store<{ configuration: unknown }>({ name: 'computers', cwd: directory, clearInvalidConfig: false, accessPropertiesByDotNotation: false, deserialize: parseStorageFile });
    return store;
  }
  return {
    read: () => {
      const root: unknown = getStore().store;
      if (!isRecord(root) || !hasOnlyKeys(root, ['configuration'])) throw new StorageFormatError('Некорректная структура файла.');
      return root['configuration'];
    },
    write: (configuration) => { getStore().set('configuration', configuration); },
  };
}
