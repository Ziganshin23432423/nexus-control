import { performance } from 'node:perf_hooks';
import { CheckCancelledError } from './networkService.js';
export interface WorkflowClock {
  now(): number;
  schedule(callback: () => void, milliseconds: number): () => void;
}
export const workflowClock: WorkflowClock = {
  now: () => performance.now(),
  schedule: (callback, ms) => { const timer = setTimeout(callback, ms); return () => clearTimeout(timer); },
};
export function workflowDelay(clock: WorkflowClock, ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(new CheckCancelledError()); return; }
    let cancelTimer: (() => void) | undefined;
    const abort = (): void => { cancelTimer?.(); signal.removeEventListener('abort', abort); reject(new CheckCancelledError()); };
    signal.addEventListener('abort', abort, { once: true });
    try { cancelTimer = clock.schedule(() => { signal.removeEventListener('abort', abort); resolve(); }, ms); }
    catch (error) { signal.removeEventListener('abort', abort); reject(error); }
    if (signal.aborted) abort();
  });
}
