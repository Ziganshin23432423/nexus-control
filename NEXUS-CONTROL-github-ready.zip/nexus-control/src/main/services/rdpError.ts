export type RdpErrorCode = 'RDP_UNSUPPORTED' | 'RDP_DISABLED' | 'RDP_UNAVAILABLE' | 'RDP_CLIENT_MISSING' | 'RDP_LAUNCH_ERROR' | 'RDP_BUSY';
export class RdpError extends Error {
  constructor(readonly code: RdpErrorCode, message: string) { super(message); }
}
