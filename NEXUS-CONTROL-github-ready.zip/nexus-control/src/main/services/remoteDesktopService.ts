import type { LaunchOwnership } from './launchOwnership.js';
import type { Computer, RemoteDesktopLaunchResult, ServiceCheckResult } from '../../shared/types.js';
import { isValidComputerId, validateStoredComputer } from '../../shared/validation.js';
import type { RemoteDesktopProvider } from '../providers/contracts.js';
import { ComputerStoreError } from './computerStore.js';
import { CheckCancelledError } from './networkService.js';
import { RdpError } from './rdpError.js';

export class RemoteDesktopService {
  constructor(
    private readonly store: { get(id: unknown): Computer },
    private readonly checks: { checkRdp(computer: Computer, signal: AbortSignal): Promise<ServiceCheckResult> },
    private readonly provider: RemoteDesktopProvider | null,
    private readonly pending = new Map<string, AbortController>(),
  ) {}
  cancelPending(): void { for (const controller of this.pending.values()) controller.abort(); }
  open(id: unknown): Promise<RemoteDesktopLaunchResult> { return this.perform(id); }
  /** Only an owner already holding the shared launch slot may enter here. */
  openOwned(id: string, ownership: LaunchOwnership): Promise<RemoteDesktopLaunchResult> { return this.perform(id, ownership); }
  private async perform(id: unknown, ownership?: LaunchOwnership): Promise<RemoteDesktopLaunchResult> {
    if (!isValidComputerId(id)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректный ID компьютера.');
    if (this.pending.has(id) && this.pending.get(id) !== ownership?.controller) throw new RdpError('RDP_BUSY', 'Для этого компьютера уже открывается клиент подключения.');
    if (ownership && (this.pending.get(id) !== ownership.controller || ownership.controller.signal.aborted)) throw new CheckCancelledError();
    const stored = this.store.get(id);
    if (stored.operatingSystem !== 'windows') throw new RdpError('RDP_UNSUPPORTED', 'RDP для этой операционной системы пока не поддерживается.');
    const validation = validateStoredComputer(stored);
    if (!validation.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Сохранённая конфигурация компьютера некорректна.', validation.errors);
    const computer = validation.value;
    if (ownership && JSON.stringify(computer) !== JSON.stringify(ownership.computer)) throw new CheckCancelledError();
    if (!computer.rdpEnabled) throw new RdpError('RDP_DISABLED', 'RDP не настроен для этого компьютера.');
    if (!this.provider) throw new RdpError('RDP_UNSUPPORTED', 'RDP-клиент доступен только в Windows.');
    const controller = ownership?.controller ?? new AbortController();
    if (!ownership) this.pending.set(id, controller);
    try {
      const rdp = await this.checks.checkRdp(computer, controller.signal);
      if (controller.signal.aborted || JSON.stringify(this.store.get(id)) !== JSON.stringify(computer)) throw new CheckCancelledError();
      if (rdp.status !== 'ready' || !rdp.addressUsed) throw new RdpError('RDP_UNAVAILABLE', 'RDP сейчас недоступен. Обновите статусы и попробуйте снова.');
      // The selected address must belong to the validated snapshot, never to IPC.
      if (rdp.port !== 3389 || rdp.service !== 'rdp' || ![computer.localAddress, computer.remoteAddress].includes(rdp.addressUsed)) throw new RdpError('RDP_LAUNCH_ERROR', 'Не удалось определить адрес RDP-подключения.');
      await this.provider.open({ host: rdp.addressUsed, port: 3389, signal: controller.signal });
      return { computerId: id, state: 'client-opened', rdp };
    } finally { if (!ownership) this.pending.delete(id); }
  }
}
