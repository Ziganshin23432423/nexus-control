import type { LaunchOwnership } from './launchOwnership.js';
import type { Computer, WakeComputerResult } from '../../shared/types.js';
import { isValidComputerId, isValidIpv4, isValidPort, normalizeMac, validateStoredComputer } from '../../shared/validation.js';
import { createMagicPacket } from '../../shared/magicPacket.js';
import type { WakeOnLanProvider } from '../providers/contracts.js';
import { ComputerStoreError } from './computerStore.js';
import { WakeOnLanError } from './wakeOnLanError.js';

export class WakeOnLanService {
  private readonly pending = new Map<string, AbortController>();
  constructor(private readonly store: { get(id: unknown): Computer }, private readonly provider: WakeOnLanProvider | null, private readonly workflowClaims = new Set<string>()) {}
  cancel(id: string): void { this.pending.get(id)?.abort(); }
  cancelPending(): void { for (const controller of this.pending.values()) controller.abort(); }
  wake(id: unknown): Promise<WakeComputerResult> { return this.perform(id); }
  wakeOwned(id: string, ownership: LaunchOwnership): Promise<WakeComputerResult> { return this.perform(id, ownership); }
  private async perform(id: unknown, ownership?: LaunchOwnership): Promise<WakeComputerResult> {
    if (!isValidComputerId(id)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректный ID компьютера.');
    if (this.workflowClaims.has(id) && !ownership) throw new WakeOnLanError('WOL_BUSY', 'Для этого компьютера уже выполняется включение с подключением.');
    if (ownership?.controller.signal.aborted) throw new WakeOnLanError('CANCELLED', 'Отправка Wake-on-LAN отменена.');
    if (this.pending.has(id)) throw new WakeOnLanError('WOL_BUSY', 'Для этого компьютера уже отправляется Magic Packet.');
    const stored = this.store.get(id);
    // The shared current-MVP validator rejects Linux; give that case a useful capability error.
    if (stored.operatingSystem === 'linux') throw new WakeOnLanError('WOL_UNSUPPORTED', 'Wake-on-LAN для этой операционной системы пока не поддерживается.');
    const validation = validateStoredComputer(stored);
    if (!validation.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Сохранённая конфигурация компьютера некорректна.', validation.errors);
    const computer = validation.value;
    if (ownership && JSON.stringify(computer) !== JSON.stringify(ownership.computer)) throw new WakeOnLanError('CANCELLED', 'Конфигурация изменилась; отправка отменена.');
    if (computer.operatingSystem !== 'windows') throw new WakeOnLanError('WOL_UNSUPPORTED', 'Операционная система не поддерживается.');
    if (!computer.wakeOnLan || !computer.macAddress) throw new WakeOnLanError('WOL_DISABLED', 'Wake-on-LAN не настроен: укажите MAC, broadcast address и порт.');
    const macAddress = normalizeMac(computer.macAddress);
    const { broadcastAddress, port } = computer.wakeOnLan;
    if (!macAddress || !isValidIpv4(broadcastAddress) || !isValidPort(port)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректные настройки Wake-on-LAN.');
    if (!this.provider) throw new WakeOnLanError('WOL_UNSUPPORTED', 'Wake-on-LAN сейчас доступен только в Windows.');
    const packet = createMagicPacket(macAddress);
    const controller = ownership?.controller ?? new AbortController(); this.pending.set(id, controller);
    try {
      await this.provider.send({ macAddress, broadcastAddress, port, packet, signal: controller.signal });
      if (controller.signal.aborted) throw new WakeOnLanError('CANCELLED', 'Отправка Wake-on-LAN отменена.');
      return { computerId: id, state: 'packet-sent', packetsSent: 3 };
    } finally { this.pending.delete(id); }
  }
}
