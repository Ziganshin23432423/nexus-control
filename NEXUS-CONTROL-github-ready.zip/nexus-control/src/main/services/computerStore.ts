import { randomUUID } from 'node:crypto';
import type { Computer, ComputerDraft, IpcErrorCode, ValidationErrors } from '../../shared/types.js';
import { isValidComputerId, validateComputerDraft } from '../../shared/validation.js';
import { MAX_COMPUTERS, STORAGE_VERSION, migrateConfiguration } from './storageSchema.js';
import type { ComputerConfiguration } from './storageSchema.js';

export interface ConfigurationRepository { read(): unknown; write(configuration: ComputerConfiguration): void }
export class ComputerStoreError extends Error {
  constructor(readonly code: IpcErrorCode, message: string, readonly fieldErrors?: ValidationErrors) { super(message); }
}
export class ComputerStore {
  constructor(private readonly repository: ConfigurationRepository, private readonly id = randomUUID as () => string, private readonly now = () => new Date().toISOString()) {}

  private load(): ComputerConfiguration {
    const raw = this.repository.read();
    if (raw === undefined) {
      const empty: ComputerConfiguration = { schemaVersion: STORAGE_VERSION, computers: [] };
      this.repository.write(empty);
      return empty;
    }
    const configuration = migrateConfiguration(raw);
    // Persist only successful migration/normalization; invalid data is never cleared.
    if (JSON.stringify(raw) !== JSON.stringify(configuration)) this.repository.write(configuration);
    return configuration;
  }
  private draft(value: unknown): ComputerDraft {
    const result = validateComputerDraft(value);
    if (!result.ok) throw new ComputerStoreError('VALIDATION_ERROR', 'Проверьте параметры компьютера.', result.errors);
    return result.value;
  }
  private requireId(value: unknown): string {
    if (!isValidComputerId(value)) throw new ComputerStoreError('VALIDATION_ERROR', 'Некорректный идентификатор компьютера.');
    return value;
  }
  get(idInput: unknown): Computer {
    const id = this.requireId(idInput);
    const computer = this.load().computers.find((item) => item.id === id);
    if (!computer) throw new ComputerStoreError('NOT_FOUND', 'Компьютер уже удалён или не найден.');
    return structuredClone(computer);
  }
  list(): Computer[] { return structuredClone([...this.load().computers]); }
  create(input: unknown): Computer {
    const draft = this.draft(input);
    const configuration = this.load();
    if (configuration.computers.length >= MAX_COMPUTERS) throw new ComputerStoreError('LIMIT_REACHED', 'Достигнут лимит сохранённых компьютеров.');
    const timestamp = this.now();
    const computer: Computer = { ...draft, id: this.id(), createdAt: timestamp, updatedAt: timestamp };
    const next = migrateConfiguration({ ...configuration, computers: [...configuration.computers, computer] });
    this.repository.write(next);
    return structuredClone(computer);
  }
  update(idInput: unknown, input: unknown): Computer {
    const id = this.requireId(idInput);
    const draft = this.draft(input);
    const configuration = this.load();
    const existing = configuration.computers.find((item) => item.id === id);
    if (!existing) throw new ComputerStoreError('NOT_FOUND', 'Компьютер уже удалён или не найден.');
    const computer: Computer = { ...draft, id, createdAt: existing.createdAt, updatedAt: [existing.updatedAt, this.now()].sort().at(-1) ?? existing.updatedAt };
    const next = migrateConfiguration({ ...configuration, computers: configuration.computers.map((item) => item.id === id ? computer : item) });
    this.repository.write(next);
    return structuredClone(computer);
  }
  delete(idInput: unknown): null {
    const id = this.requireId(idInput);
    const configuration = this.load();
    if (!configuration.computers.some((item) => item.id === id)) throw new ComputerStoreError('NOT_FOUND', 'Компьютер уже удалён или не найден.');
    this.repository.write({ ...configuration, computers: configuration.computers.filter((item) => item.id !== id) });
    return null;
  }
}
