import type { Computer } from '../../shared/types.js';
import { hasOnlyKeys, isRecord, validateStoredComputer } from '../../shared/validation.js';

export const STORAGE_VERSION = 1;
export const MAX_COMPUTERS = 1000;
export interface ComputerConfiguration { readonly schemaVersion: number; readonly computers: readonly Computer[] }
export class StorageFormatError extends Error {}
export type ConfigurationMigration = (input: Record<string, unknown>) => unknown;
/** Add explicit version-to-version transforms here when a second schema exists. */
const migrations: Readonly<Record<number, ConfigurationMigration>> = Object.freeze({});

export function migrateConfiguration(input: unknown, steps = migrations): ComputerConfiguration {
  let candidate = input;
  for (let count = 0; count < STORAGE_VERSION; count++) {
    if (!isRecord(candidate) || typeof candidate['schemaVersion'] !== 'number' || !Number.isInteger(candidate['schemaVersion']) || candidate['schemaVersion'] < 0) throw new StorageFormatError('Некорректная версия конфигурации.');
    const version = candidate['schemaVersion'];
    if (version > STORAGE_VERSION) throw new StorageFormatError('Этот файл создан более новой версией NEXUS CONTROL.');
    if (version === STORAGE_VERSION) break;
    const step = steps[version];
    if (!step) throw new StorageFormatError('Для этой версии конфигурации нет миграции.');
    candidate = step(candidate);
    if (!isRecord(candidate) || candidate['schemaVersion'] !== version + 1) throw new StorageFormatError('Миграция не выполнила следующий шаг версии.');
  }
  if (!isRecord(candidate) || candidate['schemaVersion'] !== STORAGE_VERSION || !hasOnlyKeys(candidate, ['schemaVersion', 'computers']) || !Array.isArray(candidate['computers']) || candidate['computers'].length > MAX_COMPUTERS) throw new StorageFormatError('Некорректный формат конфигурации.');
  const ids = new Set<string>();
  const computers: Computer[] = [];
  for (const value of candidate['computers']) {
    const result = validateStoredComputer(value);
    if (!result.ok || ids.has(result.value.id)) throw new StorageFormatError('В файле есть некорректные или повторяющиеся записи.');
    ids.add(result.value.id);
    computers.push(result.value);
  }
  return { schemaVersion: STORAGE_VERSION, computers };
}

/** Validate the raw JSON root before electron-store can coerce it into an object. */
export function parseStorageFile(serialized: string): { configuration: unknown } {
  const root: unknown = JSON.parse(serialized);
  if (!isRecord(root) || !hasOnlyKeys(root, ['configuration']) || !Object.hasOwn(root, 'configuration')) throw new StorageFormatError('Некорректная структура файла.');
  return { configuration: root['configuration'] };
}
