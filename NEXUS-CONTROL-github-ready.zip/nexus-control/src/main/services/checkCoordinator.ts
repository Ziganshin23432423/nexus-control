import { setMaxListeners } from 'node:events';
import { COMPUTER_CHECK_CONCURRENCY } from '../../shared/networkConstants.js';
import type { Computer, ConnectionCheckResult, ServiceCheckResult } from '../../shared/types.js';
import type { ComputerStore } from './computerStore.js';
import { CheckCancelledError, NetworkService } from './networkService.js';

/** One global pool, including sockets from a superseded request until they close. */
export class ComputerCheckPool {
  private active = 0;
  private readonly queue: { signal: AbortSignal; start(): void; cancel(): void }[] = [];
  constructor(private readonly limit = COMPUTER_CHECK_CONCURRENCY) {}
  async run<T>(signal: AbortSignal, task: () => Promise<T>): Promise<T> {
    await new Promise<void>((resolve, reject) => {
      const entry = { signal, start: () => { signal.removeEventListener('abort', entry.cancel); this.active++; resolve(); },
        cancel: () => { const index = this.queue.indexOf(entry); if (index !== -1) this.queue.splice(index, 1); signal.removeEventListener('abort', entry.cancel); reject(new CheckCancelledError()); } };
      if (signal.aborted) { reject(new CheckCancelledError()); return; }
      if (this.active < this.limit) entry.start();
      else { this.queue.push(entry); signal.addEventListener('abort', entry.cancel, { once: true }); }
    });
    try { if (signal.aborted) throw new CheckCancelledError(); return await task(); }
    finally { this.active--; this.drain(); }
  }
  private drain(): void {
    while (this.active < this.limit && this.queue.length) {
      const next = this.queue.shift(); if (!next) break;
      if (next.signal.aborted) next.cancel(); else next.start();
    }
  }
}
export class CheckCoordinator {
  private current: AbortController | null = null;
  private readonly pool = new ComputerCheckPool();
  constructor(private readonly store: Pick<ComputerStore, 'get' | 'list'>, private readonly network = new NetworkService()) {}
  cancel(): void { this.current?.abort(); this.current = null; }
  async checkComputerStatus(id: unknown): Promise<ConnectionCheckResult> {
    const computer = this.store.get(id); // Store revalidates the whole file and ID.
    const results = await this.run([computer]);
    const result = results[0]; if (!result) throw new CheckCancelledError(); return result;
  }
  async refreshAllComputerStatuses(): Promise<ConnectionCheckResult[]> { return this.run(this.store.list()); }
  /** Launch checks share the global pool but do not supersede UI refreshes. */
  checkRdp(computer: Computer, signal: AbortSignal): Promise<ServiceCheckResult> {
    return this.pool.run(signal, () => this.network.checkRdp(computer, signal));
  }
  checkSsh(computer: Computer, signal: AbortSignal): Promise<ServiceCheckResult> {
    return this.pool.run(signal, () => this.network.checkSsh(computer, signal));
  }
  private async run(computers: readonly Computer[]): Promise<ConnectionCheckResult[]> {
    this.cancel();
    const controller = new AbortController(); this.current = controller;
    // At most 8 workers / 16 probes; keep Node's listener warning within that bound.
    setMaxListeners(COMPUTER_CHECK_CONCURRENCY * 4, controller.signal);
    const results: ConnectionCheckResult[] = [];
    let cursor = 0;
    try {
      const worker = async (): Promise<void> => {
        while (cursor < computers.length) {
          if (controller.signal.aborted) throw new CheckCancelledError();
          const computer = computers[cursor++]; if (!computer) break;
          const result = await this.pool.run(controller.signal, () => this.network.check(computer, controller.signal));
          if (controller.signal.aborted) throw new CheckCancelledError();
          results.push(result);
        }
      };
      await Promise.all(Array.from({ length: Math.min(COMPUTER_CHECK_CONCURRENCY, computers.length) }, worker));
      if (controller.signal.aborted) throw new CheckCancelledError();
      const current = new Map(this.store.list().map((computer) => [computer.id, computer]));
      if (computers.some((computer) => JSON.stringify(current.get(computer.id)) !== JSON.stringify(computer))) throw new CheckCancelledError();
      return results;
    } catch (error) { controller.abort(); throw error; }
    finally { if (this.current === controller) this.current = null; }
  }
}
