export class WakeAndConnectError extends Error {
  constructor(readonly code: 'WAKE_CONNECT_BUSY' | 'WAKE_CONNECT_TIMEOUT' | 'WAKE_CONNECT_UNSUPPORTED', message: string) { super(message); }
}
