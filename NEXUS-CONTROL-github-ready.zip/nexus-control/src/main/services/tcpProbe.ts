import { Socket } from 'node:net';
import { performance } from 'node:perf_hooks';
import { CONNECTION_TIMEOUT_MS, SERVICE_PORTS } from '../../shared/networkConstants.js';
import type { CheckedService, TcpErrorCode } from '../../shared/types.js';

export interface TcpProbeResult { readonly status: 'ready' | 'unavailable'; readonly latencyMs: number | null; readonly errorCode: TcpErrorCode | null }
export type TcpProbe = (address: string, service: CheckedService, signal?: AbortSignal) => Promise<TcpProbeResult>;
/** Minimal adapter keeps socket lifecycle tests independent of real networking. */
export interface ProbeSocket {
  onConnect(callback: () => void): () => void;
  onError(callback: (error: unknown) => void): () => void;
  onClose(callback: () => void): () => void;
  connect(address: string, port: 3389 | 22): void;
  destroy(): void;
}
export interface TcpProbeDependencies {
  readonly socketFactory: () => ProbeSocket;
  readonly schedule: (callback: () => void, milliseconds: number) => () => void;
  readonly now: () => number;
}
function nodeSocket(): ProbeSocket {
  const socket = new Socket();
  return {
    onConnect: (callback) => { socket.once('connect', callback); return () => { socket.removeListener('connect', callback); }; },
    onError: (callback) => { socket.on('error', callback); return () => { socket.removeListener('error', callback); }; },
    onClose: (callback) => { socket.once('close', callback); return () => { socket.removeListener('close', callback); }; },
    connect: (address, port) => { socket.connect({ host: address, port }); },
    destroy: () => { socket.destroy(); },
  };
}
const dependencies: TcpProbeDependencies = {
  socketFactory: nodeSocket,
  schedule: (callback, milliseconds) => { const timer = setTimeout(callback, milliseconds); return () => clearTimeout(timer); },
  now: () => performance.now(),
};
const errorCodes: readonly string[] = ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN', 'EHOSTUNREACH', 'ENETUNREACH', 'ECONNRESET', 'EACCES', 'EPERM', 'EADDRNOTAVAIL'];
function safeErrorCode(error: unknown): TcpErrorCode {
  if (typeof error === 'object' && error !== null && 'code' in error && typeof error.code === 'string' && errorCodes.includes(error.code)) return error.code as TcpErrorCode;
  return 'SOCKET_ERROR';
}
const failed = (code: TcpErrorCode): TcpProbeResult => ({ status: 'unavailable', latencyMs: null, errorCode: code });

export function createTcpProbe(deps: TcpProbeDependencies = dependencies): TcpProbe {
  return (address, service, signal) => {
    if (signal?.aborted) return Promise.resolve(failed('CANCELLED'));
    return new Promise<TcpProbeResult>((resolve) => {
      const socket = deps.socketFactory();
      const start = deps.now();
      let outcome: TcpProbeResult | null = null;
      let cancelTimer: (() => void) | undefined;
      const unsubscribe: (() => void)[] = [];
      function finish(result: TcpProbeResult): void {
        if (outcome) return;
        outcome = result;
        cancelTimer?.();
        signal?.removeEventListener('abort', abort);
        // Keep the error listener until close: destroy can race with a queued error.
        socket.destroy();
      }
      function abort(): void { finish(failed('CANCELLED')); }
      unsubscribe.push(socket.onConnect(() => finish({ status: 'ready', latencyMs: Math.max(0, Math.round(deps.now() - start)), errorCode: null })));
      unsubscribe.push(socket.onError((error) => finish(failed(safeErrorCode(error)))));
      unsubscribe.push(socket.onClose(() => {
        cancelTimer?.(); signal?.removeEventListener('abort', abort);
        unsubscribe.forEach((remove) => remove());
        resolve(outcome ?? failed('SOCKET_CLOSED'));
      }));
      // A wall-clock deadline includes DNS lookup; socket idle timeout alone does not.
      cancelTimer = deps.schedule(() => finish(failed('ETIMEDOUT')), CONNECTION_TIMEOUT_MS);
      signal?.addEventListener('abort', abort, { once: true });
      if (signal?.aborted) { abort(); return; }
      try { socket.connect(address, SERVICE_PORTS[service]); }
      catch (error) { finish(failed(safeErrorCode(error))); }
    });
  };
}
