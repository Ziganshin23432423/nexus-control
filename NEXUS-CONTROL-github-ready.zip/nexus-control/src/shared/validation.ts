import type { Computer, ComputerDraft, ValidationErrors, ValidationResult } from './types.js';

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
export function hasOnlyKeys(value: Record<string, unknown>, keys: readonly string[]): boolean {
  return Object.keys(value).every((key) => keys.includes(key));
}
export function isValidIpv4(value: string): boolean {
  return /^(?:\d{1,3}\.){3}\d{1,3}$/.test(value) && value.split('.').every((part) =>
    (part === '0' || !part.startsWith('0')) && Number(part) <= 255);
}
export function isValidHostname(value: string): boolean {
  return value.length >= 1 && value.length <= 253 && !/^[\d.]+$/.test(value) &&
    value.split('.').every((label) => label.length <= 63 && /^[a-z\d](?:[a-z\d-]*[a-z\d])?$/i.test(label));
}
export function isValidAddress(value: string): boolean {
  return isValidIpv4(value) || isValidHostname(value);
}
export function isValidMac(value: string): boolean {
  return /^(?:[\da-f]{2}:){5}[\da-f]{2}$|^(?:[\da-f]{2}-){5}[\da-f]{2}$/i.test(value);
}
export function normalizeMac(value: string): string | null {
  const trimmed = value.trim();
  return isValidMac(trimmed) ? trimmed.toUpperCase().replaceAll('-', ':') : null;
}
export function isValidPort(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= 65535;
}
export function isValidUsername(value: string): boolean {
  const account = /^[\p{L}\p{N}_][\p{L}\p{N}_.-]{0,63}$/u;
  if (!value || value.length > 128) return false;
  if (account.test(value)) return true;
  const domainParts = value.split('\\');
  if (domainParts.length === 2) return domainParts.every((part) => account.test(part));
  const upnParts = value.split('@');
  return upnParts.length === 2 && account.test(upnParts[0] ?? '') && isValidHostname(upnParts[1] ?? '');
}
export function isValidComputerId(value: unknown): value is string {
  return typeof value === 'string' && /^[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}$/i.test(value);
}

const DRAFT_KEYS = ['name', 'operatingSystem', 'hostname', 'localAddress', 'remoteAddress', 'macAddress', 'username', 'rdpEnabled', 'sshEnabled', 'wakeOnLan', 'notes'] as const;
const text = (value: unknown, max: number): value is string => typeof value === 'string' && value.length <= max && !/[\u0000-\u001f\u007f]/.test(value);

/** Runs unchanged in renderer and main; unknown fields (including secrets) are rejected. */
export function validateComputerDraft(input: unknown): ValidationResult<ComputerDraft> {
  if (!isRecord(input) || !hasOnlyKeys(input, DRAFT_KEYS)) return { ok: false, errors: { _form: 'Некорректная конфигурация компьютера: лишние или неизвестные поля.' } };
  const errors: ValidationErrors = {};
  const name = text(input['name'], 64) ? input['name'].trim() : '';
  const hostname = text(input['hostname'], 253) ? input['hostname'].trim() : '';
  const localAddress = text(input['localAddress'], 253) ? input['localAddress'].trim() : '';
  const optional = (value: unknown, max: number): string | null => value === null ? null : text(value, max) ? value.trim() || null : null;
  const remoteAddress = optional(input['remoteAddress'], 253);
  const rawMac = optional(input['macAddress'], 17);
  const macAddress = rawMac ? normalizeMac(rawMac) : null;
  const username = optional(input['username'], 128);
  if (!name) errors.name = 'Введите название до 64 символов без управляющих знаков.';
  if (!text(input['hostname'], 253) || (hostname && !isValidHostname(hostname))) errors.hostname = 'Укажите hostname: буквы, цифры и дефисы в DNS-имени.';
  if (!isValidAddress(localAddress)) errors.localAddress = 'Введите корректный IPv4 или hostname без протокола и порта.';
  if (input['remoteAddress'] !== null && (!text(input['remoteAddress'], 253) || (remoteAddress && !isValidAddress(remoteAddress)))) errors.remoteAddress = 'Введите корректный IPv4 или hostname.';
  if (input['macAddress'] !== null && (!text(input['macAddress'], 17) || (rawMac && !macAddress))) errors.macAddress = 'Используйте MAC в формате AA:BB:CC:DD:EE:FF или AA-BB-CC-DD-EE-FF.';
  if (input['username'] !== null && (!text(input['username'], 128) || (username && !isValidUsername(username)))) errors.username = 'Укажите username, DOMAIN\\user или user@domain без пробелов и командных символов.';
  if (input['sshEnabled'] === true && !username) errors.username = 'Для SSH укажите имя пользователя.';
  if (input['operatingSystem'] !== 'windows') errors.operatingSystem = 'Сейчас поддерживаются только Windows-компьютеры.';
  if (typeof input['rdpEnabled'] !== 'boolean' || typeof input['sshEnabled'] !== 'boolean') errors._form = 'Возможности компьютера должны быть переключателями.';
  const notes = typeof input['notes'] === 'string' ? input['notes'] : '';
  if (typeof input['notes'] !== 'string' || notes.length > 2000 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(notes)) errors.notes = 'Заметка должна содержать не более 2000 символов.';
  let wakeOnLan: ComputerDraft['wakeOnLan'] = null;
  const wol = input['wakeOnLan'];
  if (wol !== null) {
    if (!isRecord(wol) || !hasOnlyKeys(wol, ['broadcastAddress', 'port'])) errors._form = 'Некорректные настройки Wake-on-LAN.';
    else {
      const broadcastAddress = text(wol['broadcastAddress'], 15) ? wol['broadcastAddress'].trim() : '';
      if (!isValidIpv4(broadcastAddress)) errors.broadcastAddress = 'Введите корректный IPv4 broadcast address.';
      if (!isValidPort(wol['port'])) errors.port = 'Порт должен быть целым числом от 1 до 65535.';
      if (!macAddress) errors.macAddress = 'Для Wake-on-LAN нужен корректный MAC-адрес.';
      if (isValidPort(wol['port'])) wakeOnLan = { broadcastAddress, port: wol['port'] };
    }
  }
  if (Object.keys(errors).length) return { ok: false, errors };
  return { ok: true, value: { name, operatingSystem: 'windows', hostname, localAddress, remoteAddress, macAddress, username,
    rdpEnabled: input['rdpEnabled'] === true, sshEnabled: input['sshEnabled'] === true, wakeOnLan, notes } };
}

export function validateStoredComputer(input: unknown): ValidationResult<Computer> {
  if (!isRecord(input) || !hasOnlyKeys(input, [...DRAFT_KEYS, 'id', 'createdAt', 'updatedAt'])) return { ok: false, errors: { _form: 'Некорректная сохранённая запись.' } };
  const draft: Record<string, unknown> = {};
  for (const key of DRAFT_KEYS) draft[key] = input[key];
  const result = validateComputerDraft(draft);
  if (!result.ok) return result;
  const validDate = (value: unknown): value is string => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value) &&
    Number.isFinite(Date.parse(value)) && new Date(value).toISOString() === value;
  if (!isValidComputerId(input['id']) || !validDate(input['createdAt']) || !validDate(input['updatedAt']) || input['updatedAt'] < input['createdAt']) return { ok: false, errors: { _form: 'Некорректный ID или даты сохранённой записи.' } };
  return { ok: true, value: { ...result.value, id: input['id'], createdAt: input['createdAt'], updatedAt: input['updatedAt'] } };
}
