/** Fixed capabilities, never supplied by renderer. */
export const SERVICE_PORTS = Object.freeze({ rdp: 3389, ssh: 22 } as const);
export const CONNECTION_TIMEOUT_MS = 2000;
export const COMPUTER_CHECK_CONCURRENCY = 8;
