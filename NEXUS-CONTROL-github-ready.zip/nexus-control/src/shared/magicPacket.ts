import { normalizeMac } from './validation.js';

/** Standard WoL payload only: FF × 6, then MAC × 16. No arbitrary data. */
export function createMagicPacket(macAddress: string): Uint8Array {
  const normalized = normalizeMac(macAddress);
  if (!normalized) throw new Error('Некорректный MAC-адрес.');
  const mac = normalized.split(':').map(byte => Number.parseInt(byte, 16));
  const packet = new Uint8Array(102);
  packet.fill(0xff, 0, 6);
  for (let i = 0; i < 16; i++) packet.set(mac, 6 + i * 6);
  return packet;
}
