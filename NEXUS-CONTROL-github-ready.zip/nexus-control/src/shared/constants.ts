import type { ComputerOperatingSystem, HostPlatform } from './types';

export const APP_ID = 'network.onion.nexus-control';
export const APP_NAME = 'NEXUS CONTROL';
export const APP_TAGLINE = 'Все мои компьютеры — в одном месте.';

export const DEFAULT_COMPUTER_OPERATING_SYSTEM: ComputerOperatingSystem = 'windows';
export const MVP_SUPPORTED_HOST_PLATFORMS: readonly HostPlatform[] = Object.freeze(['windows']);
export const MVP_SUPPORTED_COMPUTER_SYSTEMS: readonly ComputerOperatingSystem[] = Object.freeze(['windows']);

export const IPC_CHANNELS = Object.freeze({
  wakeAndOpenRemoteDesktop: 'nexus:wake-connect:rdp',
  wakeAndOpenSshTerminal: 'nexus:wake-connect:ssh',
  cancelWakeAndConnect: 'nexus:wake-connect:cancel',
  wakeAndConnectProgress: 'nexus:wake-connect:progress',
  wakeComputer: 'nexus:wol:wake-computer',
  getAppInfo: 'nexus:app:get-info',
  listComputers: 'nexus:computers:list',
  createComputer: 'nexus:computers:create',
  updateComputer: 'nexus:computers:update',
  deleteComputer: 'nexus:computers:delete',
  checkComputerStatus: 'nexus:status:check-computer',
  refreshAllComputerStatuses: 'nexus:status:refresh-all',
  cancelComputerStatusChecks: 'nexus:status:cancel',
  openRemoteDesktop: 'nexus:rdp:open',
  openSshTerminal: 'nexus:ssh:open-terminal',
});

export const APP_PROTOCOL = 'nexus';
export const APP_ORIGIN = `${APP_PROTOCOL}://app`;
export const APP_ENTRY_URL = `${APP_ORIGIN}/index.html`;
export const DEV_RENDERER_ORIGIN = 'http://127.0.0.1:5173';
