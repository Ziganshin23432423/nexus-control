/** OS of a saved remote computer; distinct from the OS running NEXUS. */
export type ComputerOperatingSystem = 'windows' | 'linux';

/** Application host. Unsupported hosts never imply native feature support. */
export type HostPlatform = 'windows' | 'linux' | 'unsupported';

export interface WakeOnLanConfig {
  readonly broadcastAddress: string;
  readonly port: number;
}

/** Configuration only: passwords and computed availability do not belong here. */
export interface Computer {
  readonly id: string;
  readonly name: string;
  readonly operatingSystem: ComputerOperatingSystem;
  readonly hostname: string;
  readonly localAddress: string;
  readonly remoteAddress: string | null;
  readonly macAddress: string | null;
  readonly username: string | null;
  readonly rdpEnabled: boolean;
  readonly sshEnabled: boolean;
  readonly wakeOnLan: WakeOnLanConfig | null;
  readonly notes: string;
  readonly createdAt: string;
  readonly updatedAt: string;
}

/** Live state is kept separately from the persisted computer configuration. */
export type ComputerStatus = 'online' | 'offline' | 'checking' | 'unknown' | 'no-services';
export type ServiceStatus = 'ready' | 'unavailable' | 'checking' | 'disabled' | 'unknown';
export type WakeOnLanStatus = 'configured' | 'disabled';

export interface ConnectionCheckResult {
  readonly computerId: string;
  readonly status: ComputerStatus;
  readonly rdp: ServiceStatus;
  readonly ssh: ServiceStatus;
  readonly wakeOnLan: WakeOnLanStatus;
  readonly checkedAt: string | null;
  readonly services?: readonly ServiceCheckResult[];
  readonly configUpdatedAt?: string;
}

export interface AppInfo {
  readonly name: string;
  readonly version: string;
  readonly mode: 'development' | 'production';
  readonly platform: HostPlatform;
}

/** Every method is an explicit capability; never expose raw IPC or shell execution. */
export interface NexusApi {
  wakeAndOpenRemoteDesktop(id: string): Promise<IpcResult<WakeAndRdpResult>>;
  wakeAndOpenSshTerminal(id: string): Promise<IpcResult<WakeAndSshResult>>;
  cancelWakeAndConnect(id: string): Promise<IpcResult<{ computerId: string; cancelled: boolean }>>;
  onWakeAndConnectProgress(listener: (progress: WakeAndConnectProgress) => void): () => void;
  wakeComputer(id: string): Promise<IpcResult<WakeComputerResult>>;
  getAppInfo(): Promise<AppInfo>;
  listComputers(): Promise<IpcResult<Computer[]>>;
  createComputer(draft: ComputerDraft): Promise<IpcResult<Computer>>;
  updateComputer(id: string, draft: ComputerDraft): Promise<IpcResult<Computer>>;
  deleteComputer(id: string): Promise<IpcResult<null>>;
  checkComputerStatus(id: string): Promise<IpcResult<ConnectionCheckResult>>;
  refreshAllComputerStatuses(): Promise<IpcResult<ConnectionCheckResult[]>>;
  cancelComputerStatusChecks(): Promise<void>;
  openSshTerminal(id: string): Promise<IpcResult<SshTerminalLaunchResult>>;
  openRemoteDesktop(id: string): Promise<IpcResult<RemoteDesktopLaunchResult>>;
}

/** IDs and timestamps are assigned exclusively by main. */
export type ComputerDraft = Omit<Computer, 'id' | 'createdAt' | 'updatedAt'>;
export type ValidationField = keyof ComputerDraft | 'broadcastAddress' | 'port' | '_form';
export type ValidationErrors = Partial<Record<ValidationField, string>>;
export type ValidationResult<T> = { readonly ok: true; readonly value: T } | { readonly ok: false; readonly errors: ValidationErrors };
export type IpcErrorCode = 'WAKE_CONNECT_BUSY' | 'WAKE_CONNECT_TIMEOUT' | 'WAKE_CONNECT_UNSUPPORTED' | 'WOL_UNSUPPORTED' | 'WOL_DISABLED' | 'WOL_BUSY' | 'WOL_SEND_ERROR' | 'WOL_TIMEOUT' | 'VALIDATION_ERROR' | 'NOT_FOUND' | 'STORAGE_ERROR' | 'LIMIT_REACHED' | 'NETWORK_ERROR' | 'CANCELLED' | 'RDP_UNSUPPORTED' | 'RDP_DISABLED' | 'RDP_UNAVAILABLE' | 'RDP_CLIENT_MISSING' | 'RDP_LAUNCH_ERROR' | 'RDP_BUSY' | 'SSH_UNSUPPORTED' | 'SSH_DISABLED' | 'SSH_UNAVAILABLE' | 'SSH_CLIENT_MISSING' | 'SSH_HOST_MISSING' | 'SSH_LAUNCH_ERROR' | 'SSH_BUSY';
export type IpcResult<T> = { readonly ok: true; readonly value: T } | {
  readonly ok: false;
  readonly error: { readonly code: IpcErrorCode; readonly message: string; readonly fieldErrors?: ValidationErrors };
};

export type CheckedService = 'rdp' | 'ssh';
export type AddressKind = 'local' | 'remote';
export type TcpErrorCode = 'ECONNREFUSED' | 'ETIMEDOUT' | 'ENOTFOUND' | 'EAI_AGAIN' | 'EHOSTUNREACH' | 'ENETUNREACH' | 'ECONNRESET' | 'EACCES' | 'EPERM' | 'EADDRNOTAVAIL' | 'SOCKET_ERROR' | 'SOCKET_CLOSED' | 'CANCELLED';
export interface TcpAttempt {
  readonly address: string;
  readonly addressKind: AddressKind;
  readonly status: 'ready' | 'unavailable';
  readonly latencyMs: number | null;
  readonly errorCode: TcpErrorCode | null;
}
export interface ServiceCheckResult {
  readonly service: CheckedService;
  readonly status: 'ready' | 'unavailable' | 'disabled';
  readonly addressUsed: string | null;
  readonly addressKind: AddressKind | null;
  readonly port: 3389 | 22;
  readonly latencyMs: number | null;
  readonly errorCode: TcpErrorCode | null;
  readonly attempts: readonly TcpAttempt[];
}

/** Client process opened; this never asserts successful RDP authentication. */
export interface RemoteDesktopLaunchResult {
  readonly computerId: string;
  readonly state: 'client-opened';
  readonly rdp: ServiceCheckResult;
}

/** Terminal host opened; OpenSSH owns host-key checking and authentication. */
export interface SshTerminalLaunchResult {
  readonly computerId: string;
  readonly state: 'terminal-opened';
  readonly ssh: ServiceCheckResult;
}

/** UDP send acknowledgement only; never claims delivery or power-on. */
export interface WakeComputerResult {
  readonly computerId: string;
  readonly state: 'packet-sent';
  readonly packetsSent: 3;
}

export interface WakeAndConnectProgress {
  readonly computerId: string;
  readonly service: 'rdp' | 'ssh';
  readonly phase: 'sending' | 'waiting' | 'launching';
  /** Main-owned bounded deadline; informational only, never accepted as IPC input. */
  readonly remainingSeconds?: number;
}
export interface WakeAndRdpResult extends RemoteDesktopLaunchResult { readonly wakeSent: true; readonly waitedMs: number }
export interface WakeAndSshResult extends SshTerminalLaunchResult { readonly wakeSent: true; readonly waitedMs: number }
