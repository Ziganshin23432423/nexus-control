import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { smokeSummary, smokeExitCode } from '../src/main/readiness/windowsReadiness.js';
import type { SmokeReport, SmokeScenario } from '../src/main/readiness/windowsReadiness.js';

async function main():Promise<void>{
 const args=process.argv.slice(2);const selected=args[0]?.replace('--scenario=','')??'all';
 if(args.length>1||(args.length===1&&!args[0]?.startsWith('--scenario='))||!['app','rdp','ssh','wol','all'].includes(selected)){console.log('FAIL arguments: используйте --scenario=app|rdp|ssh|wol|all.');process.exitCode=2;return;}
 if(process.platform!=='win32'){console.log('FAIL host: smoke:windows запускается только на Windows. Linux QA не является Windows smoke.');process.exitCode=1;return;}
 const directory=await mkdtemp(join(tmpdir(),'nexus-windows-smoke-'));
 try{
  const executable=createRequire(import.meta.url)('electron') as string;
  const environment:NodeJS.ProcessEnv={...process.env,NEXUS_SMOKE_SESSION:directory,NEXUS_SMOKE_SCENARIO:selected as SmokeScenario};delete environment.ELECTRON_RUN_AS_NODE;delete environment.ELECTRON_RENDERER_URL;
  let output='';
  const exit=await new Promise<number>(resolveResult=>{
   const child=spawn(executable,[join(dirname(fileURLToPath(import.meta.url)),'windowsSmokeMain.js')],{shell:false,windowsHide:true,stdio:['ignore','pipe','ignore'],env:environment});
   // Keep reports compact and never forward native stderr, paths, environment or raw stack traces.
   child.stdout?.on('data',(chunk:Buffer)=>{if(output.length<65536)output+=chunk.toString('utf8');});
   const timer=setTimeout(()=>{child.kill();},30000);
   child.once('error',()=>{clearTimeout(timer);resolveResult(1);});child.once('exit',code=>{clearTimeout(timer);resolveResult(code??1);});
  });
  const line=output.split(/\r?\n/).find(value=>value.startsWith('NEXUS_SMOKE_REPORT='));
  if(!line){console.log('FAIL Electron: не удалось завершить диагностический запуск. Проверьте npm ci, build и WINDOWS-SMOKE.md.');process.exitCode=1;return;}
  const report=JSON.parse(line.slice('NEXUS_SMOKE_REPORT='.length)) as SmokeReport;
  console.log(smokeSummary(report));console.log('Диагностика не запускает RDP/SSH, не отправляет WoL и не проверяет авторизацию целевого ПК.');
  process.exitCode=exit||smokeExitCode(report);
 }finally{await rm(directory,{recursive:true,force:true,maxRetries:4,retryDelay:150}).catch(()=>{console.log('WARN cleanup: временный диагностический профиль занят Windows; повторите после закрытия процесса.');});}
}
main().catch(()=>{console.log('FAIL smoke: диагностика не завершена. Проверьте prerequisites по WINDOWS-SMOKE.md.');process.exitCode=1;});
