"""Recreate Windows ICO + contact sheet from committed SVG-rendered master PNG.
Requires Pillow. SVG is preserved in build/nexus-mark.svg; no redesign involved.
"""
from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parent.parent
image = Image.open(root / 'build/icon.png')
sizes = [16, 20, 24, 32, 40, 48, 64, 128, 256]
image.save(root / 'build/icon.ico', sizes=[(s, s) for s in sizes])
sheet = Image.new('RGB', (900, 315), '#0b1017')
draw = ImageDraw.Draw(sheet)
x = 12
for size in sizes:
    tile = image.resize((size, size), Image.Resampling.LANCZOS)
    sheet.paste(tile, (x, 35), tile)
    draw.text((x, 12), str(size), fill='white')
    x += size + 14
sheet.save(root / 'docs/stage13/icon-sizes.png')
