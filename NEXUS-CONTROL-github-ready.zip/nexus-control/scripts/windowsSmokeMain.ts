import { app, BrowserWindow, protocol } from 'electron';
import { constants } from 'node:fs';
import { access, stat, lstat, readFile, writeFile, mkdir } from 'node:fs/promises';
import { createSocket } from 'node:dgram';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { APP_NAME, APP_PROTOCOL } from '../src/shared/constants.js';
import { configureSessionSecurity, protectWindow } from '../src/main/security.js';
import { registerAppProtocol } from '../src/main/protocol.js';
import { exclusiveWritableProbe } from '../src/main/readiness/fileProbe.js';
import { auditProject } from '../src/main/readiness/sourceAudit.js';
import { runWindowsReadiness, smokeExitCode } from '../src/main/readiness/windowsReadiness.js';
import type { SmokeScenario } from '../src/main/readiness/windowsReadiness.js';

const project=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
const scenario=process.env['NEXUS_SMOKE_SCENARIO'] as SmokeScenario;
const sessionDirectory=process.env['NEXUS_SMOKE_SESSION']??'';
if(!sessionDirectory||!['app','rdp','ssh','wol','all'].includes(scenario)) throw new Error('Smoke must be started through npm run smoke:windows.');
app.setName(APP_NAME);
// Real userData is only probed with one exclusively-created temporary file; its data is never read.
const realUserData=app.getPath('userData');
app.setPath('userData',sessionDirectory);
protocol.registerSchemesAsPrivileged([{scheme:APP_PROTOCOL,privileges:{standard:true,secure:true,supportFetchAPI:true}}]);
let window:BrowserWindow|null=null;
async function readableFile(path:string):Promise<boolean>{await access(path,constants.R_OK);return (await stat(path)).isFile();}
async function storageProbe():Promise<boolean>{
  const probeDirectory=join(sessionDirectory,'probe');await mkdir(probeDirectory,{recursive:true});
  await writeFile(join(probeDirectory,'index.html'),'<!doctype html><html lang="ru"><meta charset="utf-8"><title>NEXUS diagnostic</title><body></body></html>');
  configureSessionSecurity(false);registerAppProtocol(probeDirectory);
  window=new BrowserWindow({show:false,backgroundColor:'#0b1017',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false}});
  protectWindow(window);await window.loadURL(`${APP_PROTOCOL}://app/index.html`);
  // Fixed diagnostic in an isolated session. No preload, IPC, appearance key, fetch or client launch.
  await window.webContents.executeJavaScript("localStorage.setItem('nexus.smoke.probe','ready')");
  await window.loadURL(`${APP_PROTOCOL}://app/index.html`);
  return window.webContents.executeJavaScript("(()=>{const ok=localStorage.getItem('nexus.smoke.probe')==='ready';localStorage.removeItem('nexus.smoke.probe');return ok})()");
}
async function udpProbe():Promise<boolean>{
  return new Promise(resolveResult=>{const socket=createSocket('udp4');let done=false;const timer=setTimeout(()=>finish(false),1500);
    function finish(ok:boolean):void{if(done)return;done=true;clearTimeout(timer);try{socket.close(()=>resolveResult(ok));}catch{resolveResult(false);}}
    socket.once('error',()=>finish(false));try{socket.bind(0,'127.0.0.1',()=>finish(true));}catch{finish(false);}
  });
}
app.whenReady().then(async()=>{
 const metadata=JSON.parse(await readFile(join(project,'package.json'),'utf8')) as {version:string};
 const report=await runWindowsReadiness({platform:process.platform,architecture:process.arch,version:metadata.version,scenario,environment:process.env,
  isFile:readableFile,isAlias:async path=>{const entry=await lstat(path);return entry.isFile()||entry.isSymbolicLink();},
  sourceSafe:async()=>!(await auditProject(project)).length,
  buildReady:async()=>{for(const file of ['out/main/main.js','out/preload/preload.cjs','out/renderer/index.html','out/renderer/nexus-mark.svg'])if(!await readableFile(join(project,file)))return false;return true;},
  userDataWritable:()=>exclusiveWritableProbe(realUserData),rendererStorage:storageProbe,udpLifecycle:udpProbe});
 window?.destroy();console.log('NEXUS_SMOKE_REPORT='+JSON.stringify(report));app.exit(smokeExitCode(report));
}).catch(()=>{window?.destroy();console.log('NEXUS_SMOKE_FAILURE');app.exit(1);});
