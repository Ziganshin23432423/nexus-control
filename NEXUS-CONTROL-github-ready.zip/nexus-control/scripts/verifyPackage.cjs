// Read-only inspection. Never executes the Windows installer or native app.
const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
const resedit=require('resedit'); // pinned transitively by electron-builder
const sizes=[16,20,24,32,40,48,64,128,256];
function inspectPE(file,isApp){
  const b=fs.readFileSync(file),pe=b.readUInt32LE(60),optional=pe+24;
  assert.equal(b.readUInt32LE(pe),0x4550);
  assert.equal(b.readUInt16LE(pe+4),isApp?0x8664:0x14c);
  const magic=b.readUInt16LE(optional),dirs=optional+(magic===0x20b?112:96);
  assert.equal(b.readUInt32LE(dirs+4*8+4),0,'Unsigned RC expected');
  const e=resedit.NtExecutable.from(b),r=resedit.NtExecutableResource.from(e);
  const v=resedit.Resource.VersionInfo.fromEntries(r.entries)[0];assert.ok(v);
  const lang=v.getAllLanguagesForStringValues()[0],strings=v.getStringValues(lang);
  assert.equal(strings.CompanyName,'network.onion');assert.equal(strings.ProductName,'NEXUS CONTROL');
  assert.equal(strings.FileVersion,'1.0.0.1');
  assert.equal(strings.ProductVersion,isApp?'1.0.0.1':'1.0.0-rc.1');
  const icons=resedit.Resource.IconGroupEntry.fromEntries(r.entries)[0].icons;
  assert.deepEqual(icons.map(i=>i.width||256),sizes);
  const manifest=r.entries.find(e=>e.type===24);
  assert.ok(manifest);assert.match(Buffer.from(manifest.bin).toString('utf8'),/level="asInvoker"/);
  return {file:path.basename(file),bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex'),machine:isApp?'x64':'x86 installer stub / x64 payload',signed:false,strings,iconSizes:sizes,fixedVersion:v.fixedInfo};
}
async function run(){
  const asar=await import('@electron/asar');
  const args=process.argv.slice(2),unpackedOnly=args.includes('--unpacked');
  const release=path.resolve(args.find(a=>!a.startsWith('--'))||'release'),app=path.join(release,'win-unpacked');
  const report={application:inspectPE(path.join(app,'NEXUS CONTROL.exe'),true),installer:unpackedOnly?{status:'NOT BUILT',reason:'Inspecting unpacked app only; native NSIS build remains a separate gate'}:inspectPE(path.join(release,'NEXUS-CONTROL-Setup-1.0.0-rc.1.exe'),false)};
  const archive=path.join(app,'resources/app.asar'),names=asar.listPackage(archive);
  for(const name of ['/out/main/main.js','/out/preload/preload.cjs','/out/renderer/index.html','/package.json'])assert.ok(names.includes(name),name);
  const forbidden=names.filter(n=>/^\/(src|tests|docs|scripts|build|\.git|\.test-out|\.smoke-out)(\/|$)/.test(n)||/(^|\/)\.env($|\.)/.test(n)||/node_modules\/(electron-builder|app-builder-lib|typescript|electron-updater)(\/|$)/.test(n)||/computers\.json$|nexus\.appearance|profile-/i.test(n));
  assert.deepEqual(forbidden,[]);
  const pkg=JSON.parse(asar.extractFile(archive,'package.json'));assert.equal(pkg.version,'1.0.0-rc.1');assert.equal(pkg.main,'./out/main/main.js');
  const main=asar.extractFile(archive,'out/main/main.js').toString();
  for(const text of ['nodeIntegration: false','contextIsolation: true','sandbox: true','webSecurity: true'])assert.ok(main.includes(text),text);
  assert.ok(main.includes('network.onion.nexus-control'));
  assert.deepEqual(fs.readFileSync(path.join(app,'resources/icon.ico')),fs.readFileSync('build/icon.ico'));
  report.asar={bytes:fs.statSync(archive).size,entries:names.length,rootEntries:names.filter(n=>!n.slice(1).includes('/')),forbiddenFiles:forbidden,version:pkg.version,securityPreferencesPreserved:true};
  fs.mkdirSync('docs/stage13',{recursive:true});fs.writeFileSync('docs/stage13/package-inspection.json',JSON.stringify(report,null,2)+'\n');
  console.log('PASS x64 app, '+(unpackedOnly?'unpacked inspection':'NSIS PE')+', unsigned RC, versions, embedded icons, manifest, ASAR whitelist and sandbox');
}
run().catch(e=>{console.error(e);process.exitCode=1;});
